__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  var _FileSystem = require(_dependencyMap[0], "./FileSystem");
  Object.keys(_FileSystem).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _FileSystem[k];
        }
      });
    }
  });
  var _legacyWarnings = require(_dependencyMap[1], "./legacyWarnings");
  Object.keys(_legacyWarnings).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _legacyWarnings[k];
        }
      });
    }
  });
},3721,[3731,3737],"node_modules/expo-file-system/src/index.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "Paths", {
    enumerable: true,
    get: function () {
      return Paths;
    }
  });
  Object.defineProperty(exports, "File", {
    enumerable: true,
    get: function () {
      return File;
    }
  });
  Object.defineProperty(exports, "Directory", {
    enumerable: true,
    get: function () {
      return Directory;
    }
  });
  var _ExpoFileSystem = require(_dependencyMap[0], "./ExpoFileSystem");
  var ExpoFileSystem = _interopDefault(_ExpoFileSystem);
  var _pathUtilities = require(_dependencyMap[1], "./pathUtilities");
  var _streams = require(_dependencyMap[2], "./streams");
  class Paths extends _pathUtilities.PathUtilities {
    /**
     * A property containing the cache directory – a place to store files that can be deleted by the system when the device runs low on storage.
     */
    static get cache() {
      return new Directory(ExpoFileSystem.default.cacheDirectory);
    }

    /**
     * A property containing the bundle directory – the directory where assets bundled with the application are stored.
     */
    static get bundle() {
      return new Directory(ExpoFileSystem.default.bundleDirectory);
    }

    /**
     * A property containing the document directory – a place to store files that are safe from being deleted by the system.
     */
    static get document() {
      return new Directory(ExpoFileSystem.default.documentDirectory);
    }
    static get appleSharedContainers() {
      const containers = ExpoFileSystem.default.appleSharedContainers ?? {};
      const result = {};
      for (const appGroupId in containers) {
        if (containers[appGroupId]) {
          result[appGroupId] = new Directory(containers[appGroupId]);
        }
      }
      return result;
    }

    /**
     * A property that represents the total space on device's internal storage, represented in bytes.
     */
    static get totalDiskSpace() {
      return ExpoFileSystem.default.totalDiskSpace;
    }

    /**
     * A property that represents the available space on device's internal storage, represented in bytes.
     */
    static get availableDiskSpace() {
      return ExpoFileSystem.default.availableDiskSpace;
    }

    /**
     * Returns an object that indicates if the specified path represents a directory.
     */
    static info(...uris) {
      return ExpoFileSystem.default.info(uris.join('/'));
    }
  }

  /**
   * Represents a file on the filesystem.
   *
   * A `File` instance can be created for any path, and does not need to exist on the filesystem during creation.
   *
   * The constructor accepts an array of strings that are joined to create the file URI. The first argument can also be a `Directory` instance (like `Paths.cache`) or a `File` instance (which creates a new reference to the same file).
   * @example
   * ```ts
   * const file = new File(Paths.cache, "subdirName", "file.txt");
   * ```
   */
  class File extends ExpoFileSystem.default.FileSystemFile {
    /**
     * Creates an instance of a file. It can be created for any path, and does not need to exist on the filesystem during creation.
     *
     * The constructor accepts an array of strings that are joined to create the file URI. The first argument can also be a `Directory` instance (like `Paths.cache`) or a `File` instance (which creates a new reference to the same file).
     * @param uris An array of: `file:///` string URIs, `File` instances, and `Directory` instances representing an arbitrary location on the file system.
     * @example
     * ```ts
     * const file = new File(Paths.cache, "subdirName", "file.txt");
     * ```
     */
    constructor(...uris) {
      super(Paths.join(...uris));
      this.validatePath();
    }

    /*
     * Directory containing the file.
     */
    get parentDirectory() {
      return new Directory(Paths.dirname(this.uri));
    }

    /**
     * File extension.
     * @example '.png'
     */
    get extension() {
      return Paths.extname(this.uri);
    }

    /**
     * File name. Includes the extension.
     */
    get name() {
      return Paths.basename(this.uri);
    }
    readableStream() {
      return new ReadableStream(new _streams.FileSystemReadableStreamSource(super.open()));
    }
    writableStream() {
      return new WritableStream(new _streams.FileSystemWritableSink(super.open()));
    }
    async arrayBuffer() {
      const bytes = await this.bytes();
      return bytes.buffer;
    }
    stream() {
      return this.readableStream();
    }
    slice(start, end, contentType) {
      return new Blob([this.bytesSync().slice(start, end)], {
        type: contentType
      });
    }
  }

  // Cannot use `static` keyword in class declaration because of a runtime error.
  File.downloadFileAsync = async function downloadFileAsync(url, to, options) {
    const outputURI = await ExpoFileSystem.default.downloadFileAsync(url, to, options);
    return new File(outputURI);
  };
  File.pickFileAsync = async function (initialUri, mimeType) {
    const file = (await ExpoFileSystem.default.pickFileAsync(initialUri, mimeType)).uri;
    return new File(file);
  };

  /**
   * Represents a directory on the filesystem.
   *
   * A `Directory` instance can be created for any path, and does not need to exist on the filesystem during creation.
   *
   * The constructor accepts an array of strings that are joined to create the directory URI. The first argument can also be a `Directory` instance (like `Paths.cache`).
   * @example
   * ```ts
   * const directory = new Directory(Paths.cache, "subdirName");
   * ```
   */
  class Directory extends ExpoFileSystem.default.FileSystemDirectory {
    /**
     * Creates an instance of a directory. It can be created for any path, and does not need to exist on the filesystem during creation.
     *
     * The constructor accepts an array of strings that are joined to create the directory URI. The first argument can also be a `Directory` instance (like `Paths.cache`).
     * @param uris An array of: `file:///` string URIs, `File` instances, and `Directory` instances representing an arbitrary location on the file system.
     * @example
     * ```ts
     * const directory = new Directory(Paths.cache, "subdirName");
     * ```
     */
    constructor(...uris) {
      super(Paths.join(...uris));
      this.validatePath();
    }

    /*
     * Directory containing the file.
     */
    get parentDirectory() {
      return new Directory(Paths.join(this.uri, '..'));
    }

    /**
     * Lists the contents of a directory.
     * Calling this method if the parent directory does not exist will throw an error.
     * @returns An array of `Directory` and `File` instances.
     */
    list() {
      // We need to wrap it in the JS File/Directory classes, and returning SharedObjects in lists is not supported yet on Android.
      return super.listAsRecords().map(({
        isDirectory,
        uri
      }) => isDirectory ? new Directory(uri) : new File(uri));
    }

    /**
     * Directory name.
     */
    get name() {
      return Paths.basename(this.uri);
    }
    createFile(name, mimeType) {
      // Wrapping with the JS child class for additional, JS-only methods.
      return new File(super.createFile(name, mimeType).uri);
    }
    createDirectory(name) {
      return new Directory(super.createDirectory(name).uri);
    }
  }
  Directory.pickDirectoryAsync = async function (initialUri) {
    const directory = (await ExpoFileSystem.default.pickDirectoryAsync(initialUri)).uri;
    return new Directory(directory);
  };
},3731,[3732,3733,3736],"node_modules/expo-file-system/src/FileSystem.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  class FileSystemFile {
    constructor() {
      console.warn('expo-file-system is not supported on web');
    }
  }
  class FileSystemDirectory {
    constructor() {
      console.warn('expo-file-system is not supported on web');
    }
  }
  var _default = {
    FileSystemDirectory,
    FileSystemFile,
    downloadFileAsync: () => {
      console.warn('expo-file-system is not supported on web');
      return Promise.resolve();
    },
    pickDirectoryAsync: () => {
      console.warn('expo-file-system is not supported on web');
      return Promise.resolve();
    },
    pickFileAsync: () => {
      console.warn('expo-file-system is not supported on web');
      return Promise.resolve();
    },
    get totalDiskSpace() {
      console.warn('expo-file-system is not supported on web');
      return 0;
    },
    get availableDiskSpace() {
      console.warn('expo-file-system is not supported on web');
      return 0;
    },
    get documentDirectory() {
      console.warn('expo-file-system is not supported on web');
      return '';
    },
    get cacheDirectory() {
      console.warn('expo-file-system is not supported on web');
      return '';
    },
    get bundleDirectory() {
      console.warn('expo-file-system is not supported on web');
      return '';
    }
  };
},3732,[],"node_modules/expo-file-system/src/ExpoFileSystem.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "PathUtilities", {
    enumerable: true,
    get: function () {
      return PathUtilities;
    }
  });
  var _path = require(_dependencyMap[0], "./path");
  var nodePath = _interopNamespace(_path);
  var _url = require(_dependencyMap[1], "./url");
  function uriObjectToString(path) {
    return typeof path === 'string' ? path : path.uri;
  }
  class PathUtilities {
    /**
     * Joins path segments into a single path.
     * @param paths - An array of path segments.
     * @returns A string representing the joined path.
     */
    static join(...paths) {
      const [firstSegment, ...rest] = paths.map(uriObjectToString);
      const pathAsUrl = (0, _url.asUrl)(firstSegment);
      if (pathAsUrl) {
        pathAsUrl.pathname = nodePath.join(pathAsUrl.pathname, ...rest.map(_url.encodeURLChars));
        return pathAsUrl.toString();
      }
      return nodePath.join(firstSegment, ...rest.map(_url.encodeURLChars));
    }

    /**
     * Resolves a relative path to an absolute path.
     * @param from - The base path.
     * @param to - The relative path.
     * @returns A string representing the resolved path.
     */
    static relative(from, to) {
      const fromString = uriObjectToString(from);
      const toString = uriObjectToString(to);

      // If the first path is a file URL, convert it to a path
      if ((0, _url.isUrl)(fromString)) {
        from = (0, _url.asUrl)(fromString).pathname;
      }
      // If the second path is a file URL, convert it to a path
      if ((0, _url.isUrl)(toString)) {
        to = (0, _url.asUrl)(toString).pathname;
      }
      return nodePath.relative(fromString, toString);
    }

    /**
     * Checks if a path is absolute.
     * @param path - The path to check.
     * @returns `true` if the path is absolute, `false` otherwise.
     */
    static isAbsolute(path) {
      const pathString = uriObjectToString(path);
      if ((0, _url.isUrl)(pathString)) {
        return true;
      }
      return nodePath.isAbsolute(pathString);
    }

    /**
     * Normalizes a path.
     * @param path - The path to normalize.
     * @returns A string representing the normalized path.
     */
    static normalize(path) {
      const pathString = uriObjectToString(path);
      const pathURL = (0, _url.asUrl)((0, _url.encodeURLChars)(pathString));
      if (pathURL) {
        pathURL.pathname = (0, _url.encodeURLChars)(nodePath.normalize(decodeURIComponent(pathURL.pathname)));
        return pathURL.toString();
      }
      return nodePath.normalize(pathString);
    }

    /**
     * Returns the directory name of a path.
     * @param path - The path to get the directory name from.
     * @returns A string representing the directory name.
     */
    static dirname(path) {
      const pathString = uriObjectToString(path);
      const pathURL = (0, _url.asUrl)(pathString);
      if (pathURL) {
        pathURL.pathname = (0, _url.encodeURLChars)(nodePath.dirname(decodeURIComponent(pathURL.pathname)));
        return pathURL.toString();
      }
      return nodePath.dirname(pathString);
    }

    /**
     * Returns the base name of a path.
     * @param path - The path to get the base name from.
     * @param ext - An optional file extension.
     * @returns A string representing the base name.
     */
    static basename(path, ext) {
      const pathString = uriObjectToString(path);
      const pathURL = (0, _url.asUrl)(pathString);
      if (pathURL) {
        return nodePath.basename(decodeURIComponent(pathURL.pathname));
      }
      return nodePath.basename(pathString, ext);
    }

    /**
     * Returns the extension of a path.
     * @param path - The path to get the extension from.
     * @returns A string representing the extension.
     */
    static extname(path) {
      const pathString = uriObjectToString(path);
      const pathURL = (0, _url.asUrl)(pathString);
      if (pathURL) {
        return nodePath.extname(decodeURIComponent(pathURL.pathname));
      }
      return nodePath.extname(pathString);
    }

    /**
     * Parses a path into its components.
     * @param path - The path to parse.
     * @returns An object containing the parsed path components.
     */
    static parse(path) {
      const pathString = uriObjectToString(path);
      const pathURL = (0, _url.asUrl)(pathString);
      if (pathURL) {
        return nodePath.parse(decodeURIComponent(pathURL.pathname));
      }
      return nodePath.parse(pathString);
    }
  }
},3733,[3734,3735],"node_modules/expo-file-system/src/pathUtilities/index.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.format = format;
  exports.resolve = resolve;
  exports.normalize = normalize;
  exports.isAbsolute = isAbsolute;
  exports.join = join;
  exports.relative = relative;
  exports.toNamespacedPath = toNamespacedPath;
  exports.dirname = dirname;
  exports.basename = basename;
  exports.extname = extname;
  exports.parse = parse;
  Object.defineProperty(exports, "sep", {
    enumerable: true,
    get: function () {
      return sep;
    }
  });
  Object.defineProperty(exports, "delimiter", {
    enumerable: true,
    get: function () {
      return delimiter;
    }
  });
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.

  function isPathSeparator(code) {
    return code === '/';
  }

  // Resolves . and .. elements in a path with directory names
  function normalizeString(path, allowAboveRoot, separator) {
    let res = '';
    let lastSegmentLength = 0;
    let lastSlash = -1;
    let dots = 0;
    let code = '';
    for (let i = 0; i <= path.length; ++i) {
      if (i < path.length) code = path.charAt(i);else if (isPathSeparator(code)) break;else code = '/';
      if (isPathSeparator(code)) {
        if (lastSlash === i - 1 || dots === 1) {
          // NOOP
        } else if (dots === 2) {
          if (res.length < 2 || lastSegmentLength !== 2 || res.charAt(res.length - 1) !== '.' || res.charAt(res.length - 2) !== '.') {
            if (res.length > 2) {
              const lastSlashIndex = res.lastIndexOf(separator);
              if (lastSlashIndex === -1) {
                res = '';
                lastSegmentLength = 0;
              } else {
                res = res.slice(0, lastSlashIndex);
                lastSegmentLength = res.length - 1 - res.lastIndexOf(separator);
              }
              lastSlash = i;
              dots = 0;
              continue;
            } else if (res.length !== 0) {
              res = '';
              lastSegmentLength = 0;
              lastSlash = i;
              dots = 0;
              continue;
            }
          }
          if (allowAboveRoot) {
            res += res.length > 0 ? `${separator}..` : '..';
            lastSegmentLength = 2;
          }
        } else {
          if (res.length > 0) res += `${separator}${path.slice(lastSlash + 1, i)}`;else res = path.slice(lastSlash + 1, i);
          lastSegmentLength = i - lastSlash - 1;
        }
        lastSlash = i;
        dots = 0;
      } else if (code === '.' && dots !== -1) {
        ++dots;
      } else {
        dots = -1;
      }
    }
    return res;
  }
  function formatExt(ext) {
    return ext ? `${ext[0] === '.' ? '' : '.'}${ext}` : '';
  }
  function format(sep, pathObject) {
    const dir = pathObject.dir || pathObject.root;
    const base = pathObject.base || `${pathObject.name || ''}${formatExt(pathObject.ext)}`;
    if (!dir) {
      return base;
    }
    return dir === pathObject.root ? `${dir}${base}` : `${dir}${sep}${base}`;
  }
  function resolve(...args) {
    let resolvedPath = '';
    let resolvedAbsolute = false;
    for (let i = args.length - 1; i >= -1 && !resolvedAbsolute; i--) {
      const path = i >= 0 ? args[i] : '';

      // Skip empty entries
      if (!path || path.length === 0) {
        continue;
      }
      resolvedPath = `${path}/${resolvedPath}`;
      resolvedAbsolute = !!(path && path.charAt(0) === '/');
    }

    // At this point the path should be resolved to a full absolute path, but
    // handle relative paths to be safe (might happen when process.cwd() fails)

    // Normalize the path
    resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute, '/');
    if (resolvedAbsolute) {
      return `/${resolvedPath}`;
    }
    return resolvedPath.length > 0 ? resolvedPath : '.';
  }
  function normalize(path) {
    if (path.length === 0) return '.';
    const isAbsolute = path.charAt(0) === '/';
    const trailingSeparator = path.charAt(path.length - 1) === '/';

    // Normalize the path
    path = normalizeString(path, !isAbsolute, '/');
    if (path.length === 0) {
      if (isAbsolute) return '/';
      return trailingSeparator ? './' : '.';
    }
    if (trailingSeparator) path += '/';
    return isAbsolute ? `/${path}` : path;
  }
  function isAbsolute(path) {
    return path.length > 0 && path.charAt(0) === '/';
  }
  function join(...args) {
    if (args.length === 0) return '.';
    const path = [];
    for (let i = 0; i < args.length; ++i) {
      const arg = args[i];
      if (arg && arg.length > 0) {
        path.push(arg);
      }
    }
    if (path.length === 0) return '.';
    return normalize(path.join('/'));
  }
  function relative(from, to) {
    if (from === to) return '';

    // Trim leading forward slashes.
    from = resolve(from);
    to = resolve(to);
    if (from === to) return '';
    const fromStart = 1;
    const fromEnd = from.length;
    const fromLen = fromEnd - fromStart;
    const toStart = 1;
    const toLen = to.length - toStart;

    // Compare paths to find the longest common path from root
    const length = fromLen < toLen ? fromLen : toLen;
    let lastCommonSep = -1;
    let i = 0;
    for (; i < length; i++) {
      const fromChar = from.charAt(fromStart + i);
      if (fromChar !== to.charAt(toStart + i)) break;else if (fromChar === '/') lastCommonSep = i;
    }
    if (i === length) {
      if (toLen > length) {
        if (to.charAt(toStart + i) === '/') {
          // We get here if `from` is the exact base path for `to`.
          // For example: from='/foo/bar'; to='/foo/bar/baz'
          return to.slice(toStart + i + 1);
        }
        if (i === 0) {
          // We get here if `from` is the root
          // For example: from='/'; to='/foo'
          return to.slice(toStart + i);
        }
      } else if (fromLen > length) {
        if (from.charAt(fromStart + i) === '/') {
          // We get here if `to` is the exact base path for `from`.
          // For example: from='/foo/bar/baz'; to='/foo/bar'
          lastCommonSep = i;
        } else if (i === 0) {
          // We get here if `to` is the root.
          // For example: from='/foo/bar'; to='/'
          lastCommonSep = 0;
        }
      }
    }
    let out = '';
    // Generate the relative path based on the path difference between `to`
    // and `from`.
    for (i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i) {
      if (i === fromEnd || from.charAt(i) === '/') {
        out += out.length === 0 ? '..' : '/..';
      }
    }

    // Lastly, append the rest of the destination (`to`) path that comes after
    // the common path parts.
    return `${out}${to.slice(toStart + lastCommonSep)}`;
  }
  function toNamespacedPath(path) {
    // Non-op on posix systems
    return path;
  }
  function dirname(path) {
    if (path.length === 0) return '.';
    const hasRoot = path.charAt(0) === '/';
    let end = -1;
    let matchedSlash = true;
    for (let i = path.length - 1; i >= 1; --i) {
      if (path.charAt(i) === '/') {
        if (!matchedSlash) {
          end = i;
          break;
        }
      } else {
        // We saw the first non-path separator
        matchedSlash = false;
      }
    }
    if (end === -1) return hasRoot ? '/' : '.';
    if (hasRoot && end === 1) return '//';
    return path.slice(0, end);
  }
  function basename(path, suffix) {
    let start = 0;
    let end = -1;
    let matchedSlash = true;
    if (suffix !== undefined && suffix.length > 0 && suffix.length <= path.length) {
      if (suffix === path) return '';
      let extIdx = suffix.length - 1;
      let firstNonSlashEnd = -1;
      for (let i = path.length - 1; i >= 0; --i) {
        const code = path.charAt(i);
        if (code === '/') {
          // If we reached a path separator that was not part of a set of path
          // separators at the end of the string, stop now
          if (!matchedSlash) {
            start = i + 1;
            break;
          }
        } else {
          if (firstNonSlashEnd === -1) {
            // We saw the first non-path separator, remember this index in case
            // we need it if the extension ends up not matching
            matchedSlash = false;
            firstNonSlashEnd = i + 1;
          }
          if (extIdx >= 0) {
            // Try to match the explicit extension
            if (code === suffix.charAt(extIdx)) {
              if (--extIdx === -1) {
                // We matched the extension, so mark this as the end of our path
                // component
                end = i;
              }
            } else {
              // Extension does not match, so our result is the entire path
              // component
              extIdx = -1;
              end = firstNonSlashEnd;
            }
          }
        }
      }
      if (start === end) end = firstNonSlashEnd;else if (end === -1) end = path.length;
      return path.slice(start, end);
    }
    for (let i = path.length - 1; i >= 0; --i) {
      if (path.charAt(i) === '/') {
        // If we reached a path separator that was not part of a set of path
        // separators at the end of the string, stop now
        if (!matchedSlash) {
          start = i + 1;
          break;
        }
      } else if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // path component
        matchedSlash = false;
        end = i + 1;
      }
    }
    if (end === -1) return '';
    return path.slice(start, end);
  }
  function extname(path) {
    let startDot = -1;
    let startPart = 0;
    let end = -1;
    let matchedSlash = true;
    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    let preDotState = 0;
    for (let i = path.length - 1; i >= 0; --i) {
      const code = path.charAt(i);
      if (code === '/') {
        // If we reached a path separator that was not part of a set of path
        // separators at the end of the string, stop now
        if (!matchedSlash) {
          startPart = i + 1;
          break;
        }
        continue;
      }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false;
        end = i + 1;
      }
      if (code === '.') {
        // If this is our first dot, mark it as the start of our extension
        if (startDot === -1) startDot = i;else if (preDotState !== 1) preDotState = 1;
      } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1;
      }
    }
    if (startDot === -1 || end === -1 ||
    // We saw a non-dot character immediately before the dot
    preDotState === 0 ||
    // The (right-most) trimmed path component is exactly '..'
    preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
      return '';
    }
    return path.slice(startDot, end);
  }
  function parse(path) {
    const ret = {
      root: '',
      dir: '',
      base: '',
      ext: '',
      name: ''
    };
    if (path.length === 0) return ret;
    const isAbsolute = path.charAt(0) === '/';
    let start;
    if (isAbsolute) {
      ret.root = '/';
      start = 1;
    } else {
      start = 0;
    }
    let startDot = -1;
    let startPart = 0;
    let end = -1;
    let matchedSlash = true;
    let i = path.length - 1;

    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    let preDotState = 0;

    // Get non-dir info
    for (; i >= start; --i) {
      const code = path.charAt(i);
      if (code === '/') {
        // If we reached a path separator that was not part of a set of path
        // separators at the end of the string, stop now
        if (!matchedSlash) {
          startPart = i + 1;
          break;
        }
        continue;
      }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false;
        end = i + 1;
      }
      if (code === '.') {
        // If this is our first dot, mark it as the start of our extension
        if (startDot === -1) startDot = i;else if (preDotState !== 1) preDotState = 1;
      } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1;
      }
    }
    if (end !== -1) {
      const start = startPart === 0 && isAbsolute ? 1 : startPart;
      if (startDot === -1 ||
      // We saw a non-dot character immediately before the dot
      preDotState === 0 ||
      // The (right-most) trimmed path component is exactly '..'
      preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
        // eslint-disable-next-line no-multi-assign
        ret.base = ret.name = path.slice(start, end);
      } else {
        ret.name = path.slice(start, startDot);
        ret.base = path.slice(start, end);
        ret.ext = path.slice(startDot, end);
      }
    }
    if (startPart > 0) ret.dir = path.slice(0, startPart - 1);else if (isAbsolute) ret.dir = '/';
    return ret;
  }
  const sep = '/';
  const delimiter = ':';
},3734,[],"node_modules/expo-file-system/src/pathUtilities/path.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.encodeURLChars = encodeURLChars;
  exports.isUrl = isUrl;
  exports.asUrl = asUrl;
  var _path = require(_dependencyMap[0], "./path");
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.

  const percentRegEx = /%/g;
  const backslashRegEx = /\\/g;
  const newlineRegEx = /\n/g;
  const carriageReturnRegEx = /\r/g;
  const tabRegEx = /\t/g;
  const questionRegex = /\?/g;
  const hashRegex = /#/g;
  const spaceRegEx = / /g;
  function encodePathChars(filepath) {
    if (filepath.indexOf('%') !== -1) filepath = filepath.replace(percentRegEx, '%25');
    // In posix, backslash is a valid character in paths:
    if (filepath.indexOf('\\') !== -1) filepath = filepath.replace(backslashRegEx, '%5C');
    if (filepath.indexOf('\n') !== -1) filepath = filepath.replace(newlineRegEx, '%0A');
    if (filepath.indexOf('\r') !== -1) filepath = filepath.replace(carriageReturnRegEx, '%0D');
    if (filepath.indexOf('\t') !== -1) filepath = filepath.replace(tabRegEx, '%09');
    if (filepath.indexOf(' ') !== -1) filepath = filepath.replace(spaceRegEx, '%20');
    return filepath;
  }
  function encodeURLChars(path) {
    let resolved = (0, _path.resolve)(path);
    // path.resolve strips trailing slashes so we must add them back
    const filePathLast = path.charAt(path.length - 1);
    if (filePathLast === '/' && resolved[resolved.length - 1] !== _path.sep) resolved += '/';

    // Call encodePathChars first to avoid encoding % again for ? and #.
    resolved = encodePathChars(resolved);

    // Question and hash character should be included in pathname.
    // Therefore, encoding is required to eliminate parsing them in different states.
    // This is done as an optimization to not creating a URL instance and
    // later triggering pathname setter, which impacts performance
    if (resolved.indexOf('?') !== -1) resolved = resolved.replace(questionRegex, '%3F');
    if (resolved.indexOf('#') !== -1) resolved = resolved.replace(hashRegex, '%23');
    return resolved;
  }
  function isUrl(url) {
    try {
      return !!new URL(url);
    } catch (error) {
      return false;
    }
  }
  function asUrl(url) {
    try {
      const newUrl = new URL(url);
      newUrl.hash = '';
      return newUrl;
    } catch (error) {
      return null;
    }
  }
},3735,[3734],"node_modules/expo-file-system/src/pathUtilities/url.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "FileSystemReadableStreamSource", {
    enumerable: true,
    get: function () {
      return FileSystemReadableStreamSource;
    }
  });
  Object.defineProperty(exports, "FileSystemWritableSink", {
    enumerable: true,
    get: function () {
      return FileSystemWritableSink;
    }
  });
  class FileSystemReadableStreamSource {
    size = 1024;
    type = 'bytes';
    constructor(handle) {
      this.handle = handle;
    }
    cancel() {
      this.handle.close();
    }
    pull(controller) {
      const theView = controller.byobRequest?.view;
      if (!theView) {
        const bytes = this.handle.readBytes(this.size);
        if (bytes.length === 0) {
          controller.close();
          return;
        }
        controller.enqueue(bytes);
        return;
      }

      // TODO: Optimize by adding a native method that can write into a TypedArray at a given offset.
      const bytes = this.handle.readBytes(theView.byteLength - theView.byteOffset);
      if (bytes.length === 0) {
        controller.close();
        controller.byobRequest.respond(0);
        return;
      }
      if (theView instanceof Uint8Array) {
        theView.set(bytes, theView.byteOffset);
      } else {
        const array = new Uint8Array(theView.buffer);
        for (let i = 0; i < bytes.length; i++) {
          array[i + (theView.byteOffset ?? 0)] = bytes[i];
        }
      }
      controller.byobRequest.respond(bytes.length);
    }
  }
  class FileSystemWritableSink {
    constructor(handle) {
      this.handle = handle;
    }
    abort() {
      this.close();
    }
    close() {
      this.handle.close();
    }
    write(chunk) {
      this.handle.writeBytes(chunk);
    }
  }
},3736,[],"node_modules/expo-file-system/src/streams.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.getInfoAsync = getInfoAsync;
  exports.readAsStringAsync = readAsStringAsync;
  exports.getContentUriAsync = getContentUriAsync;
  exports.writeAsStringAsync = writeAsStringAsync;
  exports.deleteAsync = deleteAsync;
  exports.deleteLegacyDocumentDirectoryAndroid = deleteLegacyDocumentDirectoryAndroid;
  exports.moveAsync = moveAsync;
  exports.copyAsync = copyAsync;
  exports.makeDirectoryAsync = makeDirectoryAsync;
  exports.readDirectoryAsync = readDirectoryAsync;
  exports.getFreeDiskStorageAsync = getFreeDiskStorageAsync;
  exports.getTotalDiskCapacityAsync = getTotalDiskCapacityAsync;
  exports.downloadAsync = downloadAsync;
  exports.uploadAsync = uploadAsync;
  exports.createDownloadResumable = createDownloadResumable;
  exports.createUploadTask = createUploadTask;
  function errorOnLegacyMethodUse(methodName) {
    const message = `Method ${methodName} imported from "expo-file-system" is deprecated.\nYou can migrate to the new filesystem API using "File" and "Directory" classes or import the legacy API from "expo-file-system/legacy".\nAPI reference and examples are available in the filesystem docs: https://docs.expo.dev/versions/v54.0.0/sdk/filesystem/`;
    console.warn(message);
    return new Error(message);
  }

  /**
   * @deprecated Use `new File().info` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function getInfoAsync(fileUri, options = {}) {
    throw errorOnLegacyMethodUse('getInfoAsync');
  }

  /**
   * @deprecated Use `new File().text()` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function readAsStringAsync(fileUri, options = {}) {
    throw errorOnLegacyMethodUse('readAsStringAsync');
  }

  /**
   * @deprecated Import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function getContentUriAsync(fileUri) {
    throw errorOnLegacyMethodUse('getContentUriAsync');
  }

  /**
   * @deprecated Use `new File().write()` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function writeAsStringAsync(fileUri, contents, options = {}) {
    throw errorOnLegacyMethodUse('writeAsStringAsync');
  }

  /**
   * @deprecated Use `new File().delete()` or `new Directory().delete()` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function deleteAsync(fileUri, options = {}) {
    throw errorOnLegacyMethodUse('deleteAsync');
  }

  /**
   * @deprecated
   */
  async function deleteLegacyDocumentDirectoryAndroid() {
    throw errorOnLegacyMethodUse('deleteLegacyDocumentDirectoryAndroid');
  }

  /**
   * @deprecated Use `new File().move()` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function moveAsync(options) {
    throw errorOnLegacyMethodUse('moveAsync');
  }

  /**
   * @deprecated Use `new File().copy()` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function copyAsync(options) {
    throw errorOnLegacyMethodUse('copyAsync');
  }

  /**
   * @deprecated Use `new Directory().create()` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function makeDirectoryAsync(fileUri, options = {}) {
    throw errorOnLegacyMethodUse('makeDirectoryAsync');
  }

  /**
   * @deprecated Use `new Directory().list()` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function readDirectoryAsync(fileUri) {
    throw errorOnLegacyMethodUse('readDirectoryAsync');
  }

  /**
   * @deprecated Use `Paths.availableDiskSpace` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function getFreeDiskStorageAsync() {
    throw errorOnLegacyMethodUse('getFreeDiskStorageAsync');
  }

  /**
   * @deprecated Use `Paths.totalDiskSpace` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function getTotalDiskCapacityAsync() {
    throw errorOnLegacyMethodUse('getTotalDiskCapacityAsync');
  }

  /**
   * @deprecated Use `File.downloadFileAsync` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function downloadAsync(uri, fileUri, options = {}) {
    throw errorOnLegacyMethodUse('downloadAsync');
  }

  /**
   * @deprecated Use `@expo/fetch` or import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  async function uploadAsync(url, fileUri, options = {}) {
    throw errorOnLegacyMethodUse('uploadAsync');
  }

  /**
   * @deprecated Import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  function createDownloadResumable(uri, fileUri, options, callback, resumeData) {
    throw errorOnLegacyMethodUse('createDownloadResumable');
  }

  /**
   * @deprecated Import this method from `expo-file-system/legacy`. This method will throw in runtime.
   */
  function createUploadTask(url, fileUri, options, callback) {
    throw errorOnLegacyMethodUse('createUploadTask');
  }
},3737,[],"node_modules/expo-file-system/src/legacyWarnings.ts");
//# sourceMappingURL=http://127.0.0.1:8087/node_modules/expo-file-system/src/index.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false