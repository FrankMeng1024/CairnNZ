__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},8,[],"node_modules/metro-runtime/src/modules/empty-module.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _vendorEmitterEventEmitter = require(_dependencyMap[0], "../vendor/emitter/EventEmitter");
  var EventEmitter = _interopDefault(_vendorEmitterEventEmitter);
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   * @format
   */

  // FIXME: use typed events

  /**
   * Global EventEmitter used by the native platform to emit events to JavaScript.
   * Events are identified by globally unique event names.
   *
   * NativeModules that emit events should instead subclass `NativeEventEmitter`.
   */
  var _default = new EventEmitter.default();
},29,[30],"node_modules/react-native-web/dist/vendor/react-native/EventEmitter/RCTDeviceEventEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return EventEmitter;
    }
  });
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   * @format
   */

  /**
   * EventEmitter manages listeners and publishes events to them.
   *
   * EventEmitter accepts a single type parameter that defines the valid events
   * and associated listener argument(s).
   *
   * @example
   *
   *   const emitter = new EventEmitter<{
   *     success: [number, string],
   *     error: [Error],
   *   }>();
   *
   *   emitter.on('success', (statusCode, responseText) => {...});
   *   emitter.emit('success', 200, '...');
   *
   *   emitter.on('error', error => {...});
   *   emitter.emit('error', new Error('Resource not found'));
   *
   */
  class EventEmitter {
    constructor() {
      this._registry = {};
    }
    /**
     * Registers a listener that is called when the supplied event is emitted.
     * Returns a subscription that has a `remove` method to undo registration.
     */
    addListener(eventType, listener, context) {
      var registrations = allocate(this._registry, eventType);
      var registration = {
        context,
        listener,
        remove() {
          registrations.delete(registration);
        }
      };
      registrations.add(registration);
      return registration;
    }

    /**
     * Emits the supplied event. Additional arguments supplied to `emit` will be
     * passed through to each of the registered listeners.
     *
     * If a listener modifies the listeners registered for the same event, those
     * changes will not be reflected in the current invocation of `emit`.
     */
    emit(eventType) {
      var registrations = this._registry[eventType];
      if (registrations != null) {
        for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          args[_key - 1] = arguments[_key];
        }
        for (var _i = 0, _arr = [...registrations]; _i < _arr.length; _i++) {
          var registration = _arr[_i];
          registration.listener.apply(registration.context, args);
        }
      }
    }

    /**
     * Removes all registered listeners.
     */
    removeAllListeners(eventType) {
      if (eventType == null) {
        this._registry = {};
      } else {
        delete this._registry[eventType];
      }
    }

    /**
     * Returns the number of registered listeners for the supplied event.
     */
    listenerCount(eventType) {
      var registrations = this._registry[eventType];
      return registrations == null ? 0 : registrations.size;
    }
  }
  function allocate(registry, eventType) {
    var registrations = registry[eventType];
    if (registrations == null) {
      registrations = new Set();
      registry[eventType] = registrations;
    }
    return registrations;
  }
},30,[],"node_modules/react-native-web/dist/vendor/react-native/vendor/emitter/EventEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  'use strict';

  var validateFormat = process.env.NODE_ENV !== "production" ? function (format) {
    if (format === undefined) {
      throw new Error('invariant(...): Second argument must be a string.');
    }
  } : function (format) {};
  /**
   * Use invariant() to assert state which your program assumes to be true.
   *
   * Provide sprintf-style format (only %s is supported) and arguments to provide
   * information about what broke and what you were expecting.
   *
   * The invariant message will be stripped in production, but the invariant will
   * remain to ensure logic does not differ in production.
   */

  function invariant(condition, format) {
    for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
      args[_key - 2] = arguments[_key];
    }
    validateFormat(format);
    if (!condition) {
      var error;
      if (format === undefined) {
        error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
      } else {
        var argIndex = 0;
        error = new Error(format.replace(/%s/g, function () {
          return String(args[argIndex++]);
        }));
        error.name = 'Invariant Violation';
      }
      error.framesToPop = 1; // Skip invariant's own stack frame.

      throw error;
    }
  }
  module.exports = invariant;
},52,[],"node_modules/fbjs/lib/invariant.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  if (process.env.NODE_ENV === 'production') {
    module.exports = require(_dependencyMap[0], "./cjs/react.production.js");
  } else {
    module.exports = require(_dependencyMap[1], "./cjs/react.development.js");
  }
},62,[8,63],"node_modules/react/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * @license React
   * react.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  "use strict";

  "production" !== process.env.NODE_ENV && function () {
    function defineDeprecationWarning(methodName, info) {
      Object.defineProperty(Component.prototype, methodName, {
        get: function () {
          console.warn("%s(...) is deprecated in plain JavaScript React classes. %s", info[0], info[1]);
        }
      });
    }
    function getIteratorFn(maybeIterable) {
      if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
      maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
      return "function" === typeof maybeIterable ? maybeIterable : null;
    }
    function warnNoop(publicInstance, callerName) {
      publicInstance = (publicInstance = publicInstance.constructor) && (publicInstance.displayName || publicInstance.name) || "ReactClass";
      var warningKey = publicInstance + "." + callerName;
      didWarnStateUpdateForUnmountedComponent[warningKey] || (console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", callerName, publicInstance), didWarnStateUpdateForUnmountedComponent[warningKey] = !0);
    }
    function Component(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function ComponentDummy() {}
    function PureComponent(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function testStringCoercion(value) {
      return "" + value;
    }
    function checkKeyStringCoercion(value) {
      try {
        testStringCoercion(value);
        var JSCompiler_inline_result = !1;
      } catch (e) {
        JSCompiler_inline_result = !0;
      }
      if (JSCompiler_inline_result) {
        JSCompiler_inline_result = console;
        var JSCompiler_temp_const = JSCompiler_inline_result.error;
        var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
        JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
        return testStringCoercion(value);
      }
    }
    function getComponentNameFromType(type) {
      if (null == type) return null;
      if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
      if ("string" === typeof type) return type;
      switch (type) {
        case REACT_FRAGMENT_TYPE:
          return "Fragment";
        case REACT_PROFILER_TYPE:
          return "Profiler";
        case REACT_STRICT_MODE_TYPE:
          return "StrictMode";
        case REACT_SUSPENSE_TYPE:
          return "Suspense";
        case REACT_SUSPENSE_LIST_TYPE:
          return "SuspenseList";
        case REACT_ACTIVITY_TYPE:
          return "Activity";
      }
      if ("object" === typeof type) switch ("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof) {
        case REACT_PORTAL_TYPE:
          return "Portal";
        case REACT_CONTEXT_TYPE:
          return (type.displayName || "Context") + ".Provider";
        case REACT_CONSUMER_TYPE:
          return (type._context.displayName || "Context") + ".Consumer";
        case REACT_FORWARD_REF_TYPE:
          var innerType = type.render;
          type = type.displayName;
          type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
          return type;
        case REACT_MEMO_TYPE:
          return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
        case REACT_LAZY_TYPE:
          innerType = type._payload;
          type = type._init;
          try {
            return getComponentNameFromType(type(innerType));
          } catch (x) {}
      }
      return null;
    }
    function getTaskName(type) {
      if (type === REACT_FRAGMENT_TYPE) return "<>";
      if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
      try {
        var name = getComponentNameFromType(type);
        return name ? "<" + name + ">" : "<...>";
      } catch (x) {
        return "<...>";
      }
    }
    function getOwner() {
      var dispatcher = ReactSharedInternals.A;
      return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
      return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
      if (hasOwnProperty.call(config, "key")) {
        var getter = Object.getOwnPropertyDescriptor(config, "key").get;
        if (getter && getter.isReactWarning) return !1;
      }
      return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
      function warnAboutAccessingKey() {
        specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
      }
      warnAboutAccessingKey.isReactWarning = !0;
      Object.defineProperty(props, "key", {
        get: warnAboutAccessingKey,
        configurable: !0
      });
    }
    function elementRefGetterWithDeprecationWarning() {
      var componentName = getComponentNameFromType(this.type);
      didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
      componentName = this.props.ref;
      return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, self, source, owner, props, debugStack, debugTask) {
      self = props.ref;
      type = {
        $$typeof: REACT_ELEMENT_TYPE,
        type: type,
        key: key,
        props: props,
        _owner: owner
      };
      null !== (void 0 !== self ? self : null) ? Object.defineProperty(type, "ref", {
        enumerable: !1,
        get: elementRefGetterWithDeprecationWarning
      }) : Object.defineProperty(type, "ref", {
        enumerable: !1,
        value: null
      });
      type._store = {};
      Object.defineProperty(type._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: 0
      });
      Object.defineProperty(type, "_debugInfo", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: null
      });
      Object.defineProperty(type, "_debugStack", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugStack
      });
      Object.defineProperty(type, "_debugTask", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugTask
      });
      Object.freeze && (Object.freeze(type.props), Object.freeze(type));
      return type;
    }
    function cloneAndReplaceKey(oldElement, newKey) {
      newKey = ReactElement(oldElement.type, newKey, void 0, void 0, oldElement._owner, oldElement.props, oldElement._debugStack, oldElement._debugTask);
      oldElement._store && (newKey._store.validated = oldElement._store.validated);
      return newKey;
    }
    function isValidElement(object) {
      return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    function escape(key) {
      var escaperLookup = {
        "=": "=0",
        ":": "=2"
      };
      return "$" + key.replace(/[=:]/g, function (match) {
        return escaperLookup[match];
      });
    }
    function getElementKey(element, index) {
      return "object" === typeof element && null !== element && null != element.key ? (checkKeyStringCoercion(element.key), escape("" + element.key)) : index.toString(36);
    }
    function noop$1() {}
    function resolveThenable(thenable) {
      switch (thenable.status) {
        case "fulfilled":
          return thenable.value;
        case "rejected":
          throw thenable.reason;
        default:
          switch ("string" === typeof thenable.status ? thenable.then(noop$1, noop$1) : (thenable.status = "pending", thenable.then(function (fulfilledValue) {
            "pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
          }, function (error) {
            "pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
          })), thenable.status) {
            case "fulfilled":
              return thenable.value;
            case "rejected":
              throw thenable.reason;
          }
      }
      throw thenable;
    }
    function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
      var type = typeof children;
      if ("undefined" === type || "boolean" === type) children = null;
      var invokeCallback = !1;
      if (null === children) invokeCallback = !0;else switch (type) {
        case "bigint":
        case "string":
        case "number":
          invokeCallback = !0;
          break;
        case "object":
          switch (children.$$typeof) {
            case REACT_ELEMENT_TYPE:
            case REACT_PORTAL_TYPE:
              invokeCallback = !0;
              break;
            case REACT_LAZY_TYPE:
              return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
          }
      }
      if (invokeCallback) {
        invokeCallback = children;
        callback = callback(invokeCallback);
        var childKey = "" === nameSoFar ? "." + getElementKey(invokeCallback, 0) : nameSoFar;
        isArrayImpl(callback) ? (escapedPrefix = "", null != childKey && (escapedPrefix = childKey.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function (c) {
          return c;
        })) : null != callback && (isValidElement(callback) && (null != callback.key && (invokeCallback && invokeCallback.key === callback.key || checkKeyStringCoercion(callback.key)), escapedPrefix = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || invokeCallback && invokeCallback.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + childKey), "" !== nameSoFar && null != invokeCallback && isValidElement(invokeCallback) && null == invokeCallback.key && invokeCallback._store && !invokeCallback._store.validated && (escapedPrefix._store.validated = 2), callback = escapedPrefix), array.push(callback));
        return 1;
      }
      invokeCallback = 0;
      childKey = "" === nameSoFar ? "." : nameSoFar + ":";
      if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = childKey + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if (i = getIteratorFn(children), "function" === typeof i) for (i === children.entries && (didWarnAboutMaps || console.warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), didWarnAboutMaps = !0), children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = childKey + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if ("object" === type) {
        if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
        array = String(children);
        throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
      }
      return invokeCallback;
    }
    function mapChildren(children, func, context) {
      if (null == children) return children;
      var result = [],
        count = 0;
      mapIntoArray(children, result, "", "", function (child) {
        return func.call(context, child, count++);
      });
      return result;
    }
    function lazyInitializer(payload) {
      if (-1 === payload._status) {
        var ctor = payload._result;
        ctor = ctor();
        ctor.then(function (moduleObject) {
          if (0 === payload._status || -1 === payload._status) payload._status = 1, payload._result = moduleObject;
        }, function (error) {
          if (0 === payload._status || -1 === payload._status) payload._status = 2, payload._result = error;
        });
        -1 === payload._status && (payload._status = 0, payload._result = ctor);
      }
      if (1 === payload._status) return ctor = payload._result, void 0 === ctor && console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))\n\nDid you accidentally put curly braces around the import?", ctor), "default" in ctor || console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))", ctor), ctor.default;
      throw payload._result;
    }
    function resolveDispatcher() {
      var dispatcher = ReactSharedInternals.H;
      null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
      return dispatcher;
    }
    function noop() {}
    function enqueueTask(task) {
      if (null === enqueueTaskImpl) try {
        var requireString = ("require" + Math.random()).slice(0, 7);
        enqueueTaskImpl = (module && module[requireString]).call(module, "timers").setImmediate;
      } catch (_err) {
        enqueueTaskImpl = function (callback) {
          !1 === didWarnAboutMessageChannel && (didWarnAboutMessageChannel = !0, "undefined" === typeof MessageChannel && console.error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
          var channel = new MessageChannel();
          channel.port1.onmessage = callback;
          channel.port2.postMessage(void 0);
        };
      }
      return enqueueTaskImpl(task);
    }
    function aggregateErrors(errors) {
      return 1 < errors.length && "function" === typeof AggregateError ? new AggregateError(errors) : errors[0];
    }
    function popActScope(prevActQueue, prevActScopeDepth) {
      prevActScopeDepth !== actScopeDepth - 1 && console.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
      actScopeDepth = prevActScopeDepth;
    }
    function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
      var queue = ReactSharedInternals.actQueue;
      if (null !== queue) if (0 !== queue.length) try {
        flushActQueue(queue);
        enqueueTask(function () {
          return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
        });
        return;
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      } else ReactSharedInternals.actQueue = null;
      0 < ReactSharedInternals.thrownErrors.length ? (queue = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(queue)) : resolve(returnValue);
    }
    function flushActQueue(queue) {
      if (!isFlushing) {
        isFlushing = !0;
        var i = 0;
        try {
          for (; i < queue.length; i++) {
            var callback = queue[i];
            do {
              ReactSharedInternals.didUsePromise = !1;
              var continuation = callback(!1);
              if (null !== continuation) {
                if (ReactSharedInternals.didUsePromise) {
                  queue[i] = callback;
                  queue.splice(0, i);
                  return;
                }
                callback = continuation;
              } else break;
            } while (1);
          }
          queue.length = 0;
        } catch (error) {
          queue.splice(0, i + 1), ReactSharedInternals.thrownErrors.push(error);
        } finally {
          isFlushing = !1;
        }
      }
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
      REACT_PORTAL_TYPE = Symbol.for("react.portal"),
      REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"),
      REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"),
      REACT_PROFILER_TYPE = Symbol.for("react.profiler");
    Symbol.for("react.provider");
    var REACT_CONSUMER_TYPE = Symbol.for("react.consumer"),
      REACT_CONTEXT_TYPE = Symbol.for("react.context"),
      REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"),
      REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"),
      REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"),
      REACT_MEMO_TYPE = Symbol.for("react.memo"),
      REACT_LAZY_TYPE = Symbol.for("react.lazy"),
      REACT_ACTIVITY_TYPE = Symbol.for("react.activity"),
      MAYBE_ITERATOR_SYMBOL = Symbol.iterator,
      didWarnStateUpdateForUnmountedComponent = {},
      ReactNoopUpdateQueue = {
        isMounted: function () {
          return !1;
        },
        enqueueForceUpdate: function (publicInstance) {
          warnNoop(publicInstance, "forceUpdate");
        },
        enqueueReplaceState: function (publicInstance) {
          warnNoop(publicInstance, "replaceState");
        },
        enqueueSetState: function (publicInstance) {
          warnNoop(publicInstance, "setState");
        }
      },
      assign = Object.assign,
      emptyObject = {};
    Object.freeze(emptyObject);
    Component.prototype.isReactComponent = {};
    Component.prototype.setState = function (partialState, callback) {
      if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, partialState, callback, "setState");
    };
    Component.prototype.forceUpdate = function (callback) {
      this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
    };
    var deprecatedAPIs = {
        isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
        replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
      },
      fnName;
    for (fnName in deprecatedAPIs) deprecatedAPIs.hasOwnProperty(fnName) && defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
    ComponentDummy.prototype = Component.prototype;
    deprecatedAPIs = PureComponent.prototype = new ComponentDummy();
    deprecatedAPIs.constructor = PureComponent;
    assign(deprecatedAPIs, Component.prototype);
    deprecatedAPIs.isPureReactComponent = !0;
    var isArrayImpl = Array.isArray,
      REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"),
      ReactSharedInternals = {
        H: null,
        A: null,
        T: null,
        S: null,
        V: null,
        actQueue: null,
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1,
        didUsePromise: !1,
        thrownErrors: [],
        getCurrentStack: null,
        recentlyCreatedOwnerStacks: 0
      },
      hasOwnProperty = Object.prototype.hasOwnProperty,
      createTask = console.createTask ? console.createTask : function () {
        return null;
      };
    deprecatedAPIs = {
      "react-stack-bottom-frame": function (callStackForError) {
        return callStackForError();
      }
    };
    var specialPropKeyWarningShown, didWarnAboutOldJSXRuntime;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = deprecatedAPIs["react-stack-bottom-frame"].bind(deprecatedAPIs, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutMaps = !1,
      userProvidedKeyEscapeRegex = /\/+/g,
      reportGlobalError = "function" === typeof reportError ? reportError : function (error) {
        if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
          var event = new window.ErrorEvent("error", {
            bubbles: !0,
            cancelable: !0,
            message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
            error: error
          });
          if (!window.dispatchEvent(event)) return;
        } else if ("object" === typeof process && "function" === typeof process.emit) {
          process.emit("uncaughtException", error);
          return;
        }
        console.error(error);
      },
      didWarnAboutMessageChannel = !1,
      enqueueTaskImpl = null,
      actScopeDepth = 0,
      didWarnNoAwaitAct = !1,
      isFlushing = !1,
      queueSeveralMicrotasks = "function" === typeof queueMicrotask ? function (callback) {
        queueMicrotask(function () {
          return queueMicrotask(callback);
        });
      } : enqueueTask;
    deprecatedAPIs = Object.freeze({
      __proto__: null,
      c: function (size) {
        return resolveDispatcher().useMemoCache(size);
      }
    });
    exports.Children = {
      map: mapChildren,
      forEach: function (children, forEachFunc, forEachContext) {
        mapChildren(children, function () {
          forEachFunc.apply(this, arguments);
        }, forEachContext);
      },
      count: function (children) {
        var n = 0;
        mapChildren(children, function () {
          n++;
        });
        return n;
      },
      toArray: function (children) {
        return mapChildren(children, function (child) {
          return child;
        }) || [];
      },
      only: function (children) {
        if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
        return children;
      }
    };
    exports.Component = Component;
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.Profiler = REACT_PROFILER_TYPE;
    exports.PureComponent = PureComponent;
    exports.StrictMode = REACT_STRICT_MODE_TYPE;
    exports.Suspense = REACT_SUSPENSE_TYPE;
    exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
    exports.__COMPILER_RUNTIME = deprecatedAPIs;
    exports.act = function (callback) {
      var prevActQueue = ReactSharedInternals.actQueue,
        prevActScopeDepth = actScopeDepth;
      actScopeDepth++;
      var queue = ReactSharedInternals.actQueue = null !== prevActQueue ? prevActQueue : [],
        didAwaitActCall = !1;
      try {
        var result = callback();
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      }
      if (0 < ReactSharedInternals.thrownErrors.length) throw popActScope(prevActQueue, prevActScopeDepth), callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      if (null !== result && "object" === typeof result && "function" === typeof result.then) {
        var thenable = result;
        queueSeveralMicrotasks(function () {
          didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
        });
        return {
          then: function (resolve, reject) {
            didAwaitActCall = !0;
            thenable.then(function (returnValue) {
              popActScope(prevActQueue, prevActScopeDepth);
              if (0 === prevActScopeDepth) {
                try {
                  flushActQueue(queue), enqueueTask(function () {
                    return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
                  });
                } catch (error$0) {
                  ReactSharedInternals.thrownErrors.push(error$0);
                }
                if (0 < ReactSharedInternals.thrownErrors.length) {
                  var _thrownError = aggregateErrors(ReactSharedInternals.thrownErrors);
                  ReactSharedInternals.thrownErrors.length = 0;
                  reject(_thrownError);
                }
              } else resolve(returnValue);
            }, function (error) {
              popActScope(prevActQueue, prevActScopeDepth);
              0 < ReactSharedInternals.thrownErrors.length ? (error = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(error)) : reject(error);
            });
          }
        };
      }
      var returnValue$jscomp$0 = result;
      popActScope(prevActQueue, prevActScopeDepth);
      0 === prevActScopeDepth && (flushActQueue(queue), 0 !== queue.length && queueSeveralMicrotasks(function () {
        didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"));
      }), ReactSharedInternals.actQueue = null);
      if (0 < ReactSharedInternals.thrownErrors.length) throw callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      return {
        then: function (resolve, reject) {
          didAwaitActCall = !0;
          0 === prevActScopeDepth ? (ReactSharedInternals.actQueue = queue, enqueueTask(function () {
            return recursivelyFlushAsyncActWork(returnValue$jscomp$0, resolve, reject);
          })) : resolve(returnValue$jscomp$0);
        }
      };
    };
    exports.cache = function (fn) {
      return function () {
        return fn.apply(null, arguments);
      };
    };
    exports.captureOwnerStack = function () {
      var getCurrentStack = ReactSharedInternals.getCurrentStack;
      return null === getCurrentStack ? null : getCurrentStack();
    };
    exports.cloneElement = function (element, config, children) {
      if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
      var props = assign({}, element.props),
        key = element.key,
        owner = element._owner;
      if (null != config) {
        var JSCompiler_inline_result;
        a: {
          if (hasOwnProperty.call(config, "ref") && (JSCompiler_inline_result = Object.getOwnPropertyDescriptor(config, "ref").get) && JSCompiler_inline_result.isReactWarning) {
            JSCompiler_inline_result = !1;
            break a;
          }
          JSCompiler_inline_result = void 0 !== config.ref;
        }
        JSCompiler_inline_result && (owner = getOwner());
        hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key);
        for (propName in config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
      }
      var propName = arguments.length - 2;
      if (1 === propName) props.children = children;else if (1 < propName) {
        JSCompiler_inline_result = Array(propName);
        for (var i = 0; i < propName; i++) JSCompiler_inline_result[i] = arguments[i + 2];
        props.children = JSCompiler_inline_result;
      }
      props = ReactElement(element.type, key, void 0, void 0, owner, props, element._debugStack, element._debugTask);
      for (key = 2; key < arguments.length; key++) owner = arguments[key], isValidElement(owner) && owner._store && (owner._store.validated = 1);
      return props;
    };
    exports.createContext = function (defaultValue) {
      defaultValue = {
        $$typeof: REACT_CONTEXT_TYPE,
        _currentValue: defaultValue,
        _currentValue2: defaultValue,
        _threadCount: 0,
        Provider: null,
        Consumer: null
      };
      defaultValue.Provider = defaultValue;
      defaultValue.Consumer = {
        $$typeof: REACT_CONSUMER_TYPE,
        _context: defaultValue
      };
      defaultValue._currentRenderer = null;
      defaultValue._currentRenderer2 = null;
      return defaultValue;
    };
    exports.createElement = function (type, config, children) {
      for (var i = 2; i < arguments.length; i++) {
        var node = arguments[i];
        isValidElement(node) && node._store && (node._store.validated = 1);
      }
      i = {};
      node = null;
      if (null != config) for (propName in didWarnAboutOldJSXRuntime || !("__self" in config) || "key" in config || (didWarnAboutOldJSXRuntime = !0, console.warn("Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform")), hasValidKey(config) && (checkKeyStringCoercion(config.key), node = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (i[propName] = config[propName]);
      var childrenLength = arguments.length - 2;
      if (1 === childrenLength) i.children = children;else if (1 < childrenLength) {
        for (var childArray = Array(childrenLength), _i = 0; _i < childrenLength; _i++) childArray[_i] = arguments[_i + 2];
        Object.freeze && Object.freeze(childArray);
        i.children = childArray;
      }
      if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === i[propName] && (i[propName] = childrenLength[propName]);
      node && defineKeyPropWarningGetter(i, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
      var propName = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
      return ReactElement(type, node, void 0, void 0, getOwner(), i, propName ? Error("react-stack-top-frame") : unknownOwnerDebugStack, propName ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
    exports.createRef = function () {
      var refObject = {
        current: null
      };
      Object.seal(refObject);
      return refObject;
    };
    exports.forwardRef = function (render) {
      null != render && render.$$typeof === REACT_MEMO_TYPE ? console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : "function" !== typeof render ? console.error("forwardRef requires a render function but was given %s.", null === render ? "null" : typeof render) : 0 !== render.length && 2 !== render.length && console.error("forwardRef render functions accept exactly two parameters: props and ref. %s", 1 === render.length ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined.");
      null != render && null != render.defaultProps && console.error("forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?");
      var elementType = {
          $$typeof: REACT_FORWARD_REF_TYPE,
          render: render
        },
        ownName;
      Object.defineProperty(elementType, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          render.name || render.displayName || (Object.defineProperty(render, "name", {
            value: name
          }), render.displayName = name);
        }
      });
      return elementType;
    };
    exports.isValidElement = isValidElement;
    exports.lazy = function (ctor) {
      return {
        $$typeof: REACT_LAZY_TYPE,
        _payload: {
          _status: -1,
          _result: ctor
        },
        _init: lazyInitializer
      };
    };
    exports.memo = function (type, compare) {
      null == type && console.error("memo: The first argument must be a component. Instead received: %s", null === type ? "null" : typeof type);
      compare = {
        $$typeof: REACT_MEMO_TYPE,
        type: type,
        compare: void 0 === compare ? null : compare
      };
      var ownName;
      Object.defineProperty(compare, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          type.name || type.displayName || (Object.defineProperty(type, "name", {
            value: name
          }), type.displayName = name);
        }
      });
      return compare;
    };
    exports.startTransition = function (scope) {
      var prevTransition = ReactSharedInternals.T,
        currentTransition = {};
      ReactSharedInternals.T = currentTransition;
      currentTransition._updatedFibers = new Set();
      try {
        var returnValue = scope(),
          onStartTransitionFinish = ReactSharedInternals.S;
        null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
        "object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && returnValue.then(noop, reportGlobalError);
      } catch (error) {
        reportGlobalError(error);
      } finally {
        null === prevTransition && currentTransition._updatedFibers && (scope = currentTransition._updatedFibers.size, currentTransition._updatedFibers.clear(), 10 < scope && console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.")), ReactSharedInternals.T = prevTransition;
      }
    };
    exports.unstable_useCacheRefresh = function () {
      return resolveDispatcher().useCacheRefresh();
    };
    exports.use = function (usable) {
      return resolveDispatcher().use(usable);
    };
    exports.useActionState = function (action, initialState, permalink) {
      return resolveDispatcher().useActionState(action, initialState, permalink);
    };
    exports.useCallback = function (callback, deps) {
      return resolveDispatcher().useCallback(callback, deps);
    };
    exports.useContext = function (Context) {
      var dispatcher = resolveDispatcher();
      Context.$$typeof === REACT_CONSUMER_TYPE && console.error("Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?");
      return dispatcher.useContext(Context);
    };
    exports.useDebugValue = function (value, formatterFn) {
      return resolveDispatcher().useDebugValue(value, formatterFn);
    };
    exports.useDeferredValue = function (value, initialValue) {
      return resolveDispatcher().useDeferredValue(value, initialValue);
    };
    exports.useEffect = function (create, createDeps, update) {
      null == create && console.warn("React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      var dispatcher = resolveDispatcher();
      if ("function" === typeof update) throw Error("useEffect CRUD overload is not enabled in this build of React.");
      return dispatcher.useEffect(create, createDeps);
    };
    exports.useId = function () {
      return resolveDispatcher().useId();
    };
    exports.useImperativeHandle = function (ref, create, deps) {
      return resolveDispatcher().useImperativeHandle(ref, create, deps);
    };
    exports.useInsertionEffect = function (create, deps) {
      null == create && console.warn("React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useInsertionEffect(create, deps);
    };
    exports.useLayoutEffect = function (create, deps) {
      null == create && console.warn("React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useLayoutEffect(create, deps);
    };
    exports.useMemo = function (create, deps) {
      return resolveDispatcher().useMemo(create, deps);
    };
    exports.useOptimistic = function (passthrough, reducer) {
      return resolveDispatcher().useOptimistic(passthrough, reducer);
    };
    exports.useReducer = function (reducer, initialArg, init) {
      return resolveDispatcher().useReducer(reducer, initialArg, init);
    };
    exports.useRef = function (initialValue) {
      return resolveDispatcher().useRef(initialValue);
    };
    exports.useState = function (initialState) {
      return resolveDispatcher().useState(initialState);
    };
    exports.useSyncExternalStore = function (subscribe, getSnapshot, getServerSnapshot) {
      return resolveDispatcher().useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
    };
    exports.useTransition = function () {
      return resolveDispatcher().useTransition();
    };
    exports.version = "19.1.0";
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
  }();
},63,[],"node_modules/react/cjs/react.development.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var Platform = {
    OS: 'web',
    select: obj => 'web' in obj ? obj.web : obj.default,
    get isTesting() {
      if (process.env.NODE_ENV === 'test') {
        return true;
      }
      return false;
    },
    get Version() {
      return '0.0.0';
    }
  };
  var _default = Platform;
},123,[],"node_modules/react-native-web/dist/exports/Platform/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _vendorReactNativeEventEmitterNativeEventEmitter = require(_dependencyMap[0], "../../vendor/react-native/EventEmitter/NativeEventEmitter");
  var NativeEventEmitter = _interopDefault(_vendorReactNativeEventEmitterNativeEventEmitter);
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var _default = NativeEventEmitter.default;
},126,[127],"node_modules/react-native-web/dist/exports/NativeEventEmitter/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   * @format
   */

  'use strict';

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return NativeEventEmitter;
    }
  });
  var _exportsPlatform = require(_dependencyMap[0], "../../../exports/Platform");
  var Platform = _interopDefault(_exportsPlatform);
  var _RCTDeviceEventEmitter = require(_dependencyMap[1], "./RCTDeviceEventEmitter");
  var RCTDeviceEventEmitter = _interopDefault(_RCTDeviceEventEmitter);
  var _fbjsLibInvariant = require(_dependencyMap[2], "fbjs/lib/invariant");
  var invariant = _interopDefault(_fbjsLibInvariant);
  /**
   * `NativeEventEmitter` is intended for use by Native Modules to emit events to
   * JavaScript listeners. If a `NativeModule` is supplied to the constructor, it
   * will be notified (via `addListener` and `removeListeners`) when the listener
   * count changes to manage "native memory".
   *
   * Currently, all native events are fired via a global `RCTDeviceEventEmitter`.
   * This means event names must be globally unique, and it means that call sites
   * can theoretically listen to `RCTDeviceEventEmitter` (although discouraged).
   */
  class NativeEventEmitter {
    constructor(nativeModule) {
      if (Platform.default.OS === 'ios') {
        (0, invariant.default)(nativeModule != null, '`new NativeEventEmitter()` requires a non-null argument.');
        this._nativeModule = nativeModule;
      }
    }
    addListener(eventType, listener, context) {
      var _this$_nativeModule;
      (_this$_nativeModule = this._nativeModule) == null ? void 0 : _this$_nativeModule.addListener(eventType);
      var subscription = RCTDeviceEventEmitter.default.addListener(eventType, listener, context);
      return {
        remove: () => {
          if (subscription != null) {
            var _this$_nativeModule2;
            (_this$_nativeModule2 = this._nativeModule) == null ? void 0 : _this$_nativeModule2.removeListeners(1);
            // $FlowFixMe[incompatible-use]
            subscription.remove();
            subscription = null;
          }
        }
      };
    }

    /**
     * @deprecated Use `remove` on the EventSubscription from `addListener`.
     */
    removeListener(eventType, listener) {
      var _this$_nativeModule3;
      (_this$_nativeModule3 = this._nativeModule) == null ? void 0 : _this$_nativeModule3.removeListeners(1);
      // NOTE: This will report a deprecation notice via `console.error`.
      // $FlowFixMe[prop-missing] - `removeListener` exists but is deprecated.
      RCTDeviceEventEmitter.default.removeListener(eventType, listener);
    }
    emit(eventType) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      // Generally, `RCTDeviceEventEmitter` is directly invoked. But this is
      // included for completeness.
      RCTDeviceEventEmitter.default.emit(eventType, ...args);
    }
    removeAllListeners(eventType) {
      var _this$_nativeModule4;
      (0, invariant.default)(eventType != null, '`NativeEventEmitter.removeAllListener()` requires a non-null argument.');
      (_this$_nativeModule4 = this._nativeModule) == null ? void 0 : _this$_nativeModule4.removeListeners(this.listenerCount(eventType));
      RCTDeviceEventEmitter.default.removeAllListeners(eventType);
    }
    listenerCount(eventType) {
      return RCTDeviceEventEmitter.default.listenerCount(eventType);
    }
  }
},127,[123,29,52],"node_modules/react-native-web/dist/vendor/react-native/EventEmitter/NativeEventEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "EventEmitter", {
    enumerable: true,
    get: function () {
      return _EventEmitter.EventEmitter;
    }
  });
  Object.defineProperty(exports, "NativeModule", {
    enumerable: true,
    get: function () {
      return _NativeModule.NativeModule;
    }
  });
  Object.defineProperty(exports, "SharedObject", {
    enumerable: true,
    get: function () {
      return _SharedObject.SharedObject;
    }
  });
  Object.defineProperty(exports, "SharedRef", {
    enumerable: true,
    get: function () {
      return _SharedRef.SharedRef;
    }
  });
  Object.defineProperty(exports, "Platform", {
    enumerable: true,
    get: function () {
      return _Platform2.default;
    }
  });
  Object.defineProperty(exports, "uuid", {
    enumerable: true,
    get: function () {
      return _uuid2.default;
    }
  });
  Object.defineProperty(exports, "requireNativeViewManager", {
    enumerable: true,
    get: function () {
      return _NativeViewManagerAdapter.requireNativeViewManager;
    }
  });
  Object.defineProperty(exports, "CodedError", {
    enumerable: true,
    get: function () {
      return _errorsCodedError.CodedError;
    }
  });
  Object.defineProperty(exports, "UnavailabilityError", {
    enumerable: true,
    get: function () {
      return _errorsUnavailabilityError.UnavailabilityError;
    }
  });
  Object.defineProperty(exports, "LegacyEventEmitter", {
    enumerable: true,
    get: function () {
      return _LegacyEventEmitter.LegacyEventEmitter;
    }
  });
  Object.defineProperty(exports, "NativeModulesProxy", {
    enumerable: true,
    get: function () {
      return _NativeModulesProxy2.default;
    }
  });
  require(_dependencyMap[0], "./sweet/setUpJsLogger.fx");
  require(_dependencyMap[1], "./polyfill");
  var _EventEmitter = require(_dependencyMap[2], "./EventEmitter");
  var _NativeModule = require(_dependencyMap[3], "./NativeModule");
  var _SharedObject = require(_dependencyMap[4], "./SharedObject");
  var _SharedRef = require(_dependencyMap[5], "./SharedRef");
  var _Platform = require(_dependencyMap[6], "./Platform");
  var _Platform2 = _interopDefault(_Platform);
  var _uuid = require(_dependencyMap[7], "./uuid");
  var _uuid2 = _interopDefault(_uuid);
  var _NativeViewManagerAdapter = require(_dependencyMap[8], "./NativeViewManagerAdapter");
  var _requireNativeModule = require(_dependencyMap[9], "./requireNativeModule");
  Object.keys(_requireNativeModule).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _requireNativeModule[k];
        }
      });
    }
  });
  var _registerWebModule = require(_dependencyMap[10], "./registerWebModule");
  Object.keys(_registerWebModule).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _registerWebModule[k];
        }
      });
    }
  });
  var _TypedArraysTypes = require(_dependencyMap[11], "./TypedArrays.types");
  Object.keys(_TypedArraysTypes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _TypedArraysTypes[k];
        }
      });
    }
  });
  var _PermissionsInterface = require(_dependencyMap[12], "./PermissionsInterface");
  Object.keys(_PermissionsInterface).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _PermissionsInterface[k];
        }
      });
    }
  });
  var _PermissionsHook = require(_dependencyMap[13], "./PermissionsHook");
  Object.keys(_PermissionsHook).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _PermissionsHook[k];
        }
      });
    }
  });
  var _Refs = require(_dependencyMap[14], "./Refs");
  Object.keys(_Refs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _Refs[k];
        }
      });
    }
  });
  var _hooksUseReleasingSharedObject = require(_dependencyMap[15], "./hooks/useReleasingSharedObject");
  Object.keys(_hooksUseReleasingSharedObject).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _hooksUseReleasingSharedObject[k];
        }
      });
    }
  });
  var _reload = require(_dependencyMap[16], "./reload");
  Object.keys(_reload).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _reload[k];
        }
      });
    }
  });
  var _errorsCodedError = require(_dependencyMap[17], "./errors/CodedError");
  var _errorsUnavailabilityError = require(_dependencyMap[18], "./errors/UnavailabilityError");
  var _LegacyEventEmitter = require(_dependencyMap[19], "./LegacyEventEmitter");
  var _NativeModulesProxy = require(_dependencyMap[20], "./NativeModulesProxy");
  var _NativeModulesProxy2 = _interopDefault(_NativeModulesProxy);
},131,[132,133,146,148,149,150,151,136,153,156,157,158,159,160,161,162,163,155,154,164,166],"node_modules/expo-modules-core/src/index.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {},132,[],"node_modules/expo-modules-core/src/sweet/setUpJsLogger.fx.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var _dangerousInternal = require(_dependencyMap[0], "./dangerous-internal");
  (0, _dangerousInternal.installExpoGlobalPolyfill)();
},133,[134],"node_modules/expo-modules-core/src/polyfill/index.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.installExpoGlobalPolyfill = installExpoGlobalPolyfill;
  var _CoreModule = require(_dependencyMap[0], "./CoreModule");
  var _uuidIndexWeb = require(_dependencyMap[1], "../uuid/index.web");
  var uuid = _interopDefault(_uuidIndexWeb);
  var _tsDeclarationsGlobal = require(_dependencyMap[2], "../ts-declarations/global");
  Object.keys(_tsDeclarationsGlobal).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _tsDeclarationsGlobal[k];
        }
      });
    }
  });
  // jest-expo imports to this file directly without going through the global types
  // Exporting the types to let jest-expo to know the globalThis types

  function installExpoGlobalPolyfill() {
    if (globalThis.expo) return;
    globalThis.expo = {
      EventEmitter: _CoreModule.EventEmitter,
      NativeModule: _CoreModule.NativeModule,
      SharedObject: _CoreModule.SharedObject,
      SharedRef: _CoreModule.SharedRef,
      modules: globalThis.ExpoDomWebView?.expoModulesProxy ?? {},
      uuidv4: uuid.default.v4,
      uuidv5: uuid.default.v5,
      getViewConfig: () => {
        throw new Error('Method not implemented.');
      },
      reloadAppAsync: async () => {
        window.location.reload();
      },
      expoModulesCoreVersion: undefined,
      cacheDir: undefined,
      documentsDir: undefined
    };
  }
},134,[135,136,141],"node_modules/expo-modules-core/src/polyfill/dangerous-internal.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "EventEmitter", {
    enumerable: true,
    get: function () {
      return EventEmitter;
    }
  });
  Object.defineProperty(exports, "NativeModule", {
    enumerable: true,
    get: function () {
      return NativeModule;
    }
  });
  Object.defineProperty(exports, "SharedObject", {
    enumerable: true,
    get: function () {
      return SharedObject;
    }
  });
  Object.defineProperty(exports, "SharedRef", {
    enumerable: true,
    get: function () {
      return SharedRef;
    }
  });
  class EventEmitter {
    addListener(eventName, listener) {
      if (!this.listeners) {
        this.listeners = new Map();
      }
      if (!this.listeners?.has(eventName)) {
        this.listeners?.set(eventName, new Set());
      }
      const previousListenerCount = this.listenerCount(eventName);
      this.listeners?.get(eventName)?.add(listener);
      if (previousListenerCount === 0 && this.listenerCount(eventName) === 1) {
        this.startObserving(eventName);
      }
      return {
        remove: () => {
          this.removeListener(eventName, listener);
        }
      };
    }
    removeListener(eventName, listener) {
      const hasRemovedListener = this.listeners?.get(eventName)?.delete(listener);
      if (this.listenerCount(eventName) === 0 && hasRemovedListener) {
        this.stopObserving(eventName);
      }
    }
    removeAllListeners(eventName) {
      const previousListenerCount = this.listenerCount(eventName);
      this.listeners?.get(eventName)?.clear();
      if (previousListenerCount > 0) {
        this.stopObserving(eventName);
      }
    }
    emit(eventName, ...args) {
      const listeners = new Set(this.listeners?.get(eventName));
      listeners.forEach(listener => {
        // When the listener throws an error, don't stop the execution of subsequent listeners and
        // don't propagate the error to the `emit` function. The motivation behind this is that
        // errors thrown from a module or user's code shouldn't affect other modules' behavior.
        try {
          listener(...args);
        } catch (error) {
          console.error(error);
        }
      });
    }
    listenerCount(eventName) {
      return this.listeners?.get(eventName)?.size ?? 0;
    }
    startObserving(eventName) {}
    stopObserving(eventName) {}
  }
  class NativeModule extends EventEmitter {}
  class SharedObject extends EventEmitter {
    release() {
      // no-op on Web, but subclasses can override it if needed.
    }
  }
  class SharedRef extends SharedObject {
    nativeRefType = 'unknown';
  }
},135,[],"node_modules/expo-modules-core/src/polyfill/CoreModule.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _libSha = require(_dependencyMap[0], "./lib/sha1");
  var sha1 = _interopDefault(_libSha);
  var _libV = require(_dependencyMap[1], "./lib/v35");
  var v35 = _interopDefault(_libV);
  var _uuidTypes = require(_dependencyMap[2], "./uuid.types");
  function uuidv4() {
    if (
    // We use this code path in jest-expo.
    process.env.NODE_ENV === 'test' ||
    // Node.js has supported global crypto since v15.
    typeof crypto === 'undefined' &&
    // Only use abstract imports in server environments.
    typeof window === 'undefined') {
      // NOTE: Metro statically extracts all `require` statements to resolve them for environments
      // that don't support `require` natively. Here we check if we're running in a server environment
      // by using the standard `typeof window` check, then running `eval` to skip Metro's static
      // analysis and keep the `require` statement intact for runtime evaluation.
      // eslint-disable-next-line no-eval
      return eval('require')('node:crypto').randomUUID();
    }
    return crypto.randomUUID();
  }
  const uuid = {
    v4: uuidv4,
    v5: (0, v35.default)('v5', 0x50, sha1.default),
    namespace: _uuidTypes.Uuidv5Namespace
  };
  var _default = uuid;
},136,[137,138,140],"node_modules/expo-modules-core/src/uuid/index.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  // Adapted from Chris Veness' SHA1 code at
  // http://www.movable-type.co.uk/scripts/sha1.html
  'use strict';

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  function f(s, x, y, z) {
    switch (s) {
      case 0:
        return x & y ^ ~x & z;
      case 1:
        return x ^ y ^ z;
      case 2:
        return x & y ^ x & z ^ y & z;
      case 3:
        return x ^ y ^ z;
      default:
        return 0;
    }
  }
  function ROTL(x, n) {
    return x << n | x >>> 32 - n;
  }
  function sha1(bytes) {
    const K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
    const H = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];
    if (typeof bytes == 'string') {
      const msg = unescape(encodeURIComponent(bytes)); // UTF8 escape
      bytes = new Array(msg.length);
      for (let i = 0; i < msg.length; i++) bytes[i] = msg.charCodeAt(i);
    }
    bytes.push(0x80);
    const l = bytes.length / 4 + 2;
    const N = Math.ceil(l / 16);
    const M = new Array(N);
    for (let i = 0; i < N; i++) {
      M[i] = new Array(16);
      for (let j = 0; j < 16; j++) {
        M[i][j] = bytes[i * 64 + j * 4] << 24 | bytes[i * 64 + j * 4 + 1] << 16 | bytes[i * 64 + j * 4 + 2] << 8 | bytes[i * 64 + j * 4 + 3];
      }
    }
    M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
    M[N - 1][14] = Math.floor(M[N - 1][14]);
    M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;
    for (let i = 0; i < N; i++) {
      const W = new Array(80);
      for (let t = 0; t < 16; t++) W[t] = M[i][t];
      for (let t = 16; t < 80; t++) {
        W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
      }
      let a = H[0];
      let b = H[1];
      let c = H[2];
      let d = H[3];
      let e = H[4];
      for (let t = 0; t < 80; t++) {
        const s = Math.floor(t / 20);
        const T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t] >>> 0;
        e = d;
        d = c;
        c = ROTL(b, 30) >>> 0;
        b = a;
        a = T;
      }
      H[0] = H[0] + a >>> 0;
      H[1] = H[1] + b >>> 0;
      H[2] = H[2] + c >>> 0;
      H[3] = H[3] + d >>> 0;
      H[4] = H[4] + e >>> 0;
    }
    return [H[0] >> 24 & 0xff, H[0] >> 16 & 0xff, H[0] >> 8 & 0xff, H[0] & 0xff, H[1] >> 24 & 0xff, H[1] >> 16 & 0xff, H[1] >> 8 & 0xff, H[1] & 0xff, H[2] >> 24 & 0xff, H[2] >> 16 & 0xff, H[2] >> 8 & 0xff, H[2] & 0xff, H[3] >> 24 & 0xff, H[3] >> 16 & 0xff, H[3] >> 8 & 0xff, H[3] & 0xff, H[4] >> 24 & 0xff, H[4] >> 16 & 0xff, H[4] >> 8 & 0xff, H[4] & 0xff];
  }
  var _default = sha1;
},137,[],"node_modules/expo-modules-core/src/uuid/lib/sha1.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _ref;
    }
  });
  var _bytesToUuid = require(_dependencyMap[0], "./bytesToUuid");
  var bytesToUuid = _interopDefault(_bytesToUuid);
  function uuidToBytes(uuid) {
    // Note: We assume we're being passed a valid uuid string
    const bytes = [];
    uuid.replace(/[a-fA-F0-9]{2}/g, hex => {
      bytes.push(parseInt(hex, 16));
      return '';
    });
    return bytes;
  }
  function stringToBytes(str) {
    str = unescape(encodeURIComponent(str)); // UTF8 escape
    const bytes = new Array(str.length);
    for (let i = 0; i < str.length; i++) {
      bytes[i] = str.charCodeAt(i);
    }
    return bytes;
  }
  function _ref(name, version, hashfunc) {
    const generateUUID = function (value, namespace, buf, offset) {
      const off = buf && offset || 0;
      if (typeof value == 'string') value = stringToBytes(value);
      if (typeof namespace == 'string') namespace = uuidToBytes(namespace);
      if (!Array.isArray(value)) throw TypeError('value must be an array of bytes');
      if (!Array.isArray(namespace) || namespace.length !== 16) throw TypeError('namespace must be uuid string or an Array of 16 byte values');

      // Per 4.3
      const bytes = hashfunc(namespace.concat(value));
      bytes[6] = bytes[6] & 0x0f | version;
      bytes[8] = bytes[8] & 0x3f | 0x80;
      if (buf) {
        for (let idx = 0; idx < 16; ++idx) {
          buf[off + idx] = bytes[idx];
        }
      }
      return (0, bytesToUuid.default)(bytes);
    };

    // Function#name is not settable on some platforms (#270)
    try {
      generateUUID.name = name;
    } catch {}

    // Pre-defined namespaces, per Appendix C
    generateUUID.DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
    generateUUID.URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
    return generateUUID;
  }
},138,[139],"node_modules/expo-modules-core/src/uuid/lib/v35.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Convert array of 16 byte values to UUID string format of the form:
   * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
   */
  const byteToHex = [];
  for (let i = 0; i < 256; ++i) {
    byteToHex[i] = (i + 0x100).toString(16).substr(1);
  }
  function bytesToUuid(buf, offset) {
    let i = offset || 0;
    const bth = byteToHex;
    // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4
    return [bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]]].join('');
  }
  var _default = bytesToUuid;
},139,[],"node_modules/expo-modules-core/src/uuid/lib/bytesToUuid.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "Uuidv5Namespace", {
    enumerable: true,
    get: function () {
      return Uuidv5Namespace;
    }
  });
  /**
   * Collection of utilities used for generating Universally Unique Identifiers.
   */
  /**
   * Default namespaces for UUID v5 defined in RFC 4122
   */
  let Uuidv5Namespace = /*#__PURE__*/function (Uuidv5Namespace) {
    // Source of the UUIDs: https://datatracker.ietf.org/doc/html/rfc4122
    Uuidv5Namespace["dns"] = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
    Uuidv5Namespace["url"] = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
    Uuidv5Namespace["oid"] = "6ba7b812-9dad-11d1-80b4-00c04fd430c8";
    Uuidv5Namespace["x500"] = "6ba7b814-9dad-11d1-80b4-00c04fd430c8";
    return Uuidv5Namespace;
  }({});
},140,[],"node_modules/expo-modules-core/src/uuid/uuid.types.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  require(_dependencyMap[0], "./EventEmitter");
  require(_dependencyMap[1], "./NativeModule");
  require(_dependencyMap[2], "./SharedObject");
  require(_dependencyMap[3], "./SharedRef");
},141,[142,143,144,145],"node_modules/expo-modules-core/src/ts-declarations/global.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},142,[],"node_modules/expo-modules-core/src/ts-declarations/EventEmitter.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},143,[],"node_modules/expo-modules-core/src/ts-declarations/NativeModule.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},144,[],"node_modules/expo-modules-core/src/ts-declarations/SharedObject.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},145,[],"node_modules/expo-modules-core/src/ts-declarations/SharedRef.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "EventEmitter", {
    enumerable: true,
    get: function () {
      return EventEmitter;
    }
  });
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();

  /**
   * A subscription object that allows to conveniently remove an event listener from the emitter.
   */

  const EventEmitter = globalThis.expo.EventEmitter;
},146,[147],"node_modules/expo-modules-core/src/EventEmitter.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.ensureNativeModulesAreInstalled = ensureNativeModulesAreInstalled;
  require(_dependencyMap[0], "./polyfill");
  // Installs the expo global on web

  /**
   * Ensures that the native modules are installed in the current runtime.
   * Otherwise, it synchronously calls a native function that installs them.
   */
  function ensureNativeModulesAreInstalled() {
    // No-op on web
  }
},147,[133],"node_modules/expo-modules-core/src/ensureNativeModulesAreInstalled.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "NativeModule", {
    enumerable: true,
    get: function () {
      return NativeModule;
    }
  });
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();
  const NativeModule = globalThis.expo.NativeModule;
},148,[147],"node_modules/expo-modules-core/src/NativeModule.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "SharedObject", {
    enumerable: true,
    get: function () {
      return SharedObject;
    }
  });
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();
  const SharedObject = globalThis.expo.SharedObject;
},149,[147],"node_modules/expo-modules-core/src/SharedObject.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "SharedRef", {
    enumerable: true,
    get: function () {
      return SharedRef;
    }
  });
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();
  const SharedRef = globalThis.expo.SharedRef;
},150,[147],"node_modules/expo-modules-core/src/SharedRef.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactNativeWebDistExportsPlatform = require(_dependencyMap[0], "react-native-web/dist/exports/Platform");
  var ReactNativePlatform = _interopDefault(_reactNativeWebDistExportsPlatform);
  var _environmentBrowser = require(_dependencyMap[1], "./environment/browser");
  if (__DEV__ && typeof "web" === 'undefined') {
    console.warn(`The global process.env.EXPO_OS is not defined. This should be inlined by babel-preset-expo during transformation.`);
  }
  const nativeSelect = typeof window !== 'undefined' ? ReactNativePlatform.default.select :
  // process.env.EXPO_OS is injected by `babel-preset-expo` and available in both client and `react-server` environments.
  // Opt to use the env var when possible, and fallback to the React Native Platform module when it's not (arbitrary bundlers and transformers).
  function select(specifics) {
    if (!"web") return undefined;
    if (specifics.hasOwnProperty("web")) {
      return specifics["web"];
    } else if (false && specifics.hasOwnProperty('native')) {
      return specifics.native;
    } else if (specifics.hasOwnProperty('default')) {
      return specifics.default;
    }
    // do nothing...
    return undefined;
  };
  const Platform = {
    /**
     * Denotes the currently running platform.
     * Can be one of ios, android, web.
     */
    OS: "web" || ReactNativePlatform.default.OS,
    /**
     * Returns the value with the matching platform.
     * Object keys can be any of ios, android, native, web, default.
     *
     * @ios ios, native, default
     * @android android, native, default
     * @web web, default
     */
    select: nativeSelect,
    /**
     * Denotes if the DOM API is available in the current environment.
     * The DOM is not available in native React runtimes and Node.js.
     */
    isDOMAvailable: _environmentBrowser.isDOMAvailable,
    /**
     * Denotes if the current environment can attach event listeners
     * to the window. This will return false in native React
     * runtimes and Node.js.
     */
    canUseEventListeners: _environmentBrowser.canUseEventListeners,
    /**
     * Denotes if the current environment can inspect properties of the
     * screen on which the current window is being rendered. This will
     * return false in native React runtimes and Node.js.
     */
    canUseViewport: _environmentBrowser.canUseViewport,
    /**
     * If the JavaScript is being executed in a remote JavaScript environment.
     * When `true`, synchronous native invocations cannot be executed.
     */
    isAsyncDebugging: _environmentBrowser.isAsyncDebugging
  };
  var _default = Platform;
},151,[123,152],"node_modules/expo-modules-core/src/Platform.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "isDOMAvailable", {
    enumerable: true,
    get: function () {
      return isDOMAvailable;
    }
  });
  Object.defineProperty(exports, "canUseEventListeners", {
    enumerable: true,
    get: function () {
      return canUseEventListeners;
    }
  });
  Object.defineProperty(exports, "canUseViewport", {
    enumerable: true,
    get: function () {
      return canUseViewport;
    }
  });
  Object.defineProperty(exports, "isAsyncDebugging", {
    enumerable: true,
    get: function () {
      return isAsyncDebugging;
    }
  });
  // Used for delegating node actions when browser APIs aren't available
  // like in SSR websites.
  const isDOMAvailable = typeof window !== 'undefined' && !!window.document?.createElement;
  const canUseEventListeners = isDOMAvailable && !!(window.addEventListener || window.attachEvent);
  const canUseViewport = isDOMAvailable && !!window.screen;
  const isAsyncDebugging = false;
},152,[],"node_modules/expo-modules-core/src/environment/browser.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.requireNativeViewManager = requireNativeViewManager;
  var _errorsUnavailabilityError = require(_dependencyMap[0], "./errors/UnavailabilityError");
  /**
   * A drop-in replacement for `requireNativeComponent`.
   */
  function requireNativeViewManager(moduleName, viewName) {
    throw new _errorsUnavailabilityError.UnavailabilityError('expo-modules-core', 'requireNativeViewManager');
  }
},153,[154],"node_modules/expo-modules-core/src/NativeViewManagerAdapter.tsx");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "UnavailabilityError", {
    enumerable: true,
    get: function () {
      return UnavailabilityError;
    }
  });
  var _CodedError = require(_dependencyMap[0], "./CodedError");
  var _Platform = require(_dependencyMap[1], "../Platform");
  var Platform = _interopDefault(_Platform);
  /**
   * A class for errors to be thrown when a property is accessed which is
   * unavailable, unsupported, or not currently implemented on the running
   * platform.
   */
  class UnavailabilityError extends _CodedError.CodedError {
    constructor(moduleName, propertyName) {
      super('ERR_UNAVAILABLE', `The method or property ${moduleName}.${propertyName} is not available on ${Platform.default.OS}, are you sure you've linked all the native dependencies properly?`);
    }
  }
},154,[155,151],"node_modules/expo-modules-core/src/errors/UnavailabilityError.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "CodedError", {
    enumerable: true,
    get: function () {
      return CodedError;
    }
  });
  /**
   * A general error class that should be used for all errors in Expo modules.
   * Guarantees a `code` field that can be used to differentiate between different
   * types of errors without further subclassing Error.
   */
  class CodedError extends Error {
    constructor(code, message) {
      super(message);
      this.code = code;
    }
  }
},155,[],"node_modules/expo-modules-core/src/errors/CodedError.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.requireNativeModule = requireNativeModule;
  exports.requireOptionalNativeModule = requireOptionalNativeModule;
  function requireNativeModule(moduleName) {
    const nativeModule = requireOptionalNativeModule(moduleName);
    if (nativeModule != null) {
      return nativeModule;
    }
    if (typeof window === 'undefined') {
      // For SSR, we expect not to have native modules available, but to avoid crashing from SSR resolutions, we return an empty object.
      return {};
    }
    throw new Error(`Cannot find native module '${moduleName}'`);
  }
  function requireOptionalNativeModule(moduleName) {
    if (typeof globalThis.ExpoDomWebView === 'object' && globalThis?.expo?.modules != null) {
      return globalThis.expo?.modules?.[moduleName] ?? null;
    }
    return null;
  }
},156,[],"node_modules/expo-modules-core/src/requireNativeModule.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.registerWebModule = registerWebModule;
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  /**
   * Registers a web module.
   * @param moduleImplementation A class that extends `NativeModule`. The class is registered under `globalThis.expo.modules[className]`.
   * @param moduleName – a name to register the module under `globalThis.expo.modules[className]`.
   * @returns A singleton instance of the class passed into arguments.
   */

  function registerWebModule(moduleImplementation, moduleName) {
    (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();
    moduleName = moduleName ?? moduleImplementation.name;
    if (!moduleName) {
      throw new Error('Web module implementation is missing a name - it is either not a class or has been minified. Pass the name as a second argument to the `registerWebModule` function.');
    }
    if (!globalThis?.expo?.modules) {
      globalThis.expo.modules = {};
    }
    if (globalThis.expo.modules[moduleName]) {
      return globalThis.expo.modules[moduleName];
    }
    globalThis.expo.modules[moduleName] = new moduleImplementation();
    return globalThis.expo.modules[moduleName];
  }
},157,[147],"node_modules/expo-modules-core/src/registerWebModule.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},158,[],"node_modules/expo-modules-core/src/TypedArrays.types.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "PermissionStatus", {
    enumerable: true,
    get: function () {
      return PermissionStatus;
    }
  });
  let PermissionStatus = /*#__PURE__*/function (PermissionStatus) {
    /**
     * User has granted the permission.
     */
    PermissionStatus["GRANTED"] = "granted";
    /**
     * User hasn't granted or denied the permission yet.
     */
    PermissionStatus["UNDETERMINED"] = "undetermined";
    /**
     * User has denied the permission.
     */
    PermissionStatus["DENIED"] = "denied";
    return PermissionStatus;
  }({});
  /**
   * Permission expiration time. Currently, all permissions are granted permanently.
   */
  /**
   * An object obtained by permissions get and request functions.
   */
},159,[],"node_modules/expo-modules-core/src/PermissionsInterface.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  // Copyright © 2024 650 Industries.

  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.createPermissionHook = createPermissionHook;
  var _react = require(_dependencyMap[0], "react");
  // These types are identical, but improves the readability for suggestions in editors

  /**
   * Get or request permission for protected functionality within the app.
   * It uses separate permission requesters to interact with a single permission.
   * By default, the hook will only retrieve the permission status.
   */
  function usePermission(methods, options) {
    const isMounted = (0, _react.useRef)(true);
    const [status, setStatus] = (0, _react.useState)(null);
    const {
      get = true,
      request = false,
      ...permissionOptions
    } = options || {};
    const getPermission = (0, _react.useCallback)(async () => {
      let response;
      if (Object.keys(permissionOptions).length > 0) {
        response = await methods.getMethod(permissionOptions);
      } else {
        response = await methods.getMethod();
      }
      if (isMounted.current) setStatus(response);
      return response;
    }, [methods.getMethod]);
    const requestPermission = (0, _react.useCallback)(async () => {
      let response;
      if (Object.keys(permissionOptions).length > 0) {
        response = await methods.requestMethod(permissionOptions);
      } else {
        response = await methods.requestMethod();
      }
      if (isMounted.current) setStatus(response);
      return response;
    }, [methods.requestMethod]);
    (0, _react.useEffect)(function runMethods() {
      if (request) requestPermission();
      if (!request && get) getPermission();
    }, [get, request, requestPermission, getPermission]);

    // Workaround for unmounting components receiving state updates
    (0, _react.useEffect)(function didMount() {
      isMounted.current = true;
      return () => {
        isMounted.current = false;
      };
    }, []);
    return [status, requestPermission, getPermission];
  }

  /**
   * Create a new permission hook with the permission methods built-in.
   * This can be used to quickly create specific permission hooks in every module.
   */
  function createPermissionHook(methods) {
    return options => usePermission(methods, options);
  }
},160,[62],"node_modules/expo-modules-core/src/PermissionsHook.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.createSnapshotFriendlyRef = createSnapshotFriendlyRef;
  var _react = require(_dependencyMap[0], "react");
  /**
   * Create a React ref object that is friendly for snapshots.
   * It will be represented as `[React.ref]` in snapshots.
   * @returns A React ref object.
   */
  function createSnapshotFriendlyRef() {
    return /*#__PURE__*/(0, _react.createRef)();
  }
},161,[62],"node_modules/expo-modules-core/src/Refs.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.useReleasingSharedObject = useReleasingSharedObject;
  var _react = require(_dependencyMap[0], "react");
  /**
   * Returns a shared object, which is automatically cleaned up when the component is unmounted.
   */
  function useReleasingSharedObject(factory, dependencies) {
    const objectRef = (0, _react.useRef)(null);
    const isFastRefresh = (0, _react.useRef)(false);
    const previousDependencies = (0, _react.useRef)(dependencies);
    if (objectRef.current == null) {
      objectRef.current = factory();
    }
    const object = (0, _react.useMemo)(() => {
      let newObject = objectRef.current;
      const dependenciesAreEqual = previousDependencies.current?.length === dependencies.length && dependencies.every((value, index) => value === previousDependencies.current[index]);

      // If the dependencies have changed, release the previous object and create a new one, otherwise this has been called
      // because of an unrelated fast refresh, and we don't want to release the object.
      if (!newObject || !dependenciesAreEqual) {
        objectRef.current?.release();
        newObject = factory();
        objectRef.current = newObject;
        previousDependencies.current = dependencies;
      }
      return newObject;
    }, dependencies);
    (0, _react.useMemo)(() => {
      isFastRefresh.current = true;
    }, []);
    (0, _react.useEffect)(() => {
      isFastRefresh.current = false;
      return () => {
        // This will be called on every fast refresh and on unmount, but we only want to release the object on unmount.
        if (!isFastRefresh.current && objectRef.current) {
          objectRef.current.release();
        }
      };
    }, []);
    return object;
  }
},162,[62],"node_modules/expo-modules-core/src/hooks/useReleasingSharedObject.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.reloadAppAsync = reloadAppAsync;
  /**
   * Reloads the app. This method works for both release and debug builds.
   *
   * Unlike [`Updates.reloadAsync()`](/versions/latest/sdk/updates/#updatesreloadasync),
   * this function does not use a new update even if one is available. It only reloads the app using the same JavaScript bundle that is currently running.
   *
   * @param reason The reason for reloading the app. This is used only for some platforms.
   */
  async function reloadAppAsync(reason = 'Reloaded from JS call') {
    await globalThis.expo?.reloadAppAsync(reason);
  }
},163,[],"node_modules/expo-modules-core/src/reload.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "LegacyEventEmitter", {
    enumerable: true,
    get: function () {
      return LegacyEventEmitter;
    }
  });
  var _invariant = require(_dependencyMap[0], "invariant");
  var invariant = _interopDefault(_invariant);
  var _reactNativeWebDistExportsNativeEventEmitter = require(_dependencyMap[1], "react-native-web/dist/exports/NativeEventEmitter");
  var NativeEventEmitter = _interopDefault(_reactNativeWebDistExportsNativeEventEmitter);
  var _reactNativeWebDistExportsPlatform = require(_dependencyMap[2], "react-native-web/dist/exports/Platform");
  var Platform = _interopDefault(_reactNativeWebDistExportsPlatform);
  const nativeEmitterSubscriptionKey = '@@nativeEmitterSubscription@@';
  /**
   * @deprecated Deprecated in favor of `EventEmitter`.
   */
  class LegacyEventEmitter {
    _listenerCount = 0;

    // @ts-expect-error

    // @ts-expect-error

    constructor(nativeModule) {
      // If the native module is a new module, just return it back as it's already an event emitter.
      // This is for backwards compatibility until we stop using this legacy class in other packages.
      if (nativeModule.__expo_module_name__) {
        // @ts-expect-error
        return nativeModule;
      }
      this._nativeModule = nativeModule;
      this._eventEmitter = new NativeEventEmitter.default(nativeModule);
    }
    addListener(eventName, listener) {
      if (!this._listenerCount && Platform.default.OS !== 'ios' && this._nativeModule.startObserving) {
        this._nativeModule.startObserving();
      }
      this._listenerCount++;
      const nativeEmitterSubscription = this._eventEmitter.addListener(eventName, listener);
      const subscription = {
        [nativeEmitterSubscriptionKey]: nativeEmitterSubscription,
        remove: () => {
          this.removeSubscription(subscription);
        }
      };
      return subscription;
    }
    removeAllListeners(eventName) {
      // @ts-ignore: the EventEmitter interface has been changed in react-native@0.64.0
      const removedListenerCount = this._eventEmitter.listenerCount ?
      // @ts-ignore: this is available since 0.64
      this._eventEmitter.listenerCount(eventName) :
      // @ts-ignore: this is available in older versions
      this._eventEmitter.listeners(eventName).length;
      this._eventEmitter.removeAllListeners(eventName);
      this._listenerCount -= removedListenerCount;
      (0, invariant.default)(this._listenerCount >= 0, `EventEmitter must have a non-negative number of listeners`);
      if (!this._listenerCount && Platform.default.OS !== 'ios' && this._nativeModule.stopObserving) {
        this._nativeModule.stopObserving();
      }
    }
    removeSubscription(subscription) {
      const state = subscription;
      const nativeEmitterSubscription = state[nativeEmitterSubscriptionKey];
      if (!nativeEmitterSubscription) {
        return;
      }
      if ('remove' in nativeEmitterSubscription) {
        nativeEmitterSubscription.remove?.();
      }
      this._listenerCount--;

      // Ensure that the emitter's internal state remains correct even if `removeSubscription` is
      // called again with the same subscription
      delete state[nativeEmitterSubscriptionKey];

      // Release closed-over references to the emitter
      subscription.remove = () => {};
      if (!this._listenerCount && Platform.default.OS !== 'ios' && this._nativeModule.stopObserving) {
        this._nativeModule.stopObserving();
      }
    }
    emit(eventName, ...params) {
      this._eventEmitter.emit(eventName, ...params);
    }
  }
},164,[165,126,123],"node_modules/expo-modules-core/src/LegacyEventEmitter.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  'use strict';

  /**
   * Use invariant() to assert state which your program assumes to be true.
   *
   * Provide sprintf-style format (only %s is supported) and arguments
   * to provide information about what broke and what you were
   * expecting.
   *
   * The invariant message will be stripped in production, but the invariant
   * will remain to ensure logic does not differ in production.
   */
  var invariant = function (condition, format, a, b, c, d, e, f) {
    if (process.env.NODE_ENV !== 'production') {
      if (format === undefined) {
        throw new Error('invariant requires an error message argument');
      }
    }
    if (!condition) {
      var error;
      if (format === undefined) {
        error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
      } else {
        var args = [a, b, c, d, e, f];
        var argIndex = 0;
        error = new Error(format.replace(/%s/g, function () {
          return args[argIndex++];
        }));
        error.name = 'Invariant Violation';
      }
      error.framesToPop = 1; // we don't care about invariant's own frame
      throw error;
    }
  };
  module.exports = invariant;
},165,[],"node_modules/invariant/browser.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  // We default to an empty object shim wherever we don't have an environment-specific implementation

  /**
   * @deprecated `NativeModulesProxy` is deprecated and might be removed in the future releases.
   * Use `requireNativeModule` or `requireOptionalNativeModule` instead.
   */
  var _default = {};
},166,[],"node_modules/expo-modules-core/src/NativeModulesProxy.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.defineTask = defineTask;
  exports.isTaskDefined = isTaskDefined;
  exports.isTaskRegisteredAsync = isTaskRegisteredAsync;
  exports.getTaskOptionsAsync = getTaskOptionsAsync;
  exports.getRegisteredTasksAsync = getRegisteredTasksAsync;
  exports.unregisterTaskAsync = unregisterTaskAsync;
  exports.unregisterAllTasksAsync = unregisterAllTasksAsync;
  exports.isAvailableAsync = isAvailableAsync;
  var _expoModulesCore = require(_dependencyMap[0], "expo-modules-core");
  var _ExpoTaskManager = require(_dependencyMap[1], "./ExpoTaskManager");
  var ExpoTaskManager = _interopDefault(_ExpoTaskManager);
  const tasks = new Map();
  function _validate(taskName) {
    if (!taskName || typeof taskName !== 'string') {
      throw new TypeError('`taskName` must be a non-empty string.');
    }
  }
  // @needsAudit
  /**
   * Defines task function. It must be called in the global scope of your JavaScript bundle.
   * In particular, it cannot be called in any of React lifecycle methods like `componentDidMount`.
   * This limitation is due to the fact that when the application is launched in the background,
   * we need to spin up your JavaScript app, run your task and then shut down — no views are mounted
   * in this scenario.
   *
   * @param taskName Name of the task. It must be the same as the name you provided when registering the task.
   * @param taskExecutor A function that will be invoked when the task with given `taskName` is executed.
   */
  function defineTask(taskName, taskExecutor) {
    if (!taskName || typeof taskName !== 'string') {
      console.warn(`TaskManager.defineTask: 'taskName' argument must be a non-empty string.`);
      return;
    }
    if (!taskExecutor || typeof taskExecutor !== 'function') {
      console.warn(`TaskManager.defineTask: 'task' argument must be a function.`);
      return;
    }
    tasks.set(taskName, taskExecutor);
  }
  // @needsAudit
  /**
   * Checks whether the task is already defined.
   *
   * @param taskName Name of the task.
   */
  function isTaskDefined(taskName) {
    return tasks.has(taskName);
  }
  // @needsAudit
  /**
   * Determine whether the task is registered. Registered tasks are stored in a persistent storage and
   * preserved between sessions.
   *
   * @param taskName Name of the task.
   * @returns A promise which resolves to `true` if a task with the given name is registered, otherwise `false`.
   */
  async function isTaskRegisteredAsync(taskName) {
    if (!ExpoTaskManager.default.isTaskRegisteredAsync) {
      throw new _expoModulesCore.UnavailabilityError('TaskManager', 'isTaskRegisteredAsync');
    }
    _validate(taskName);
    return ExpoTaskManager.default.isTaskRegisteredAsync(taskName);
  }
  // @needsAudit
  /**
   * Retrieves `options` associated with the task, that were passed to the function registering the task
   * (e.g. `Location.startLocationUpdatesAsync`).
   *
   * @param taskName Name of the task.
   * @return A promise which fulfills with the `options` object that was passed while registering task
   * with given name or `null` if task couldn't be found.
   */
  async function getTaskOptionsAsync(taskName) {
    if (!ExpoTaskManager.default.getTaskOptionsAsync) {
      throw new _expoModulesCore.UnavailabilityError('TaskManager', 'getTaskOptionsAsync');
    }
    _validate(taskName);
    return ExpoTaskManager.default.getTaskOptionsAsync(taskName);
  }
  // @needsAudit
  /**
   * Provides information about tasks registered in the app.
   *
   * @returns A promise which fulfills with an array of tasks registered in the app.
   * @example
   * ```js
   * [
   *   {
   *     taskName: 'location-updates-task-name',
   *     taskType: 'location',
   *     options: {
   *       accuracy: Location.Accuracy.High,
   *       showsBackgroundLocationIndicator: false,
   *     },
   *   },
   *   {
   *     taskName: 'geofencing-task-name',
   *     taskType: 'geofencing',
   *     options: {
   *       regions: [...],
   *     },
   *   },
   * ]
   * ```
   */
  async function getRegisteredTasksAsync() {
    if (!ExpoTaskManager.default.getRegisteredTasksAsync) {
      throw new _expoModulesCore.UnavailabilityError('TaskManager', 'getRegisteredTasksAsync');
    }
    return ExpoTaskManager.default.getRegisteredTasksAsync();
  }
  // @needsAudit
  /**
   * Unregisters task from the app, so the app will not be receiving updates for that task anymore.
   * _It is recommended to use methods specialized by modules that registered the task, eg.
   * [`Location.stopLocationUpdatesAsync`](./location/#expolocationstoplocationupdatesasynctaskname)._
   *
   * @param taskName Name of the task to unregister.
   * @return A promise which fulfills as soon as the task is unregistered.
   */
  async function unregisterTaskAsync(taskName) {
    if (!ExpoTaskManager.default.unregisterTaskAsync) {
      throw new _expoModulesCore.UnavailabilityError('TaskManager', 'unregisterTaskAsync');
    }
    _validate(taskName);
    await ExpoTaskManager.default.unregisterTaskAsync(taskName);
  }
  // @needsAudit
  /**
   * Unregisters all tasks registered for the running app. You may want to call this when the user is
   * signing out and you no longer need to track his location or run any other background tasks.
   * @return A promise which fulfills as soon as all tasks are completely unregistered.
   */
  async function unregisterAllTasksAsync() {
    if (!ExpoTaskManager.default.unregisterAllTasksAsync) {
      throw new _expoModulesCore.UnavailabilityError('TaskManager', 'unregisterAllTasksAsync');
    }
    await ExpoTaskManager.default.unregisterAllTasksAsync();
  }
  if (ExpoTaskManager.default) {
    const eventEmitter = new _expoModulesCore.LegacyEventEmitter(ExpoTaskManager.default);
    eventEmitter.addListener(ExpoTaskManager.default.EVENT_NAME, async ({
      data,
      error,
      executionInfo
    }) => {
      const {
        eventId,
        taskName
      } = executionInfo;
      const taskExecutor = tasks.get(taskName);
      let result = null;
      if (taskExecutor) {
        try {
          // Execute JS task
          result = await taskExecutor({
            data,
            error,
            executionInfo
          });
        } catch (error) {
          console.error(`TaskManager: Task "${taskName}" failed:`, error);
        } finally {
          // Notify manager the task is finished.
          await ExpoTaskManager.default.notifyTaskFinishedAsync(taskName, {
            eventId,
            result
          });
        }
      } else {
        console.warn(`TaskManager: Task "${taskName}" has been executed but looks like it is not defined. Make sure that "TaskManager.defineTask" is called during initialization phase.`);
        // No tasks defined -> we need to notify about finish anyway.
        await ExpoTaskManager.default.notifyTaskFinishedAsync(taskName, {
          eventId,
          result
        });
        // We should also unregister such tasks automatically as the task might have been removed
        // from the app or just renamed - in that case it needs to be registered again (with the new name).
        await ExpoTaskManager.default.unregisterTaskAsync(taskName);
      }
    });
  }
  // @needsAudit
  /**
   * Determine if the `TaskManager` API can be used in this app.
   * @return A promise which fulfills with `true` if the API can be used, and `false` otherwise.
   * With Expo Go, `TaskManager` is not available on Android, and does not support background execution on iOS.
   * Use a development build to avoid limitations: https://expo.fyi/dev-client.
   * On the web, it always returns `false`.
   */
  async function isAvailableAsync() {
    return ExpoTaskManager.default.isAvailableAsync();
  }
},634,[131,635],"node_modules/expo-task-manager/build/TaskManager.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _default = {
    get EVENT_NAME() {
      return 'TaskManager.executeTask';
    },
    addListener() {},
    removeListeners() {},
    async isAvailableAsync() {
      return false;
    }
  };
},635,[],"node_modules/expo-task-manager/build/ExpoTaskManager.web.js");
//# sourceMappingURL=http://127.0.0.1:8087/node_modules/expo-task-manager/build/TaskManager.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false