__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.haversineM = haversineM;
  exports.formatDistance = formatDistance;
  exports.formatDuration = formatDuration;
  exports.generateId = generateId;
  exports.formatDate = formatDate;
  exports.getRelativeTime = getRelativeTime;
  exports.kalmanInit = kalmanInit;
  exports.kalmanUpdate = kalmanUpdate;
  exports.classifyMovement = classifyMovement;
  Object.defineProperty(exports, "BG_SAMPLING", {
    enumerable: true,
    get: function () {
      return BG_SAMPLING;
    }
  });
  exports.getSamplingInterval = getSamplingInterval;
  exports.simplifyPolyline = simplifyPolyline;
  /**
   * geo.ts — geographic utility functions.
   * Unit-agnostic internally (meters). All display formatting goes through
   * formatDistance() which respects user's preferred unit.
   */

  const EARTH_RADIUS_M = 6_371_000;

  /**
   * Haversine distance between two coordinates, in meters.
   */
  function haversineM(a, b) {
    const toRad = deg => deg * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const sinDLat = Math.sin(dLat / 2);
    const sinDLng = Math.sin(dLng / 2);
    const h = sinDLat * sinDLat + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * sinDLng * sinDLng;
    return 2 * EARTH_RADIUS_M * Math.asin(Math.sqrt(h));
  }

  /**
   * Format distance for display.
   * @param meters  Raw distance in meters
   * @param unit    'km' (default) or 'mi'
   * @param decimals Decimal places (default 2)
   * Returns '--' when distance is negligible (< 10m)
   */
  function formatDistance(meters, unit = 'km', decimals = 2) {
    // Show 0.0 (or 0.00) for very short distances rather than "--", so the
    // user can see we did record a distance — they just didn't move far.
    // The previous "<10m → '--'" rule made empty-looking screens (e.g.
    // "-- km · 00:53 · +22m") that read like a hardware failure.
    if (!Number.isFinite(meters) || meters < 0) return 0 .toFixed(decimals);
    if (unit === 'mi') {
      return (meters / 1609.344).toFixed(decimals);
    }
    return (meters / 1000).toFixed(decimals);
  }

  /**
   * Format duration in seconds to mm:ss or h:mm:ss.
   */
  function formatDuration(seconds) {
    // Activity duration can briefly be fractional while a provider tick is
    // being reduced. Display is whole elapsed seconds everywhere; allowing the
    // remainder through String() exposes floating-point tails such as
    // `01:30.679000000000002` in the live metric strip.
    const totalSeconds = Number.isFinite(seconds) ? Math.max(0, Math.floor(seconds)) : 0;
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor(totalSeconds % 3600 / 60);
    const s = totalSeconds % 60;
    if (h > 0) {
      return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  /**
   * Generate a unique ID (timestamp + random suffix).
   * Not cryptographically secure — for local IDs only.
   */
  function generateId() {
    return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }

  /**
   * Format a timestamp to a human-readable date string.
   * Returns "Today", "Yesterday", or "Jan 5" / "May 14" format.
   */
  function formatDate(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const yesterdayStart = todayStart - 86400000;
    const dateStart = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
    if (dateStart === todayStart) return 'Today';
    if (dateStart === yesterdayStart) return 'Yesterday';
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[date.getMonth()]} ${date.getDate()}`;
  }

  /**
   * Relative time label: "just now", "5m ago", "3h ago", "yesterday", "4 days ago".
   */
  function getRelativeTime(ts) {
    const diffMs = Date.now() - ts;
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 60) return diffMin <= 1 ? 'just now' : `${diffMin}m ago`;
    const diffH = Math.floor(diffMin / 60);
    if (diffH < 24) return `${diffH}h ago`;
    const diffD = Math.floor(diffH / 24);
    if (diffD === 1) return 'yesterday';
    return `${diffD} days ago`;
  }

  // ── Kalman Filter for GPS Smoothing ─────────────────────────────────────────

  /**
   * 1D Kalman filter state.
   * Used independently for latitude, longitude, and altitude.
   */

  /**
   * Initialize a 1D Kalman filter with the first measurement.
   * @param initialValue  First GPS reading
   * @param accuracy      GPS reported accuracy in meters (feeds into R)
   * @param processNoise  How volatile we expect movement to be (default 0.00001 for lat/lng)
   */
  function kalmanInit(initialValue, accuracy, processNoise = 0.00001) {
    // Convert accuracy (meters) to approximate degrees for lat/lng
    // ~111,000 meters per degree of latitude
    const r = accuracy > 0 ? (accuracy / 111000) ** 2 : 0.0001;
    return {
      x: initialValue,
      p: r,
      // initial uncertainty = measurement uncertainty
      q: processNoise,
      r
    };
  }

  /**
   * Update Kalman filter with a new measurement.
   * Returns the smoothed estimate.
   */
  function kalmanUpdate(state, measurement, accuracy) {
    // Prediction step
    const pPredicted = state.p + state.q;

    // Update measurement noise if new accuracy provided
    if (accuracy != null && accuracy > 0) {
      state.r = (accuracy / 111000) ** 2;
    }

    // Kalman gain
    const k = pPredicted / (pPredicted + state.r);

    // Update estimate
    state.x = state.x + k * (measurement - state.x);
    state.p = (1 - k) * pPredicted;
    return state.x;
  }

  // O1 batch 38: GPSPoint + isConsistentPoint removed — 0 external callers

  // ── Dynamic Sampling Rate ───────────────────────────────────────────────────

  /**
   * Determine movement state from speed.
   * @param speedMs  Speed in m/s (from GPS or calculated)
   * @returns Movement state classification
   */
  function classifyMovement(speedMs) {
    if (speedMs < 0.5) return 'static';
    if (speedMs <= 2.5) return 'walking';
    return 'running';
  }

  /**
   * Get the appropriate GPS sampling interval in milliseconds.
   * @param movement    Current movement state
   * @param batteryLow  Whether battery is below 20%
   * @param opts        Sprint 72 STORY-00553: optional context for background
   *                    downgrade. When app is in background AND battery <50%
   *                    AND not charging, running/walking rates are relaxed
   *                    (running 500→1000, walking 1000→3000, static 10s→15s).
   *                    Foreground always uses tight rates. Charging or battery
   *                    ≥50% keeps foreground rates in background too.
   * @returns Sampling interval in ms
   */
  const BG_SAMPLING = {
    RUNNING_MS: 1000,
    WALKING_MS: 3000,
    STATIC_MS: 15000,
    BATTERY_HIGH_THRESHOLD: 0.5
  };
  function getSamplingInterval(movement, batteryLow = false, opts) {
    if (batteryLow) return 2000; // 0.5Hz forced (unchanged; battery <20%)

    const inBackground = opts?.appState === 'background' || opts?.appState === 'inactive';
    const batteryOk = (opts?.batteryLevel ?? 1) >= BG_SAMPLING.BATTERY_HIGH_THRESHOLD;
    const shouldDowngrade = inBackground && !opts?.isCharging && !batteryOk;
    if (shouldDowngrade) {
      switch (movement) {
        case 'static':
          return BG_SAMPLING.STATIC_MS;
        case 'walking':
          return BG_SAMPLING.WALKING_MS;
        case 'running':
          return BG_SAMPLING.RUNNING_MS;
      }
    }

    // Foreground OR charging OR battery ≥50% → tight foreground rates
    switch (movement) {
      case 'static':
        return 10000;
      // 0.1Hz
      case 'walking':
        return 1000;
      // 1Hz
      case 'running':
        return 500;
      // 2Hz
    }
  }

  // O1 batch 38: SmoothedTrackState + createTrackSmoother + smoothGPSPoint +
  // getDebugLogger + logKalmanEvent removed — 0 external callers.

  // O1 batch 38: distanceToPolylineM removed — 0 external callers.
  // (checkRouteDeviation also removed below as it was the only caller)
  // distanceToSegmentM kept — used by simplifyPolyline below.

  /**
   * Distance from a point to a line segment (in meters).
   * Projects the point onto the segment and computes perpendicular distance.
   * Used by simplifyPolyline.
   */
  function distanceToSegmentM(p, a, b) {
    const segLen = haversineM(a, b);
    if (segLen < 0.1) return haversineM(p, a); // degenerate segment
    const dx = b.lng - a.lng;
    const dy = b.lat - a.lat;
    const px = p.lng - a.lng;
    const py = p.lat - a.lat;
    const t = Math.max(0, Math.min(1, (px * dx + py * dy) / (dx * dx + dy * dy)));
    const proj = {
      lat: a.lat + t * dy,
      lng: a.lng + t * dx
    };
    return haversineM(p, proj);
  }

  /**
   * Douglas-Peucker polyline simplification (recursive). Removes vertices
   * that are within `epsilonM` of the line between their kept neighbours.
   * Visually identical to the input on a map at typical hike scale, but
   * with 30-50% fewer vertices — Mapbox renders smoother (anti-aliasing
   * has fewer cusps to handle) and consumes less GPU.
   *
   * Pure JS, no deps. Iterative-on-stack to avoid recursion-depth issues
   * on very long tracks (e.g. multi-hour rides with >5000 points).
   *
   * @param points  Input polyline (lat/lng + any extra fields). Extra
   *                fields are preserved on retained points.
   * @param epsilonM  Tolerance in metres. ε=2 is a sweet spot for hikes
   *                  (preserves all visible turns, drops only collinear
   *                  noise points).
   * @returns Filtered subset of `points` (same references, same order),
   *          guaranteed to include the first and last point.
   */
  function simplifyPolyline(points, epsilonM) {
    if (points.length < 3) return points.slice();
    // Iterative DP: stack of (start, end) index ranges. For each range,
    // find the point with max perpendicular distance from the chord
    // start→end. If > ε, mark it as kept and split into two sub-ranges.
    const keep = new Uint8Array(points.length);
    keep[0] = 1;
    keep[points.length - 1] = 1;
    const stack = [[0, points.length - 1]];
    while (stack.length > 0) {
      const [lo, hi] = stack.pop();
      if (hi - lo < 2) continue;
      let maxD = 0;
      let maxIdx = -1;
      const a = points[lo];
      const b = points[hi];
      for (let i = lo + 1; i < hi; i++) {
        const d = distanceToSegmentM(points[i], a, b);
        if (d > maxD) {
          maxD = d;
          maxIdx = i;
        }
      }
      if (maxIdx >= 0 && maxD > epsilonM) {
        keep[maxIdx] = 1;
        stack.push([lo, maxIdx]);
        stack.push([maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0; i < points.length; i++) if (keep[i]) out.push(points[i]);
    return out;
  }

  // O1 batch 38: checkRouteDeviation removed — 0 external callers; distanceToPolylineM also gone.

  /**
   * Check if user has arrived at a waypoint (within trigger radius).
   */
  // O1 batch 38: isWithinRadius removed — 0 external callers.

  // O1 batch 38: checkMarkerSpacing + filterByDensity removed — 0 external callers.
},572,[],"src/utils/geo.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.calculateLifecycleDurationMs = calculateLifecycleDurationMs;
  Object.defineProperty(exports, "MAX_CREDITABLE_ACTIVE_INTERVAL_MS", {
    enumerable: true,
    get: function () {
      return MAX_CREDITABLE_ACTIVE_INTERVAL_MS;
    }
  });
  Object.defineProperty(exports, "MAX_ACCEPTABLE_HORIZONTAL_ACCURACY_M", {
    enumerable: true,
    get: function () {
      return MAX_ACCEPTABLE_HORIZONTAL_ACCURACY_M;
    }
  });
  exports.isCredibleMotionSample = isCredibleMotionSample;
  exports.newSegmentId = newSegmentId;
  exports.saveEligibility = saveEligibility;
  exports.shouldStartNewSegment = shouldStartNewSegment;
  exports.resolveSegmentProvenance = resolveSegmentProvenance;
  exports.segmentTrace = segmentTrace;
  exports.calculateActivityStats = calculateActivityStats;
  exports.toServerPoint = toServerPoint;
  var _utilsGeo = require(_dependencyMap[0], "../../utils/geo");
  var _elevationQuality = require(_dependencyMap[1], "./elevationQuality");
  /**
   * Activity time belongs to the lifecycle, not to GPS geometry. The accumulated
   * portion is frozen at Pause; while Tracking, the provider clock contributes
   * the open interval. Real Activities use wall time and Simulator Activities
   * use their bounded virtual clock.
   */
  function calculateLifecycleDurationMs(args) {
    const accumulatedMs = Number.isFinite(args.accumulatedMs) ? Math.max(0, args.accumulatedMs) : 0;
    if (args.activeSinceMs === null || !Number.isFinite(args.activeSinceMs)) {
      return accumulatedMs;
    }
    return accumulatedMs + Math.max(0, args.nowMs - args.activeSinceMs);
  }
  const MODE_MAX_SPEED_MPS = {
    hiking: 4.17,
    running: 10
  };

  // The recorder normally samples in seconds. A two-minute interval is the
  // upper credible interval used by current dynamic/background sampling. It is
  // never sufficient by itself to split a segment: position, accuracy and known
  // loss state also participate.
  const MAX_CREDITABLE_ACTIVE_INTERVAL_MS = 120_000;
  /** Shared horizontal-quality boundary for accepted Activity/passive evidence. */
  const MAX_ACCEPTABLE_HORIZONTAL_ACCURACY_M = 25;
  const MIN_CREDIBLE_MOTION_SPEED_MPS = 0.55;
  const MIN_CREDIBLE_MOTION_STEP_M = 2.5;
  const MAX_CREDIBLE_MOTION_SAMPLE_INTERVAL_MS = 15_000;

  /**
   * Moderate-accuracy fixes normally remain behind the indoor-drift gate. A
   * moving user may pass it only when Core Location and the immediately prior
   * native sample agree that movement is coherent. This keeps the canonical
   * route responsive without turning arbitrary raw noise into Activity truth.
   */
  function isCredibleMotionSample(args) {
    const {
      mode,
      lastAccepted,
      previousRaw,
      current
    } = args;
    if (!previousRaw) return false;
    const speed = current.speed;
    const previousSpeed = previousRaw.speed;
    const accuracy = current.accuracy;
    const previousAccuracy = previousRaw.accuracy;
    if (speed == null || previousSpeed == null || speed < MIN_CREDIBLE_MOTION_SPEED_MPS || previousSpeed < MIN_CREDIBLE_MOTION_SPEED_MPS * 0.6 || speed > MODE_MAX_SPEED_MPS[mode] || accuracy == null || previousAccuracy == null || accuracy > 20 || previousAccuracy > 20) return false;
    const dtMs = current.t - previousRaw.t;
    if (dtMs <= 0 || dtMs > MAX_CREDIBLE_MOTION_SAMPLE_INTERVAL_MS) return false;
    const dtS = dtMs / 1000;
    const nativeStepM = (0, _utilsGeo.haversineM)(previousRaw, current);
    const expectedStepM = speed * dtS;
    const minimumStepM = Math.max(MIN_CREDIBLE_MOTION_STEP_M, Math.min(6, expectedStepM * 0.35));
    if (nativeStepM < minimumStepM) return false;

    // Progress must move away from the current accepted anchor rather than
    // orbiting it as stationary GPS drift commonly does.
    const previousProgressM = (0, _utilsGeo.haversineM)(lastAccepted, previousRaw);
    const currentProgressM = (0, _utilsGeo.haversineM)(lastAccepted, current);
    if (currentProgressM < previousProgressM + 1) return false;

    // Do not let a noisy speed value excuse a physically implausible sample.
    const uncertaintyM = Math.max(accuracy, previousAccuracy, 5);
    const maximumStepM = Math.max(MODE_MAX_SPEED_MPS[mode] * dtS + uncertaintyM, expectedStepM * 2 + uncertaintyM);
    return nativeStepM <= maximumStepM;
  }
  function newSegmentId(clientActivityId, at = Date.now()) {
    return `${clientActivityId}:${at}:${Math.random().toString(16).slice(2, 10)}`;
  }
  function saveEligibility(points, distanceM) {
    if (points.length < 2) return {
      eligible: false,
      reason: 'not-enough-points'
    };
    if (distanceM < 20) return {
      eligible: false,
      reason: 'not-enough-distance'
    };
    return {
      eligible: true,
      reason: 'eligible'
    };
  }
  function shouldStartNewSegment(args) {
    const {
      previous,
      next,
      mode,
      knownRecordingLoss = false
    } = args;
    if (!previous) return false;
    if (knownRecordingLoss) return true;
    const dtMs = next.t - previous.t;
    if (dtMs <= 0) return true;
    const dtS = dtMs / 1000;
    const distanceM = (0, _utilsGeo.haversineM)(previous, next);
    const previousAccuracy = previous.accuracy ?? 25;
    const nextAccuracy = next.accuracy ?? 25;
    const uncertaintyM = Math.max(25, previousAccuracy + nextAccuracy);
    const impliedSpeedMps = Math.max(0, distanceM - uncertaintyM) / dtS;
    const implausibleMovement = impliedSpeedMps > MODE_MAX_SPEED_MPS[mode];
    const longAndSpatiallyUncertain = dtMs > MAX_CREDITABLE_ACTIVE_INTERVAL_MS && (distanceM > uncertaintyM * 2 || previousAccuracy > 15 || nextAccuracy > 15);
    return implausibleMovement || longAndSpatiallyUncertain;
  }
  /**
   * Reconcile asynchronous foreground/background provenance without allowing a
   * late callback from an older provider context to move canonical truth back
   * into an earlier segment. A provider may introduce a different segment only
   * with an explicit boundary reason; physical continuity classification remains
   * the fallback authority when no durable boundary exists.
   */
  function resolveSegmentProvenance(args) {
    const incumbent = args.currentSegmentId ?? args.tailSegmentId;
    // The first accepted point establishes provenance. There is no earlier
    // canonical segment for an asynchronous callback to regress into.
    if (args.tailSegmentId === null) {
      return {
        segmentId: args.incomingSegmentId ?? incumbent,
        startsNewSegment: false,
        startReason: args.incomingStartReason,
        ignoredStaleIncoming: false
      };
    }
    const incomingDiffersFromIncumbent = Boolean(args.incomingSegmentId && incumbent && args.incomingSegmentId !== incumbent);
    const explicitIncomingBoundary = Boolean(args.incomingStartReason && (args.tailSegmentId === null || args.incomingSegmentId !== args.tailSegmentId));
    if (explicitIncomingBoundary) {
      // If the provider supplies a durable reason but no identifier, the
      // caller must allocate one. Reusing the incumbent would label a boundary
      // while silently preserving the old segment.
      const segmentId = args.incomingSegmentId ?? null;
      return {
        segmentId,
        startsNewSegment: Boolean(args.tailSegmentId),
        startReason: args.incomingStartReason,
        ignoredStaleIncoming: false
      };
    }
    if (args.pendingStartReason && args.currentSegmentId) {
      return {
        segmentId: args.currentSegmentId,
        startsNewSegment: Boolean(args.tailSegmentId && args.currentSegmentId !== args.tailSegmentId),
        startReason: args.pendingStartReason,
        ignoredStaleIncoming: incomingDiffersFromIncumbent
      };
    }
    if (args.physicalGap) {
      return {
        segmentId: null,
        startsNewSegment: true,
        startReason: 'gps-reacquired',
        ignoredStaleIncoming: incomingDiffersFromIncumbent
      };
    }
    return {
      segmentId: incomingDiffersFromIncumbent ? incumbent : args.incomingSegmentId ?? incumbent,
      startsNewSegment: false,
      ignoredStaleIncoming: incomingDiffersFromIncumbent
    };
  }
  function segmentTrace(points) {
    const segments = [];
    const gaps = [];
    let current = [];
    let previous = null;
    points.forEach((raw, index) => {
      const point = raw;
      const segmentId = point.segmentId || 'legacy-0';
      const normalized = {
        ...point,
        segmentId
      };
      const begins = index === 0 || !previous || segmentId !== previous.segmentId;
      if (begins) {
        if (current.length > 0) segments.push(current);
        if (previous) gaps.push({
          from: previous,
          to: normalized
        });
        current = [normalized];
      } else {
        current.push(normalized);
      }
      previous = normalized;
    });
    if (current.length > 0) segments.push(current);
    return {
      segments,
      gaps
    };
  }
  function calculateActivityStats(points) {
    let distanceM = 0;
    let legacyElevationGainM = 0;
    let activeDurationMs = 0;
    const normalized = points.map(point => ({
      ...point,
      segmentId: point.segmentId || 'legacy-0'
    }));
    for (let index = 1; index < normalized.length; index += 1) {
      const previous = normalized[index - 1];
      const next = normalized[index];
      if (previous.segmentId !== next.segmentId) continue;
      const dtMs = next.t - previous.t;
      if (dtMs <= 0) continue;
      distanceM += (0, _utilsGeo.haversineM)(previous, next);
      // Segment assignment is the continuity authority. Once two points are in
      // the same real segment, their full interval is active time; time alone
      // must not silently subtract duration. Untrusted intervals are represented
      // by different segment IDs before stats are calculated.
      activeDurationMs += dtMs;
      if (previous.alt != null && next.alt != null && next.alt > previous.alt) {
        legacyElevationGainM += next.alt - previous.alt;
      }
    }

    // Recovered/Simulator/legacy points may predate verticalAccuracy. Preserve
    // their historical behavior. A real native stream that supplies vertical
    // uncertainty uses the independent quality model instead.
    const hasVerticalQualityEvidence = normalized.some(point => point.verticalAccuracy != null);
    const elevationGainM = hasVerticalQualityEvidence ? (0, _elevationQuality.calculateQualityElevationGain)(normalized) : legacyElevationGainM;
    return {
      distanceM,
      elevationGainM,
      activeDurationS: Math.floor(activeDurationMs / 1000)
    };
  }
  function toServerPoint(point) {
    const segmented = point;
    return {
      lat: point.lat,
      lng: point.lng,
      // Core Location timestamps can contain fractional milliseconds on iOS.
      // The server contract is integer epoch milliseconds, so normalize at the
      // shared boundary (also repairs pre-fix pending payloads when replayed).
      t: Math.floor(point.t),
      ...(point.alt != null ? {
        alt: point.alt
      } : {}),
      ...(point.accuracy != null ? {
        acc: point.accuracy
      } : {}),
      ...(point.verticalAccuracy != null ? {
        v_acc: point.verticalAccuracy
      } : {}),
      ...(point.speed != null ? {
        speed_mps: point.speed
      } : {}),
      ...(point.course != null ? {
        course_deg: point.course
      } : {}),
      ...(point.rawOrdinal != null ? {
        raw_ordinal: point.rawOrdinal
      } : {}),
      ...(segmented.segmentId ? {
        segment_id: segmented.segmentId
      } : {}),
      ...(segmented.segmentStartReason ? {
        segment_start_reason: segmented.segmentStartReason
      } : {})
    };
  }
},630,[572,631],"src/features/activity/activityContracts.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "ELEVATION_QUALITY_VERSION", {
    enumerable: true,
    get: function () {
      return ELEVATION_QUALITY_VERSION;
    }
  });
  Object.defineProperty(exports, "MAX_VERTICAL_ACCURACY_M", {
    enumerable: true,
    get: function () {
      return MAX_VERTICAL_ACCURACY_M;
    }
  });
  exports.createElevationQualityState = createElevationQualityState;
  exports.reduceElevationObservation = reduceElevationObservation;
  exports.calculateQualityElevationGain = calculateQualityElevationGain;
  var _utilsGeo = require(_dependencyMap[0], "../../utils/geo");
  const ELEVATION_QUALITY_VERSION = 1;
  const MAX_VERTICAL_ACCURACY_M = 15;
  function createElevationQualityState(cumulativeGainM = 0) {
    return {
      version: ELEVATION_QUALITY_VERSION,
      segmentId: null,
      recentAltitudesM: [],
      filteredAltitudeM: null,
      gainAnchorM: null,
      pendingRiseStartedAtMs: null,
      pendingRiseDistanceM: 0,
      pendingRiseSamples: 0,
      previousPoint: null,
      cumulativeGainM
    };
  }
  function median(values) {
    const sorted = [...values].sort((a, b) => a - b);
    return sorted[Math.floor(sorted.length / 2)];
  }
  function clearPending(state) {
    return {
      ...state,
      pendingRiseStartedAtMs: null,
      pendingRiseDistanceM: 0,
      pendingRiseSamples: 0
    };
  }

  /**
   * Elevation has its own quality authority. O42 `wrong` proved that summing every
   * positive raw altitude delta turns symmetric vertical noise into fake climb.
   * This causal filter requires usable vertical accuracy, median/low-pass noise
   * reduction, a hysteresis band, and sustained time/distance before credit.
   */
  function reduceElevationObservation(currentState, point) {
    const rawAltitudeM = point.alt != null && Number.isFinite(point.alt) ? point.alt : null;
    const verticalAccuracyM = point.verticalAccuracy != null && Number.isFinite(point.verticalAccuracy) ? point.verticalAccuracy : null;
    const newSegment = currentState.segmentId !== point.segmentId;
    const base = newSegment ? {
      ...createElevationQualityState(currentState.cumulativeGainM),
      segmentId: point.segmentId
    } : currentState;
    if (rawAltitudeM === null) {
      return {
        state: {
          ...clearPending(base),
          previousPoint: point
        },
        rawAltitudeM,
        verticalAccuracyM,
        filteredAltitudeM: base.filteredAltitudeM,
        incrementM: 0,
        reason: 'missing-altitude'
      };
    }
    if (verticalAccuracyM === null || verticalAccuracyM < 0) {
      return {
        state: {
          ...clearPending(base),
          previousPoint: point
        },
        rawAltitudeM,
        verticalAccuracyM,
        filteredAltitudeM: base.filteredAltitudeM,
        incrementM: 0,
        reason: 'missing-vertical-accuracy'
      };
    }
    if (verticalAccuracyM > MAX_VERTICAL_ACCURACY_M) {
      return {
        state: {
          ...clearPending(base),
          previousPoint: point
        },
        rawAltitudeM,
        verticalAccuracyM,
        filteredAltitudeM: base.filteredAltitudeM,
        incrementM: 0,
        reason: 'poor-vertical-accuracy'
      };
    }
    const recentAltitudesM = [...base.recentAltitudesM, rawAltitudeM].slice(-3);
    const medianAltitudeM = median(recentAltitudesM);
    const filteredAltitudeM = base.filteredAltitudeM === null ? medianAltitudeM : base.filteredAltitudeM * 0.5 + medianAltitudeM * 0.5;
    if (base.gainAnchorM === null || newSegment) {
      return {
        state: {
          ...base,
          recentAltitudesM,
          filteredAltitudeM,
          gainAnchorM: filteredAltitudeM,
          previousPoint: point
        },
        rawAltitudeM,
        verticalAccuracyM,
        filteredAltitudeM,
        incrementM: 0,
        reason: 'segment-baseline'
      };
    }

    // O43 hypothesis-driven calibration. The forensic establishes the required
    // quality dimensions, while the exact noise band needs the next native walk.
    // Telemetry emits the raw/filtered values and every decision for adjustment.
    const noiseBandM = Math.min(12, Math.max(4, verticalAccuracyM * 0.8));
    const riseM = filteredAltitudeM - base.gainAnchorM;
    const horizontalStepM = base.previousPoint ? (0, _utilsGeo.haversineM)(base.previousPoint, point) : 0;
    if (riseM >= noiseBandM) {
      const pendingStartedAtMs = base.pendingRiseStartedAtMs ?? point.t;
      const pendingDistanceM = base.pendingRiseDistanceM + horizontalStepM;
      const pendingSamples = base.pendingRiseSamples + 1;
      const sustained = pendingSamples >= 3 || point.t - pendingStartedAtMs >= 6_000 && pendingDistanceM >= 8;
      if (sustained) {
        return {
          state: {
            ...base,
            recentAltitudesM,
            filteredAltitudeM,
            gainAnchorM: filteredAltitudeM,
            pendingRiseStartedAtMs: null,
            pendingRiseDistanceM: 0,
            pendingRiseSamples: 0,
            previousPoint: point,
            cumulativeGainM: base.cumulativeGainM + riseM
          },
          rawAltitudeM,
          verticalAccuracyM,
          filteredAltitudeM,
          incrementM: riseM,
          reason: 'sustained-rise-credited'
        };
      }
      return {
        state: {
          ...base,
          recentAltitudesM,
          filteredAltitudeM,
          pendingRiseStartedAtMs: pendingStartedAtMs,
          pendingRiseDistanceM: pendingDistanceM,
          pendingRiseSamples: pendingSamples,
          previousPoint: point
        },
        rawAltitudeM,
        verticalAccuracyM,
        filteredAltitudeM,
        incrementM: 0,
        reason: 'pending-sustained-rise'
      };
    }
    if (riseM <= -noiseBandM) {
      return {
        state: {
          ...clearPending(base),
          recentAltitudesM,
          filteredAltitudeM,
          gainAnchorM: filteredAltitudeM,
          previousPoint: point
        },
        rawAltitudeM,
        verticalAccuracyM,
        filteredAltitudeM,
        incrementM: 0,
        reason: 'descent-anchor-reset'
      };
    }
    return {
      state: {
        ...clearPending(base),
        recentAltitudesM,
        filteredAltitudeM,
        previousPoint: point
      },
      rawAltitudeM,
      verticalAccuracyM,
      filteredAltitudeM,
      incrementM: 0,
      reason: 'within-vertical-noise-band'
    };
  }
  function calculateQualityElevationGain(points) {
    let state = createElevationQualityState();
    for (const point of points) state = reduceElevationObservation(state, point).state;
    // Finish may arrive while a genuinely sustained final climb is one sample
    // short of the live confirmation threshold. Credit only a two-sample tail;
    // a lone positive spike remains excluded.
    const supportedTailRiseM = state.pendingRiseSamples >= 2 && state.pendingRiseDistanceM >= 8 && state.pendingRiseStartedAtMs !== null && state.previousPoint !== null && state.previousPoint.t - state.pendingRiseStartedAtMs >= 5_000 && state.filteredAltitudeM !== null && state.gainAnchorM !== null ? Math.max(0, state.filteredAltitudeM - state.gainAnchorM) : 0;
    return state.cumulativeGainM + supportedTailRiseM;
  }
},631,[572],"src/features/activity/elevationQuality.ts");
//# sourceMappingURL=http://127.0.0.1:8087/src/features/activity/activityContracts.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false