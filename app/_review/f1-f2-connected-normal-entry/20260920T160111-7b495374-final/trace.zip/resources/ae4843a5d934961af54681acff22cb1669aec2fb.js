__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},8,[],"node_modules/metro-runtime/src/modules/empty-module.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _vendorEmitterEventEmitter = require(_dependencyMap[0], "../vendor/emitter/EventEmitter");
  var EventEmitter = _interopDefault(_vendorEmitterEventEmitter);
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   * @format
   */

  // FIXME: use typed events

  /**
   * Global EventEmitter used by the native platform to emit events to JavaScript.
   * Events are identified by globally unique event names.
   *
   * NativeModules that emit events should instead subclass `NativeEventEmitter`.
   */
  var _default = new EventEmitter.default();
},29,[30],"node_modules/react-native-web/dist/vendor/react-native/EventEmitter/RCTDeviceEventEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return EventEmitter;
    }
  });
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   * @format
   */

  /**
   * EventEmitter manages listeners and publishes events to them.
   *
   * EventEmitter accepts a single type parameter that defines the valid events
   * and associated listener argument(s).
   *
   * @example
   *
   *   const emitter = new EventEmitter<{
   *     success: [number, string],
   *     error: [Error],
   *   }>();
   *
   *   emitter.on('success', (statusCode, responseText) => {...});
   *   emitter.emit('success', 200, '...');
   *
   *   emitter.on('error', error => {...});
   *   emitter.emit('error', new Error('Resource not found'));
   *
   */
  class EventEmitter {
    constructor() {
      this._registry = {};
    }
    /**
     * Registers a listener that is called when the supplied event is emitted.
     * Returns a subscription that has a `remove` method to undo registration.
     */
    addListener(eventType, listener, context) {
      var registrations = allocate(this._registry, eventType);
      var registration = {
        context,
        listener,
        remove() {
          registrations.delete(registration);
        }
      };
      registrations.add(registration);
      return registration;
    }

    /**
     * Emits the supplied event. Additional arguments supplied to `emit` will be
     * passed through to each of the registered listeners.
     *
     * If a listener modifies the listeners registered for the same event, those
     * changes will not be reflected in the current invocation of `emit`.
     */
    emit(eventType) {
      var registrations = this._registry[eventType];
      if (registrations != null) {
        for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          args[_key - 1] = arguments[_key];
        }
        for (var _i = 0, _arr = [...registrations]; _i < _arr.length; _i++) {
          var registration = _arr[_i];
          registration.listener.apply(registration.context, args);
        }
      }
    }

    /**
     * Removes all registered listeners.
     */
    removeAllListeners(eventType) {
      if (eventType == null) {
        this._registry = {};
      } else {
        delete this._registry[eventType];
      }
    }

    /**
     * Returns the number of registered listeners for the supplied event.
     */
    listenerCount(eventType) {
      var registrations = this._registry[eventType];
      return registrations == null ? 0 : registrations.size;
    }
  }
  function allocate(registry, eventType) {
    var registrations = registry[eventType];
    if (registrations == null) {
      registrations = new Set();
      registry[eventType] = registrations;
    }
    return registrations;
  }
},30,[],"node_modules/react-native-web/dist/vendor/react-native/vendor/emitter/EventEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _objectSpread2;
    }
  });
  var _definePropertyJs = require(_dependencyMap[0], "./defineProperty.js");
  var defineProperty = _interopDefault(_definePropertyJs);
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
        (0, defineProperty.default)(e, r, t[r]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
        Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
      });
    }
    return e;
  }
},47,[48],"node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _defineProperty;
    }
  });
  var _toPropertyKeyJs = require(_dependencyMap[0], "./toPropertyKey.js");
  var toPropertyKey = _interopDefault(_toPropertyKeyJs);
  function _defineProperty(e, r, t) {
    return (r = (0, toPropertyKey.default)(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
},48,[49],"node_modules/@babel/runtime/helpers/esm/defineProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return toPropertyKey;
    }
  });
  var _typeofJs = require(_dependencyMap[0], "./typeof.js");
  var _typeof = _interopDefault(_typeofJs);
  var _toPrimitiveJs = require(_dependencyMap[1], "./toPrimitive.js");
  var toPrimitive = _interopDefault(_toPrimitiveJs);
  function toPropertyKey(t) {
    var i = (0, toPrimitive.default)(t, "string");
    return "symbol" == (0, _typeof.default)(i) ? i : i + "";
  }
},49,[50,51],"node_modules/@babel/runtime/helpers/esm/toPropertyKey.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _typeof;
    }
  });
  function _typeof(o) {
    "@babel/helpers - typeof";

    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
      return typeof o;
    } : function (o) {
      return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
  }
},50,[],"node_modules/@babel/runtime/helpers/esm/typeof.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return toPrimitive;
    }
  });
  var _typeofJs = require(_dependencyMap[0], "./typeof.js");
  var _typeof = _interopDefault(_typeofJs);
  function toPrimitive(t, r) {
    if ("object" != (0, _typeof.default)(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != (0, _typeof.default)(i)) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
},51,[50],"node_modules/@babel/runtime/helpers/esm/toPrimitive.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  'use strict';

  var validateFormat = process.env.NODE_ENV !== "production" ? function (format) {
    if (format === undefined) {
      throw new Error('invariant(...): Second argument must be a string.');
    }
  } : function (format) {};
  /**
   * Use invariant() to assert state which your program assumes to be true.
   *
   * Provide sprintf-style format (only %s is supported) and arguments to provide
   * information about what broke and what you were expecting.
   *
   * The invariant message will be stripped in production, but the invariant will
   * remain to ensure logic does not differ in production.
   */

  function invariant(condition, format) {
    for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
      args[_key - 2] = arguments[_key];
    }
    validateFormat(format);
    if (!condition) {
      var error;
      if (format === undefined) {
        error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
      } else {
        var argIndex = 0;
        error = new Error(format.replace(/%s/g, function () {
          return String(args[argIndex++]);
        }));
        error.name = 'Invariant Violation';
      }
      error.framesToPop = 1; // Skip invariant's own stack frame.

      throw error;
    }
  }
  module.exports = invariant;
},52,[],"node_modules/fbjs/lib/invariant.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _extends;
    }
  });
  function _extends() {
    return _extends = Object.assign ? Object.assign.bind() : function (n) {
      for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e];
        for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
      }
      return n;
    }, _extends.apply(null, arguments);
  }
},55,[],"node_modules/@babel/runtime/helpers/esm/extends.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  if (process.env.NODE_ENV === 'production') {
    module.exports = require(_dependencyMap[0], "./cjs/react.production.js");
  } else {
    module.exports = require(_dependencyMap[1], "./cjs/react.development.js");
  }
},62,[8,63],"node_modules/react/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * @license React
   * react.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  "use strict";

  "production" !== process.env.NODE_ENV && function () {
    function defineDeprecationWarning(methodName, info) {
      Object.defineProperty(Component.prototype, methodName, {
        get: function () {
          console.warn("%s(...) is deprecated in plain JavaScript React classes. %s", info[0], info[1]);
        }
      });
    }
    function getIteratorFn(maybeIterable) {
      if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
      maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
      return "function" === typeof maybeIterable ? maybeIterable : null;
    }
    function warnNoop(publicInstance, callerName) {
      publicInstance = (publicInstance = publicInstance.constructor) && (publicInstance.displayName || publicInstance.name) || "ReactClass";
      var warningKey = publicInstance + "." + callerName;
      didWarnStateUpdateForUnmountedComponent[warningKey] || (console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", callerName, publicInstance), didWarnStateUpdateForUnmountedComponent[warningKey] = !0);
    }
    function Component(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function ComponentDummy() {}
    function PureComponent(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function testStringCoercion(value) {
      return "" + value;
    }
    function checkKeyStringCoercion(value) {
      try {
        testStringCoercion(value);
        var JSCompiler_inline_result = !1;
      } catch (e) {
        JSCompiler_inline_result = !0;
      }
      if (JSCompiler_inline_result) {
        JSCompiler_inline_result = console;
        var JSCompiler_temp_const = JSCompiler_inline_result.error;
        var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
        JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
        return testStringCoercion(value);
      }
    }
    function getComponentNameFromType(type) {
      if (null == type) return null;
      if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
      if ("string" === typeof type) return type;
      switch (type) {
        case REACT_FRAGMENT_TYPE:
          return "Fragment";
        case REACT_PROFILER_TYPE:
          return "Profiler";
        case REACT_STRICT_MODE_TYPE:
          return "StrictMode";
        case REACT_SUSPENSE_TYPE:
          return "Suspense";
        case REACT_SUSPENSE_LIST_TYPE:
          return "SuspenseList";
        case REACT_ACTIVITY_TYPE:
          return "Activity";
      }
      if ("object" === typeof type) switch ("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof) {
        case REACT_PORTAL_TYPE:
          return "Portal";
        case REACT_CONTEXT_TYPE:
          return (type.displayName || "Context") + ".Provider";
        case REACT_CONSUMER_TYPE:
          return (type._context.displayName || "Context") + ".Consumer";
        case REACT_FORWARD_REF_TYPE:
          var innerType = type.render;
          type = type.displayName;
          type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
          return type;
        case REACT_MEMO_TYPE:
          return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
        case REACT_LAZY_TYPE:
          innerType = type._payload;
          type = type._init;
          try {
            return getComponentNameFromType(type(innerType));
          } catch (x) {}
      }
      return null;
    }
    function getTaskName(type) {
      if (type === REACT_FRAGMENT_TYPE) return "<>";
      if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
      try {
        var name = getComponentNameFromType(type);
        return name ? "<" + name + ">" : "<...>";
      } catch (x) {
        return "<...>";
      }
    }
    function getOwner() {
      var dispatcher = ReactSharedInternals.A;
      return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
      return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
      if (hasOwnProperty.call(config, "key")) {
        var getter = Object.getOwnPropertyDescriptor(config, "key").get;
        if (getter && getter.isReactWarning) return !1;
      }
      return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
      function warnAboutAccessingKey() {
        specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
      }
      warnAboutAccessingKey.isReactWarning = !0;
      Object.defineProperty(props, "key", {
        get: warnAboutAccessingKey,
        configurable: !0
      });
    }
    function elementRefGetterWithDeprecationWarning() {
      var componentName = getComponentNameFromType(this.type);
      didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
      componentName = this.props.ref;
      return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, self, source, owner, props, debugStack, debugTask) {
      self = props.ref;
      type = {
        $$typeof: REACT_ELEMENT_TYPE,
        type: type,
        key: key,
        props: props,
        _owner: owner
      };
      null !== (void 0 !== self ? self : null) ? Object.defineProperty(type, "ref", {
        enumerable: !1,
        get: elementRefGetterWithDeprecationWarning
      }) : Object.defineProperty(type, "ref", {
        enumerable: !1,
        value: null
      });
      type._store = {};
      Object.defineProperty(type._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: 0
      });
      Object.defineProperty(type, "_debugInfo", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: null
      });
      Object.defineProperty(type, "_debugStack", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugStack
      });
      Object.defineProperty(type, "_debugTask", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugTask
      });
      Object.freeze && (Object.freeze(type.props), Object.freeze(type));
      return type;
    }
    function cloneAndReplaceKey(oldElement, newKey) {
      newKey = ReactElement(oldElement.type, newKey, void 0, void 0, oldElement._owner, oldElement.props, oldElement._debugStack, oldElement._debugTask);
      oldElement._store && (newKey._store.validated = oldElement._store.validated);
      return newKey;
    }
    function isValidElement(object) {
      return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    function escape(key) {
      var escaperLookup = {
        "=": "=0",
        ":": "=2"
      };
      return "$" + key.replace(/[=:]/g, function (match) {
        return escaperLookup[match];
      });
    }
    function getElementKey(element, index) {
      return "object" === typeof element && null !== element && null != element.key ? (checkKeyStringCoercion(element.key), escape("" + element.key)) : index.toString(36);
    }
    function noop$1() {}
    function resolveThenable(thenable) {
      switch (thenable.status) {
        case "fulfilled":
          return thenable.value;
        case "rejected":
          throw thenable.reason;
        default:
          switch ("string" === typeof thenable.status ? thenable.then(noop$1, noop$1) : (thenable.status = "pending", thenable.then(function (fulfilledValue) {
            "pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
          }, function (error) {
            "pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
          })), thenable.status) {
            case "fulfilled":
              return thenable.value;
            case "rejected":
              throw thenable.reason;
          }
      }
      throw thenable;
    }
    function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
      var type = typeof children;
      if ("undefined" === type || "boolean" === type) children = null;
      var invokeCallback = !1;
      if (null === children) invokeCallback = !0;else switch (type) {
        case "bigint":
        case "string":
        case "number":
          invokeCallback = !0;
          break;
        case "object":
          switch (children.$$typeof) {
            case REACT_ELEMENT_TYPE:
            case REACT_PORTAL_TYPE:
              invokeCallback = !0;
              break;
            case REACT_LAZY_TYPE:
              return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
          }
      }
      if (invokeCallback) {
        invokeCallback = children;
        callback = callback(invokeCallback);
        var childKey = "" === nameSoFar ? "." + getElementKey(invokeCallback, 0) : nameSoFar;
        isArrayImpl(callback) ? (escapedPrefix = "", null != childKey && (escapedPrefix = childKey.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function (c) {
          return c;
        })) : null != callback && (isValidElement(callback) && (null != callback.key && (invokeCallback && invokeCallback.key === callback.key || checkKeyStringCoercion(callback.key)), escapedPrefix = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || invokeCallback && invokeCallback.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + childKey), "" !== nameSoFar && null != invokeCallback && isValidElement(invokeCallback) && null == invokeCallback.key && invokeCallback._store && !invokeCallback._store.validated && (escapedPrefix._store.validated = 2), callback = escapedPrefix), array.push(callback));
        return 1;
      }
      invokeCallback = 0;
      childKey = "" === nameSoFar ? "." : nameSoFar + ":";
      if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = childKey + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if (i = getIteratorFn(children), "function" === typeof i) for (i === children.entries && (didWarnAboutMaps || console.warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), didWarnAboutMaps = !0), children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = childKey + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if ("object" === type) {
        if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
        array = String(children);
        throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
      }
      return invokeCallback;
    }
    function mapChildren(children, func, context) {
      if (null == children) return children;
      var result = [],
        count = 0;
      mapIntoArray(children, result, "", "", function (child) {
        return func.call(context, child, count++);
      });
      return result;
    }
    function lazyInitializer(payload) {
      if (-1 === payload._status) {
        var ctor = payload._result;
        ctor = ctor();
        ctor.then(function (moduleObject) {
          if (0 === payload._status || -1 === payload._status) payload._status = 1, payload._result = moduleObject;
        }, function (error) {
          if (0 === payload._status || -1 === payload._status) payload._status = 2, payload._result = error;
        });
        -1 === payload._status && (payload._status = 0, payload._result = ctor);
      }
      if (1 === payload._status) return ctor = payload._result, void 0 === ctor && console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))\n\nDid you accidentally put curly braces around the import?", ctor), "default" in ctor || console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))", ctor), ctor.default;
      throw payload._result;
    }
    function resolveDispatcher() {
      var dispatcher = ReactSharedInternals.H;
      null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
      return dispatcher;
    }
    function noop() {}
    function enqueueTask(task) {
      if (null === enqueueTaskImpl) try {
        var requireString = ("require" + Math.random()).slice(0, 7);
        enqueueTaskImpl = (module && module[requireString]).call(module, "timers").setImmediate;
      } catch (_err) {
        enqueueTaskImpl = function (callback) {
          !1 === didWarnAboutMessageChannel && (didWarnAboutMessageChannel = !0, "undefined" === typeof MessageChannel && console.error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
          var channel = new MessageChannel();
          channel.port1.onmessage = callback;
          channel.port2.postMessage(void 0);
        };
      }
      return enqueueTaskImpl(task);
    }
    function aggregateErrors(errors) {
      return 1 < errors.length && "function" === typeof AggregateError ? new AggregateError(errors) : errors[0];
    }
    function popActScope(prevActQueue, prevActScopeDepth) {
      prevActScopeDepth !== actScopeDepth - 1 && console.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
      actScopeDepth = prevActScopeDepth;
    }
    function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
      var queue = ReactSharedInternals.actQueue;
      if (null !== queue) if (0 !== queue.length) try {
        flushActQueue(queue);
        enqueueTask(function () {
          return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
        });
        return;
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      } else ReactSharedInternals.actQueue = null;
      0 < ReactSharedInternals.thrownErrors.length ? (queue = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(queue)) : resolve(returnValue);
    }
    function flushActQueue(queue) {
      if (!isFlushing) {
        isFlushing = !0;
        var i = 0;
        try {
          for (; i < queue.length; i++) {
            var callback = queue[i];
            do {
              ReactSharedInternals.didUsePromise = !1;
              var continuation = callback(!1);
              if (null !== continuation) {
                if (ReactSharedInternals.didUsePromise) {
                  queue[i] = callback;
                  queue.splice(0, i);
                  return;
                }
                callback = continuation;
              } else break;
            } while (1);
          }
          queue.length = 0;
        } catch (error) {
          queue.splice(0, i + 1), ReactSharedInternals.thrownErrors.push(error);
        } finally {
          isFlushing = !1;
        }
      }
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
      REACT_PORTAL_TYPE = Symbol.for("react.portal"),
      REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"),
      REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"),
      REACT_PROFILER_TYPE = Symbol.for("react.profiler");
    Symbol.for("react.provider");
    var REACT_CONSUMER_TYPE = Symbol.for("react.consumer"),
      REACT_CONTEXT_TYPE = Symbol.for("react.context"),
      REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"),
      REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"),
      REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"),
      REACT_MEMO_TYPE = Symbol.for("react.memo"),
      REACT_LAZY_TYPE = Symbol.for("react.lazy"),
      REACT_ACTIVITY_TYPE = Symbol.for("react.activity"),
      MAYBE_ITERATOR_SYMBOL = Symbol.iterator,
      didWarnStateUpdateForUnmountedComponent = {},
      ReactNoopUpdateQueue = {
        isMounted: function () {
          return !1;
        },
        enqueueForceUpdate: function (publicInstance) {
          warnNoop(publicInstance, "forceUpdate");
        },
        enqueueReplaceState: function (publicInstance) {
          warnNoop(publicInstance, "replaceState");
        },
        enqueueSetState: function (publicInstance) {
          warnNoop(publicInstance, "setState");
        }
      },
      assign = Object.assign,
      emptyObject = {};
    Object.freeze(emptyObject);
    Component.prototype.isReactComponent = {};
    Component.prototype.setState = function (partialState, callback) {
      if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, partialState, callback, "setState");
    };
    Component.prototype.forceUpdate = function (callback) {
      this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
    };
    var deprecatedAPIs = {
        isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
        replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
      },
      fnName;
    for (fnName in deprecatedAPIs) deprecatedAPIs.hasOwnProperty(fnName) && defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
    ComponentDummy.prototype = Component.prototype;
    deprecatedAPIs = PureComponent.prototype = new ComponentDummy();
    deprecatedAPIs.constructor = PureComponent;
    assign(deprecatedAPIs, Component.prototype);
    deprecatedAPIs.isPureReactComponent = !0;
    var isArrayImpl = Array.isArray,
      REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"),
      ReactSharedInternals = {
        H: null,
        A: null,
        T: null,
        S: null,
        V: null,
        actQueue: null,
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1,
        didUsePromise: !1,
        thrownErrors: [],
        getCurrentStack: null,
        recentlyCreatedOwnerStacks: 0
      },
      hasOwnProperty = Object.prototype.hasOwnProperty,
      createTask = console.createTask ? console.createTask : function () {
        return null;
      };
    deprecatedAPIs = {
      "react-stack-bottom-frame": function (callStackForError) {
        return callStackForError();
      }
    };
    var specialPropKeyWarningShown, didWarnAboutOldJSXRuntime;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = deprecatedAPIs["react-stack-bottom-frame"].bind(deprecatedAPIs, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutMaps = !1,
      userProvidedKeyEscapeRegex = /\/+/g,
      reportGlobalError = "function" === typeof reportError ? reportError : function (error) {
        if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
          var event = new window.ErrorEvent("error", {
            bubbles: !0,
            cancelable: !0,
            message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
            error: error
          });
          if (!window.dispatchEvent(event)) return;
        } else if ("object" === typeof process && "function" === typeof process.emit) {
          process.emit("uncaughtException", error);
          return;
        }
        console.error(error);
      },
      didWarnAboutMessageChannel = !1,
      enqueueTaskImpl = null,
      actScopeDepth = 0,
      didWarnNoAwaitAct = !1,
      isFlushing = !1,
      queueSeveralMicrotasks = "function" === typeof queueMicrotask ? function (callback) {
        queueMicrotask(function () {
          return queueMicrotask(callback);
        });
      } : enqueueTask;
    deprecatedAPIs = Object.freeze({
      __proto__: null,
      c: function (size) {
        return resolveDispatcher().useMemoCache(size);
      }
    });
    exports.Children = {
      map: mapChildren,
      forEach: function (children, forEachFunc, forEachContext) {
        mapChildren(children, function () {
          forEachFunc.apply(this, arguments);
        }, forEachContext);
      },
      count: function (children) {
        var n = 0;
        mapChildren(children, function () {
          n++;
        });
        return n;
      },
      toArray: function (children) {
        return mapChildren(children, function (child) {
          return child;
        }) || [];
      },
      only: function (children) {
        if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
        return children;
      }
    };
    exports.Component = Component;
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.Profiler = REACT_PROFILER_TYPE;
    exports.PureComponent = PureComponent;
    exports.StrictMode = REACT_STRICT_MODE_TYPE;
    exports.Suspense = REACT_SUSPENSE_TYPE;
    exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
    exports.__COMPILER_RUNTIME = deprecatedAPIs;
    exports.act = function (callback) {
      var prevActQueue = ReactSharedInternals.actQueue,
        prevActScopeDepth = actScopeDepth;
      actScopeDepth++;
      var queue = ReactSharedInternals.actQueue = null !== prevActQueue ? prevActQueue : [],
        didAwaitActCall = !1;
      try {
        var result = callback();
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      }
      if (0 < ReactSharedInternals.thrownErrors.length) throw popActScope(prevActQueue, prevActScopeDepth), callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      if (null !== result && "object" === typeof result && "function" === typeof result.then) {
        var thenable = result;
        queueSeveralMicrotasks(function () {
          didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
        });
        return {
          then: function (resolve, reject) {
            didAwaitActCall = !0;
            thenable.then(function (returnValue) {
              popActScope(prevActQueue, prevActScopeDepth);
              if (0 === prevActScopeDepth) {
                try {
                  flushActQueue(queue), enqueueTask(function () {
                    return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
                  });
                } catch (error$0) {
                  ReactSharedInternals.thrownErrors.push(error$0);
                }
                if (0 < ReactSharedInternals.thrownErrors.length) {
                  var _thrownError = aggregateErrors(ReactSharedInternals.thrownErrors);
                  ReactSharedInternals.thrownErrors.length = 0;
                  reject(_thrownError);
                }
              } else resolve(returnValue);
            }, function (error) {
              popActScope(prevActQueue, prevActScopeDepth);
              0 < ReactSharedInternals.thrownErrors.length ? (error = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(error)) : reject(error);
            });
          }
        };
      }
      var returnValue$jscomp$0 = result;
      popActScope(prevActQueue, prevActScopeDepth);
      0 === prevActScopeDepth && (flushActQueue(queue), 0 !== queue.length && queueSeveralMicrotasks(function () {
        didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"));
      }), ReactSharedInternals.actQueue = null);
      if (0 < ReactSharedInternals.thrownErrors.length) throw callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      return {
        then: function (resolve, reject) {
          didAwaitActCall = !0;
          0 === prevActScopeDepth ? (ReactSharedInternals.actQueue = queue, enqueueTask(function () {
            return recursivelyFlushAsyncActWork(returnValue$jscomp$0, resolve, reject);
          })) : resolve(returnValue$jscomp$0);
        }
      };
    };
    exports.cache = function (fn) {
      return function () {
        return fn.apply(null, arguments);
      };
    };
    exports.captureOwnerStack = function () {
      var getCurrentStack = ReactSharedInternals.getCurrentStack;
      return null === getCurrentStack ? null : getCurrentStack();
    };
    exports.cloneElement = function (element, config, children) {
      if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
      var props = assign({}, element.props),
        key = element.key,
        owner = element._owner;
      if (null != config) {
        var JSCompiler_inline_result;
        a: {
          if (hasOwnProperty.call(config, "ref") && (JSCompiler_inline_result = Object.getOwnPropertyDescriptor(config, "ref").get) && JSCompiler_inline_result.isReactWarning) {
            JSCompiler_inline_result = !1;
            break a;
          }
          JSCompiler_inline_result = void 0 !== config.ref;
        }
        JSCompiler_inline_result && (owner = getOwner());
        hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key);
        for (propName in config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
      }
      var propName = arguments.length - 2;
      if (1 === propName) props.children = children;else if (1 < propName) {
        JSCompiler_inline_result = Array(propName);
        for (var i = 0; i < propName; i++) JSCompiler_inline_result[i] = arguments[i + 2];
        props.children = JSCompiler_inline_result;
      }
      props = ReactElement(element.type, key, void 0, void 0, owner, props, element._debugStack, element._debugTask);
      for (key = 2; key < arguments.length; key++) owner = arguments[key], isValidElement(owner) && owner._store && (owner._store.validated = 1);
      return props;
    };
    exports.createContext = function (defaultValue) {
      defaultValue = {
        $$typeof: REACT_CONTEXT_TYPE,
        _currentValue: defaultValue,
        _currentValue2: defaultValue,
        _threadCount: 0,
        Provider: null,
        Consumer: null
      };
      defaultValue.Provider = defaultValue;
      defaultValue.Consumer = {
        $$typeof: REACT_CONSUMER_TYPE,
        _context: defaultValue
      };
      defaultValue._currentRenderer = null;
      defaultValue._currentRenderer2 = null;
      return defaultValue;
    };
    exports.createElement = function (type, config, children) {
      for (var i = 2; i < arguments.length; i++) {
        var node = arguments[i];
        isValidElement(node) && node._store && (node._store.validated = 1);
      }
      i = {};
      node = null;
      if (null != config) for (propName in didWarnAboutOldJSXRuntime || !("__self" in config) || "key" in config || (didWarnAboutOldJSXRuntime = !0, console.warn("Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform")), hasValidKey(config) && (checkKeyStringCoercion(config.key), node = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (i[propName] = config[propName]);
      var childrenLength = arguments.length - 2;
      if (1 === childrenLength) i.children = children;else if (1 < childrenLength) {
        for (var childArray = Array(childrenLength), _i = 0; _i < childrenLength; _i++) childArray[_i] = arguments[_i + 2];
        Object.freeze && Object.freeze(childArray);
        i.children = childArray;
      }
      if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === i[propName] && (i[propName] = childrenLength[propName]);
      node && defineKeyPropWarningGetter(i, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
      var propName = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
      return ReactElement(type, node, void 0, void 0, getOwner(), i, propName ? Error("react-stack-top-frame") : unknownOwnerDebugStack, propName ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
    exports.createRef = function () {
      var refObject = {
        current: null
      };
      Object.seal(refObject);
      return refObject;
    };
    exports.forwardRef = function (render) {
      null != render && render.$$typeof === REACT_MEMO_TYPE ? console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : "function" !== typeof render ? console.error("forwardRef requires a render function but was given %s.", null === render ? "null" : typeof render) : 0 !== render.length && 2 !== render.length && console.error("forwardRef render functions accept exactly two parameters: props and ref. %s", 1 === render.length ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined.");
      null != render && null != render.defaultProps && console.error("forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?");
      var elementType = {
          $$typeof: REACT_FORWARD_REF_TYPE,
          render: render
        },
        ownName;
      Object.defineProperty(elementType, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          render.name || render.displayName || (Object.defineProperty(render, "name", {
            value: name
          }), render.displayName = name);
        }
      });
      return elementType;
    };
    exports.isValidElement = isValidElement;
    exports.lazy = function (ctor) {
      return {
        $$typeof: REACT_LAZY_TYPE,
        _payload: {
          _status: -1,
          _result: ctor
        },
        _init: lazyInitializer
      };
    };
    exports.memo = function (type, compare) {
      null == type && console.error("memo: The first argument must be a component. Instead received: %s", null === type ? "null" : typeof type);
      compare = {
        $$typeof: REACT_MEMO_TYPE,
        type: type,
        compare: void 0 === compare ? null : compare
      };
      var ownName;
      Object.defineProperty(compare, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          type.name || type.displayName || (Object.defineProperty(type, "name", {
            value: name
          }), type.displayName = name);
        }
      });
      return compare;
    };
    exports.startTransition = function (scope) {
      var prevTransition = ReactSharedInternals.T,
        currentTransition = {};
      ReactSharedInternals.T = currentTransition;
      currentTransition._updatedFibers = new Set();
      try {
        var returnValue = scope(),
          onStartTransitionFinish = ReactSharedInternals.S;
        null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
        "object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && returnValue.then(noop, reportGlobalError);
      } catch (error) {
        reportGlobalError(error);
      } finally {
        null === prevTransition && currentTransition._updatedFibers && (scope = currentTransition._updatedFibers.size, currentTransition._updatedFibers.clear(), 10 < scope && console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.")), ReactSharedInternals.T = prevTransition;
      }
    };
    exports.unstable_useCacheRefresh = function () {
      return resolveDispatcher().useCacheRefresh();
    };
    exports.use = function (usable) {
      return resolveDispatcher().use(usable);
    };
    exports.useActionState = function (action, initialState, permalink) {
      return resolveDispatcher().useActionState(action, initialState, permalink);
    };
    exports.useCallback = function (callback, deps) {
      return resolveDispatcher().useCallback(callback, deps);
    };
    exports.useContext = function (Context) {
      var dispatcher = resolveDispatcher();
      Context.$$typeof === REACT_CONSUMER_TYPE && console.error("Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?");
      return dispatcher.useContext(Context);
    };
    exports.useDebugValue = function (value, formatterFn) {
      return resolveDispatcher().useDebugValue(value, formatterFn);
    };
    exports.useDeferredValue = function (value, initialValue) {
      return resolveDispatcher().useDeferredValue(value, initialValue);
    };
    exports.useEffect = function (create, createDeps, update) {
      null == create && console.warn("React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      var dispatcher = resolveDispatcher();
      if ("function" === typeof update) throw Error("useEffect CRUD overload is not enabled in this build of React.");
      return dispatcher.useEffect(create, createDeps);
    };
    exports.useId = function () {
      return resolveDispatcher().useId();
    };
    exports.useImperativeHandle = function (ref, create, deps) {
      return resolveDispatcher().useImperativeHandle(ref, create, deps);
    };
    exports.useInsertionEffect = function (create, deps) {
      null == create && console.warn("React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useInsertionEffect(create, deps);
    };
    exports.useLayoutEffect = function (create, deps) {
      null == create && console.warn("React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useLayoutEffect(create, deps);
    };
    exports.useMemo = function (create, deps) {
      return resolveDispatcher().useMemo(create, deps);
    };
    exports.useOptimistic = function (passthrough, reducer) {
      return resolveDispatcher().useOptimistic(passthrough, reducer);
    };
    exports.useReducer = function (reducer, initialArg, init) {
      return resolveDispatcher().useReducer(reducer, initialArg, init);
    };
    exports.useRef = function (initialValue) {
      return resolveDispatcher().useRef(initialValue);
    };
    exports.useState = function (initialState) {
      return resolveDispatcher().useState(initialState);
    };
    exports.useSyncExternalStore = function (subscribe, getSnapshot, getServerSnapshot) {
      return resolveDispatcher().useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
    };
    exports.useTransition = function () {
      return resolveDispatcher().useTransition();
    };
    exports.version = "19.1.0";
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
  }();
},63,[],"node_modules/react/cjs/react.development.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.createSheet = createSheet;
  var _modulesCanUseDom = require(_dependencyMap[0], "../../../modules/canUseDom");
  var canUseDOM = _interopDefault(_modulesCanUseDom);
  var _createCSSStyleSheet = require(_dependencyMap[1], "./createCSSStyleSheet");
  var createCSSStyleSheet = _interopDefault(_createCSSStyleSheet);
  var _createOrderedCSSStyleSheet = require(_dependencyMap[2], "./createOrderedCSSStyleSheet");
  var createOrderedCSSStyleSheet = _interopDefault(_createOrderedCSSStyleSheet);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var defaultId = 'react-native-stylesheet';
  var roots = new WeakMap();
  var sheets = [];
  var initialRules = [
  // minimal top-level reset
  'html{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:rgba(0,0,0,0);}', 'body{margin:0;}',
  // minimal form pseudo-element reset
  'button::-moz-focus-inner,input::-moz-focus-inner{border:0;padding:0;}', 'input::-webkit-search-cancel-button,input::-webkit-search-decoration,input::-webkit-search-results-button,input::-webkit-search-results-decoration{display:none;}'];
  function createSheet(root, id) {
    if (id === void 0) {
      id = defaultId;
    }
    var sheet;
    if (canUseDOM.default) {
      var rootNode = root != null ? root.getRootNode() : document;
      // Create the initial style sheet
      if (sheets.length === 0) {
        sheet = (0, createOrderedCSSStyleSheet.default)((0, createCSSStyleSheet.default)(id));
        initialRules.forEach(rule => {
          sheet.insert(rule, 0);
        });
        roots.set(rootNode, sheets.length);
        sheets.push(sheet);
      } else {
        var index = roots.get(rootNode);
        if (index == null) {
          var initialSheet = sheets[0];
          // If we're creating a new sheet, populate it with existing styles
          var textContent = initialSheet != null ? initialSheet.getTextContent() : '';
          // Cast rootNode to 'any' because Flow types for getRootNode are wrong
          sheet = (0, createOrderedCSSStyleSheet.default)((0, createCSSStyleSheet.default)(id, rootNode, textContent));
          roots.set(rootNode, sheets.length);
          sheets.push(sheet);
        } else {
          sheet = sheets[index];
        }
      }
    } else {
      // Create the initial style sheet
      if (sheets.length === 0) {
        sheet = (0, createOrderedCSSStyleSheet.default)((0, createCSSStyleSheet.default)(id));
        initialRules.forEach(rule => {
          sheet.insert(rule, 0);
        });
        sheets.push(sheet);
      } else {
        sheet = sheets[0];
      }
    }
    return {
      getTextContent() {
        return sheet.getTextContent();
      },
      id,
      insert(cssText, groupValue) {
        sheets.forEach(s => {
          s.insert(cssText, groupValue);
        });
      }
    };
  }
},66,[67,68,69],"node_modules/react-native-web/dist/exports/StyleSheet/dom/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var canUseDOM = !!(typeof window !== 'undefined' && window.document && window.document.createElement);
  var _default = canUseDOM;
},67,[],"node_modules/react-native-web/dist/modules/canUseDom/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return createCSSStyleSheet;
    }
  });
  var _modulesCanUseDom = require(_dependencyMap[0], "../../../modules/canUseDom");
  var canUseDOM = _interopDefault(_modulesCanUseDom);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  // $FlowFixMe: HTMLStyleElement is incorrectly typed - https://github.com/facebook/flow/issues/2696
  function createCSSStyleSheet(id, rootNode, textContent) {
    if (canUseDOM.default) {
      var root = rootNode != null ? rootNode : document;
      var element = root.getElementById(id);
      if (element == null) {
        element = document.createElement('style');
        element.setAttribute('id', id);
        if (typeof textContent === 'string') {
          element.appendChild(document.createTextNode(textContent));
        }
        if (root instanceof ShadowRoot) {
          root.insertBefore(element, root.firstChild);
        } else {
          var head = root.head;
          if (head) {
            head.insertBefore(element, head.firstChild);
          }
        }
      }
      // $FlowFixMe: HTMLElement is incorrectly typed
      return element.sheet;
    } else {
      return null;
    }
  }
},68,[67],"node_modules/react-native-web/dist/exports/StyleSheet/dom/createCSSStyleSheet.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return createOrderedCSSStyleSheet;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var slice = Array.prototype.slice;

  /**
   * Order-based insertion of CSS.
   *
   * Each rule is associated with a numerically defined group.
   * Groups are ordered within the style sheet according to their number, with the
   * lowest first.
   *
   * Groups are implemented using marker rules. The selector of the first rule of
   * each group is used only to encode the group number for hydration. An
   * alternative implementation could rely on CSSMediaRule, allowing groups to be
   * treated as a sub-sheet, but the Edge implementation of CSSMediaRule is
   * broken.
   * https://developer.mozilla.org/en-US/docs/Web/API/CSSMediaRule
   * https://gist.github.com/necolas/aa0c37846ad6bd3b05b727b959e82674
   */
  function createOrderedCSSStyleSheet(sheet) {
    var groups = {};
    var selectors = {};

    /**
     * Hydrate approximate record from any existing rules in the sheet.
     */
    if (sheet != null) {
      var group;
      slice.call(sheet.cssRules).forEach((cssRule, i) => {
        var cssText = cssRule.cssText;
        // Create record of existing selectors and rules
        if (cssText.indexOf('stylesheet-group') > -1) {
          group = decodeGroupRule(cssRule);
          groups[group] = {
            start: i,
            rules: [cssText]
          };
        } else {
          var selectorText = getSelectorText(cssText);
          if (selectorText != null) {
            selectors[selectorText] = true;
            groups[group].rules.push(cssText);
          }
        }
      });
    }
    function sheetInsert(sheet, group, text) {
      var orderedGroups = getOrderedGroups(groups);
      var groupIndex = orderedGroups.indexOf(group);
      var nextGroupIndex = groupIndex + 1;
      var nextGroup = orderedGroups[nextGroupIndex];
      // Insert rule before the next group, or at the end of the stylesheet
      var position = nextGroup != null && groups[nextGroup].start != null ? groups[nextGroup].start : sheet.cssRules.length;
      var isInserted = insertRuleAt(sheet, text, position);
      if (isInserted) {
        // Set the starting index of the new group
        if (groups[group].start == null) {
          groups[group].start = position;
        }
        // Increment the starting index of all subsequent groups
        for (var i = nextGroupIndex; i < orderedGroups.length; i += 1) {
          var groupNumber = orderedGroups[i];
          var previousStart = groups[groupNumber].start || 0;
          groups[groupNumber].start = previousStart + 1;
        }
      }
      return isInserted;
    }
    var OrderedCSSStyleSheet = {
      /**
       * The textContent of the style sheet.
       */
      getTextContent() {
        return getOrderedGroups(groups).map(group => {
          var rules = groups[group].rules;
          // Sorting provides deterministic order of styles in group for
          // build-time extraction of the style sheet.
          var marker = rules.shift();
          rules.sort();
          rules.unshift(marker);
          return rules.join('\n');
        }).join('\n');
      },
      /**
       * Insert a rule into the style sheet
       */
      insert(cssText, groupValue) {
        var group = Number(groupValue);

        // Create a new group.
        if (groups[group] == null) {
          var markerRule = encodeGroupRule(group);
          // Create the internal record.
          groups[group] = {
            start: null,
            rules: [markerRule]
          };
          // Update CSSOM.
          if (sheet != null) {
            sheetInsert(sheet, group, markerRule);
          }
        }

        // selectorText is more reliable than cssText for insertion checks. The
        // browser excludes vendor-prefixed properties and rewrites certain values
        // making cssText more likely to be different from what was inserted.
        var selectorText = getSelectorText(cssText);
        if (selectorText != null && selectors[selectorText] == null) {
          // Update the internal records.
          selectors[selectorText] = true;
          groups[group].rules.push(cssText);
          // Update CSSOM.
          if (sheet != null) {
            var isInserted = sheetInsert(sheet, group, cssText);
            if (!isInserted) {
              // Revert internal record change if a rule was rejected (e.g.,
              // unrecognized pseudo-selector)
              groups[group].rules.pop();
            }
          }
        }
      }
    };
    return OrderedCSSStyleSheet;
  }

  /**
   * Helper functions
   */

  function encodeGroupRule(group) {
    return "[stylesheet-group=\"" + group + "\"]{}";
  }
  var groupPattern = /["']/g;
  function decodeGroupRule(cssRule) {
    return Number(cssRule.selectorText.split(groupPattern)[1]);
  }
  function getOrderedGroups(obj) {
    return Object.keys(obj).map(Number).sort((a, b) => a > b ? 1 : -1);
  }
  var selectorPattern = /\s*([,])\s*/g;
  function getSelectorText(cssText) {
    var selector = cssText.split('{')[0].trim();
    return selector !== '' ? selector.replace(selectorPattern, '$1') : null;
  }
  function insertRuleAt(root, cssText, position) {
    try {
      // $FlowFixMe: Flow is missing CSSOM types needed to type 'root'.
      root.insertRule(cssText, position);
      return true;
    } catch (e) {
      // JSDOM doesn't support `CSSSMediaRule#insertRule`.
      // Also ignore errors that occur from attempting to insert vendor-prefixed selectors.
      return false;
    }
  }
},69,[],"node_modules/react-native-web/dist/exports/StyleSheet/dom/createOrderedCSSStyleSheet.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _babelRuntimeHelpersObjectSpread = require(_dependencyMap[0], "@babel/runtime/helpers/objectSpread2");
  var _objectSpread = _interopDefault(_babelRuntimeHelpersObjectSpread);
  var _babelRuntimeHelpersObjectWithoutPropertiesLoose = require(_dependencyMap[1], "@babel/runtime/helpers/objectWithoutPropertiesLoose");
  var _objectWithoutPropertiesLoose = _interopDefault(_babelRuntimeHelpersObjectWithoutPropertiesLoose);
  var _compiler = require(_dependencyMap[2], "./compiler");
  var _dom = require(_dependencyMap[3], "./dom");
  var _styleqTransformLocalizeStyle = require(_dependencyMap[4], "styleq/transform-localize-style");
  var _preprocess = require(_dependencyMap[5], "./preprocess");
  var _styleq = require(_dependencyMap[6], "styleq");
  var _validate = require(_dependencyMap[7], "./validate");
  var _modulesCanUseDom = require(_dependencyMap[8], "../../modules/canUseDom");
  var canUseDOM = _interopDefault(_modulesCanUseDom);
  var _excluded = ["writingDirection"];
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var staticStyleMap = new WeakMap();
  var sheet = (0, _dom.createSheet)();
  var defaultPreprocessOptions = {
    shadow: true,
    textShadow: true
  };
  function customStyleq(styles, options) {
    if (options === void 0) {
      options = {};
    }
    var _options = options,
      writingDirection = _options.writingDirection,
      preprocessOptions = (0, _objectWithoutPropertiesLoose.default)(_options, _excluded);
    var isRTL = writingDirection === 'rtl';
    return _styleq.styleq.factory({
      transform(style) {
        var compiledStyle = staticStyleMap.get(style);
        if (compiledStyle != null) {
          return (0, _styleqTransformLocalizeStyle.localizeStyle)(compiledStyle, isRTL);
        }
        return (0, _preprocess.preprocess)(style, (0, _objectSpread.default)((0, _objectSpread.default)({}, defaultPreprocessOptions), preprocessOptions));
      }
    })(styles);
  }
  function insertRules(compiledOrderedRules) {
    compiledOrderedRules.forEach(_ref => {
      var rules = _ref[0],
        order = _ref[1];
      if (sheet != null) {
        rules.forEach(rule => {
          sheet.insert(rule, order);
        });
      }
    });
  }
  function compileAndInsertAtomic(style) {
    var _atomic = (0, _compiler.atomic)((0, _preprocess.preprocess)(style, defaultPreprocessOptions)),
      compiledStyle = _atomic[0],
      compiledOrderedRules = _atomic[1];
    insertRules(compiledOrderedRules);
    return compiledStyle;
  }
  function compileAndInsertReset(style, key) {
    var _classic = (0, _compiler.classic)(style, key),
      compiledStyle = _classic[0],
      compiledOrderedRules = _classic[1];
    insertRules(compiledOrderedRules);
    return compiledStyle;
  }

  /* ----- API ----- */

  var absoluteFillObject = {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0
  };
  var absoluteFill = create({
    x: (0, _objectSpread.default)({}, absoluteFillObject)
  }).x;

  /**
   * create
   */
  function create(styles) {
    Object.keys(styles).forEach(key => {
      var styleObj = styles[key];
      // Only compile at runtime if the style is not already compiled
      if (styleObj != null && styleObj.$$css !== true) {
        var compiledStyles;
        if (key.indexOf('$raw') > -1) {
          compiledStyles = compileAndInsertReset(styleObj, key.split('$raw')[0]);
        } else {
          if (process.env.NODE_ENV !== 'production') {
            (0, _validate.validate)(styleObj);
            styles[key] = Object.freeze(styleObj);
          }
          compiledStyles = compileAndInsertAtomic(styleObj);
        }
        staticStyleMap.set(styleObj, compiledStyles);
      }
    });
    return styles;
  }

  /**
   * compose
   */
  function compose(style1, style2) {
    if (process.env.NODE_ENV !== 'production') {
      /* eslint-disable prefer-rest-params */
      var len = arguments.length;
      if (len > 2) {
        var readableStyles = [...arguments].map(a => flatten(a));
        throw new Error("StyleSheet.compose() only accepts 2 arguments, received " + len + ": " + JSON.stringify(readableStyles));
      }
      /* eslint-enable prefer-rest-params */
      /*
      console.warn(
        'StyleSheet.compose(a, b) is deprecated; use array syntax, i.e., [a,b].'
      );
      */
    }
    return [style1, style2];
  }

  /**
   * flatten
   */
  function flatten() {
    for (var _len = arguments.length, styles = new Array(_len), _key = 0; _key < _len; _key++) {
      styles[_key] = arguments[_key];
    }
    var flatArray = styles.flat(Infinity);
    var result = {};
    for (var i = 0; i < flatArray.length; i++) {
      var style = flatArray[i];
      if (style != null && typeof style === 'object') {
        // $FlowFixMe
        Object.assign(result, style);
      }
    }
    return result;
  }

  /**
   * getSheet
   */
  function getSheet() {
    return {
      id: sheet.id,
      textContent: sheet.getTextContent()
    };
  }

  /**
   * resolve
   */

  function StyleSheet(styles, options) {
    if (options === void 0) {
      options = {};
    }
    var isRTL = options.writingDirection === 'rtl';
    var styleProps = customStyleq(styles, options);
    if (Array.isArray(styleProps) && styleProps[1] != null) {
      styleProps[1] = (0, _compiler.inline)(styleProps[1], isRTL);
    }
    return styleProps;
  }
  StyleSheet.absoluteFill = absoluteFill;
  StyleSheet.absoluteFillObject = absoluteFillObject;
  StyleSheet.create = create;
  StyleSheet.compose = compose;
  StyleSheet.flatten = flatten;
  StyleSheet.getSheet = getSheet;
  // `hairlineWidth` is not implemented using screen density as browsers may
  // round sub-pixel values down to `0`, causing the line not to be rendered.
  StyleSheet.hairlineWidth = 1;
  if (canUseDOM.default && window.__REACT_DEVTOOLS_GLOBAL_HOOK__) {
    window.__REACT_DEVTOOLS_GLOBAL_HOOK__.resolveRNStyle = StyleSheet.flatten;
  }
  var stylesheet = StyleSheet;
  var _default = stylesheet;
},70,[47,71,72,66,112,114,116,117,67],"node_modules/react-native-web/dist/exports/StyleSheet/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _objectWithoutPropertiesLoose;
    }
  });
  function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
      if (-1 !== e.indexOf(n)) continue;
      t[n] = r[n];
    }
    return t;
  }
},71,[],"node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.atomic = atomic;
  exports.classic = classic;
  exports.inline = inline;
  exports.stringifyValueWithProperty = stringifyValueWithProperty;
  var _babelRuntimeHelpersObjectSpread = require(_dependencyMap[0], "@babel/runtime/helpers/objectSpread2");
  var _objectSpread = _interopDefault(_babelRuntimeHelpersObjectSpread);
  var _babelRuntimeHelpersObjectWithoutPropertiesLoose = require(_dependencyMap[1], "@babel/runtime/helpers/objectWithoutPropertiesLoose");
  var _objectWithoutPropertiesLoose = _interopDefault(_babelRuntimeHelpersObjectWithoutPropertiesLoose);
  var _createReactDOMStyle = require(_dependencyMap[2], "./createReactDOMStyle");
  var createReactDOMStyle = _interopDefault(_createReactDOMStyle);
  var _hash = require(_dependencyMap[3], "./hash");
  var hash = _interopDefault(_hash);
  var _hyphenateStyleName = require(_dependencyMap[4], "./hyphenateStyleName");
  var hyphenateStyleName = _interopDefault(_hyphenateStyleName);
  var _normalizeValueWithProperty = require(_dependencyMap[5], "./normalizeValueWithProperty");
  var normalizeValueWithProperty = _interopDefault(_normalizeValueWithProperty);
  var _modulesPrefixStyles = require(_dependencyMap[6], "../../../modules/prefixStyles");
  var prefixStyles = _interopDefault(_modulesPrefixStyles);
  var _excluded = ["animationKeyframes"];
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var cache = new Map();
  var emptyObject = {};
  var classicGroup = 1;
  var atomicGroup = 3;
  var customGroup = {
    borderColor: 2,
    borderRadius: 2,
    borderStyle: 2,
    borderWidth: 2,
    display: 2,
    flex: 2,
    inset: 2,
    margin: 2,
    overflow: 2,
    overscrollBehavior: 2,
    padding: 2,
    insetBlock: 2.1,
    insetInline: 2.1,
    marginInline: 2.1,
    marginBlock: 2.1,
    paddingInline: 2.1,
    paddingBlock: 2.1,
    borderBlockStartColor: 2.2,
    borderBlockStartStyle: 2.2,
    borderBlockStartWidth: 2.2,
    borderBlockEndColor: 2.2,
    borderBlockEndStyle: 2.2,
    borderBlockEndWidth: 2.2,
    borderInlineStartColor: 2.2,
    borderInlineStartStyle: 2.2,
    borderInlineStartWidth: 2.2,
    borderInlineEndColor: 2.2,
    borderInlineEndStyle: 2.2,
    borderInlineEndWidth: 2.2,
    borderEndStartRadius: 2.2,
    borderEndEndRadius: 2.2,
    borderStartStartRadius: 2.2,
    borderStartEndRadius: 2.2,
    insetBlockEnd: 2.2,
    insetBlockStart: 2.2,
    insetInlineEnd: 2.2,
    insetInlineStart: 2.2,
    marginBlockStart: 2.2,
    marginBlockEnd: 2.2,
    marginInlineStart: 2.2,
    marginInlineEnd: 2.2,
    paddingBlockStart: 2.2,
    paddingBlockEnd: 2.2,
    paddingInlineStart: 2.2,
    paddingInlineEnd: 2.2
  };
  var borderTopLeftRadius = 'borderTopLeftRadius';
  var borderTopRightRadius = 'borderTopRightRadius';
  var borderBottomLeftRadius = 'borderBottomLeftRadius';
  var borderBottomRightRadius = 'borderBottomRightRadius';
  var borderLeftColor = 'borderLeftColor';
  var borderLeftStyle = 'borderLeftStyle';
  var borderLeftWidth = 'borderLeftWidth';
  var borderRightColor = 'borderRightColor';
  var borderRightStyle = 'borderRightStyle';
  var borderRightWidth = 'borderRightWidth';
  var right = 'right';
  var marginLeft = 'marginLeft';
  var marginRight = 'marginRight';
  var paddingLeft = 'paddingLeft';
  var paddingRight = 'paddingRight';
  var left = 'left';

  // Map of LTR property names to their BiDi equivalent.
  var PROPERTIES_FLIP = {
    [borderTopLeftRadius]: borderTopRightRadius,
    [borderTopRightRadius]: borderTopLeftRadius,
    [borderBottomLeftRadius]: borderBottomRightRadius,
    [borderBottomRightRadius]: borderBottomLeftRadius,
    [borderLeftColor]: borderRightColor,
    [borderLeftStyle]: borderRightStyle,
    [borderLeftWidth]: borderRightWidth,
    [borderRightColor]: borderLeftColor,
    [borderRightStyle]: borderLeftStyle,
    [borderRightWidth]: borderLeftWidth,
    [left]: right,
    [marginLeft]: marginRight,
    [marginRight]: marginLeft,
    [paddingLeft]: paddingRight,
    [paddingRight]: paddingLeft,
    [right]: left
  };

  // Map of I18N property names to their LTR equivalent.
  var PROPERTIES_I18N = {
    borderStartStartRadius: borderTopLeftRadius,
    borderStartEndRadius: borderTopRightRadius,
    borderEndStartRadius: borderBottomLeftRadius,
    borderEndEndRadius: borderBottomRightRadius,
    borderInlineStartColor: borderLeftColor,
    borderInlineStartStyle: borderLeftStyle,
    borderInlineStartWidth: borderLeftWidth,
    borderInlineEndColor: borderRightColor,
    borderInlineEndStyle: borderRightStyle,
    borderInlineEndWidth: borderRightWidth,
    insetInlineEnd: right,
    insetInlineStart: left,
    marginInlineStart: marginLeft,
    marginInlineEnd: marginRight,
    paddingInlineStart: paddingLeft,
    paddingInlineEnd: paddingRight
  };
  var PROPERTIES_VALUE = ['clear', 'float', 'textAlign'];
  function atomic(style) {
    var compiledStyle = {
      $$css: true
    };
    var compiledRules = [];
    function atomicCompile(srcProp, prop, value) {
      var valueString = stringifyValueWithProperty(value, prop);
      var cacheKey = prop + valueString;
      var cachedResult = cache.get(cacheKey);
      var identifier;
      if (cachedResult != null) {
        identifier = cachedResult[0];
        compiledRules.push(cachedResult[1]);
      } else {
        var v = srcProp !== prop ? cacheKey : valueString;
        identifier = createIdentifier('r', srcProp, v);
        var order = customGroup[srcProp] || atomicGroup;
        var rules = createAtomicRules(identifier, prop, value);
        var orderedRules = [rules, order];
        compiledRules.push(orderedRules);
        cache.set(cacheKey, [identifier, orderedRules]);
      }
      return identifier;
    }
    Object.keys(style).sort().forEach(srcProp => {
      var value = style[srcProp];
      if (value != null) {
        var localizeableValue;
        // BiDi flip values
        if (PROPERTIES_VALUE.indexOf(srcProp) > -1) {
          var _left = atomicCompile(srcProp, srcProp, 'left');
          var _right = atomicCompile(srcProp, srcProp, 'right');
          if (value === 'start') {
            localizeableValue = [_left, _right];
          } else if (value === 'end') {
            localizeableValue = [_right, _left];
          }
        }
        // BiDi flip properties
        var propPolyfill = PROPERTIES_I18N[srcProp];
        if (propPolyfill != null) {
          var ltr = atomicCompile(srcProp, propPolyfill, value);
          var rtl = atomicCompile(srcProp, PROPERTIES_FLIP[propPolyfill], value);
          localizeableValue = [ltr, rtl];
        }
        // BiDi flip transitionProperty value
        if (srcProp === 'transitionProperty') {
          var values = Array.isArray(value) ? value : [value];
          var polyfillIndices = [];
          for (var i = 0; i < values.length; i++) {
            var val = values[i];
            if (typeof val === 'string' && PROPERTIES_I18N[val] != null) {
              polyfillIndices.push(i);
            }
          }
          if (polyfillIndices.length > 0) {
            var ltrPolyfillValues = [...values];
            var rtlPolyfillValues = [...values];
            polyfillIndices.forEach(i => {
              var ltrVal = ltrPolyfillValues[i];
              if (typeof ltrVal === 'string') {
                var ltrPolyfill = PROPERTIES_I18N[ltrVal];
                var rtlPolyfill = PROPERTIES_FLIP[ltrPolyfill];
                ltrPolyfillValues[i] = ltrPolyfill;
                rtlPolyfillValues[i] = rtlPolyfill;
                var _ltr = atomicCompile(srcProp, srcProp, ltrPolyfillValues);
                var _rtl = atomicCompile(srcProp, srcProp, rtlPolyfillValues);
                localizeableValue = [_ltr, _rtl];
              }
            });
          }
        }
        if (localizeableValue == null) {
          localizeableValue = atomicCompile(srcProp, srcProp, value);
        } else {
          compiledStyle['$$css$localize'] = true;
        }
        compiledStyle[srcProp] = localizeableValue;
      }
    });
    return [compiledStyle, compiledRules];
  }

  /**
   * Compile simple style object to classic CSS rules.
   * No support for 'placeholderTextColor', 'scrollbarWidth', or 'pointerEvents'.
   */
  function classic(style, name) {
    var compiledStyle = {
      $$css: true
    };
    var compiledRules = [];
    var animationKeyframes = style.animationKeyframes,
      rest = (0, _objectWithoutPropertiesLoose.default)(style, _excluded);
    var identifier = createIdentifier('css', name, JSON.stringify(style));
    var selector = "." + identifier;
    var animationName;
    if (animationKeyframes != null) {
      var _processKeyframesValu = processKeyframesValue(animationKeyframes),
        animationNames = _processKeyframesValu[0],
        keyframesRules = _processKeyframesValu[1];
      animationName = animationNames.join(',');
      compiledRules.push(...keyframesRules);
    }
    var block = createDeclarationBlock((0, _objectSpread.default)((0, _objectSpread.default)({}, rest), {}, {
      animationName
    }));
    compiledRules.push("" + selector + block);
    compiledStyle[identifier] = identifier;
    return [compiledStyle, [[compiledRules, classicGroup]]];
  }

  /**
   * Compile simple style object to inline DOM styles.
   * No support for 'animationKeyframes', 'placeholderTextColor', 'scrollbarWidth', or 'pointerEvents'.
   */
  function inline(originalStyle, isRTL) {
    var style = originalStyle || emptyObject;
    var frozenProps = {};
    var nextStyle = {};
    var _loop = function _loop() {
      var originalValue = style[originalProp];
      var prop = originalProp;
      var value = originalValue;
      if (!Object.prototype.hasOwnProperty.call(style, originalProp) || originalValue == null) {
        return "continue";
      }

      // BiDi flip values
      if (PROPERTIES_VALUE.indexOf(originalProp) > -1) {
        if (originalValue === 'start') {
          value = isRTL ? 'right' : 'left';
        } else if (originalValue === 'end') {
          value = isRTL ? 'left' : 'right';
        }
      }
      // BiDi flip properties
      var propPolyfill = PROPERTIES_I18N[originalProp];
      if (propPolyfill != null) {
        prop = isRTL ? PROPERTIES_FLIP[propPolyfill] : propPolyfill;
      }
      // BiDi flip transitionProperty value
      if (originalProp === 'transitionProperty') {
        // $FlowFixMe
        var originalValues = Array.isArray(originalValue) ? originalValue : [originalValue];
        originalValues.forEach((val, i) => {
          if (typeof val === 'string') {
            var valuePolyfill = PROPERTIES_I18N[val];
            if (valuePolyfill != null) {
              originalValues[i] = isRTL ? PROPERTIES_FLIP[valuePolyfill] : valuePolyfill;
              value = originalValues.join(' ');
            }
          }
        });
      }

      // Create finalized style
      if (!frozenProps[prop]) {
        nextStyle[prop] = value;
      }
      if (prop === originalProp) {
        frozenProps[prop] = true;
      }

      //    if (PROPERTIES_I18N.hasOwnProperty(originalProp)) {
      //    frozenProps[prop] = true;
      //}
    };
    for (var originalProp in style) {
      var _ret = _loop();
      if (_ret === "continue") continue;
    }
    return (0, createReactDOMStyle.default)(nextStyle, true);
  }

  /**
   * Create a value string that normalizes different input values with a common
   * output.
   */
  function stringifyValueWithProperty(value, property) {
    // e.g., 0 => '0px', 'black' => 'rgba(0,0,0,1)'
    var normalizedValue = (0, normalizeValueWithProperty.default)(value, property);
    return typeof normalizedValue !== 'string' ? JSON.stringify(normalizedValue || '') : normalizedValue;
  }

  /**
   * Create the Atomic CSS rules needed for a given StyleSheet rule.
   * Translates StyleSheet declarations to CSS.
   */
  function createAtomicRules(identifier, property, value) {
    var rules = [];
    var selector = "." + identifier;

    // Handle non-standard properties and object values that require multiple
    // CSS rules to be created.
    switch (property) {
      case 'animationKeyframes':
        {
          var _processKeyframesValu2 = processKeyframesValue(value),
            animationNames = _processKeyframesValu2[0],
            keyframesRules = _processKeyframesValu2[1];
          var block = createDeclarationBlock({
            animationName: animationNames.join(',')
          });
          rules.push("" + selector + block, ...keyframesRules);
          break;
        }

      // Equivalent to using '::placeholder'
      case 'placeholderTextColor':
        {
          var _block = createDeclarationBlock({
            color: value,
            opacity: 1
          });
          rules.push(selector + "::-webkit-input-placeholder" + _block, selector + "::-moz-placeholder" + _block, selector + ":-ms-input-placeholder" + _block, selector + "::placeholder" + _block);
          break;
        }

      // Polyfill for additional 'pointer-events' values
      // See d13f78622b233a0afc0c7a200c0a0792c8ca9e58
      // See https://reactnative.dev/docs/view#pointerevents
      case 'pointerEvents':
        {
          var finalValue = value;
          if (value === 'auto') {
            finalValue = 'auto!important';
          } else if (value === 'none') {
            finalValue = 'none!important';
            var _block2 = createDeclarationBlock({
              pointerEvents: 'none'
            });
            rules.push(selector + ">* " + _block2);
          } else if (value === 'box-none') {
            finalValue = 'none!important';
            var _block3 = createDeclarationBlock({
              pointerEvents: 'auto'
            });
            rules.push(selector + ">* " + _block3);
          } else if (value === 'box-only') {
            finalValue = 'auto!important';
            var _block4 = createDeclarationBlock({
              pointerEvents: 'none'
            });
            rules.push(selector + ">* " + _block4);
          }
          var _block5 = createDeclarationBlock({
            pointerEvents: finalValue
          });
          rules.push("" + selector + _block5);
          break;
        }

      // Polyfill for draft spec
      // https://drafts.csswg.org/css-scrollbars-1/
      case 'scrollbarWidth':
        {
          if (value === 'none') {
            rules.push(selector + "::-webkit-scrollbar{display:none}");
          }
          var _block6 = createDeclarationBlock({
            scrollbarWidth: value
          });
          rules.push("" + selector + _block6);
          break;
        }
      default:
        {
          var _block7 = createDeclarationBlock({
            [property]: value
          });
          rules.push("" + selector + _block7);
          break;
        }
    }
    return rules;
  }

  /**
   * Creates a CSS declaration block from a StyleSheet object.
   */
  function createDeclarationBlock(style) {
    var domStyle = (0, prefixStyles.default)((0, createReactDOMStyle.default)(style));
    var declarationsString = Object.keys(domStyle).map(property => {
      var value = domStyle[property];
      var prop = (0, hyphenateStyleName.default)(property);
      // The prefixer may return an array of values:
      // { display: [ '-webkit-flex', 'flex' ] }
      // to represent "fallback" declarations
      // { display: -webkit-flex; display: flex; }
      if (Array.isArray(value)) {
        return value.map(v => prop + ":" + v).join(';');
      } else {
        return prop + ":" + value;
      }
    })
    // Once properties are hyphenated, this will put the vendor
    // prefixed and short-form properties first in the list.
    .sort().join(';');
    return "{" + declarationsString + ";}";
  }

  /**
   * An identifier is associated with a unique set of styles.
   */
  function createIdentifier(prefix, name, key) {
    var hashedString = (0, hash.default)(name + key);
    return process.env.NODE_ENV !== 'production' ? prefix + "-" + name + "-" + hashedString : prefix + "-" + hashedString;
  }

  /**
   * Create individual CSS keyframes rules.
   */
  function createKeyframes(keyframes) {
    var prefixes = ['-webkit-', ''];
    var identifier = createIdentifier('r', 'animation', JSON.stringify(keyframes));
    var steps = '{' + Object.keys(keyframes).map(stepName => {
      var rule = keyframes[stepName];
      var block = createDeclarationBlock(rule);
      return "" + stepName + block;
    }).join('') + '}';
    var rules = prefixes.map(prefix => {
      return "@" + prefix + "keyframes " + identifier + steps;
    });
    return [identifier, rules];
  }

  /**
   * Create CSS keyframes rules and names from a StyleSheet keyframes object.
   */
  function processKeyframesValue(keyframesValue) {
    if (typeof keyframesValue === 'number') {
      throw new Error("Invalid CSS keyframes type: " + typeof keyframesValue);
    }
    var animationNames = [];
    var rules = [];
    var value = Array.isArray(keyframesValue) ? keyframesValue : [keyframesValue];
    value.forEach(keyframes => {
      if (typeof keyframes === 'string') {
        // Support external animation libraries (identifiers only)
        animationNames.push(keyframes);
      } else {
        // Create rules for each of the keyframes
        var _createKeyframes = createKeyframes(keyframes),
          identifier = _createKeyframes[0],
          keyframesRules = _createKeyframes[1];
        animationNames.push(identifier);
        rules.push(...keyframesRules);
      }
    });
    return [animationNames, rules];
  }
},72,[47,71,73,80,81,74,82],"node_modules/react-native-web/dist/exports/StyleSheet/compiler/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _normalizeValueWithProperty = require(_dependencyMap[0], "./normalizeValueWithProperty");
  var normalizeValueWithProperty = _interopDefault(_normalizeValueWithProperty);
  var _modulesCanUseDom = require(_dependencyMap[1], "../../../modules/canUseDom");
  var canUseDOM = _interopDefault(_modulesCanUseDom);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  /**
   * The browser implements the CSS cascade, where the order of properties is a
   * factor in determining which styles to paint. React Native is different. It
   * gives giving precedence to the more specific style property. For example,
   * the value of `paddingTop` takes precedence over that of `padding`.
   *
   * This module creates mutally exclusive style declarations by expanding all of
   * React Native's supported shortform properties (e.g. `padding`) to their
   * longfrom equivalents.
   */

  var emptyObject = {};
  var supportsCSS3TextDecoration = !canUseDOM.default || window.CSS != null && window.CSS.supports != null && (window.CSS.supports('text-decoration-line', 'none') || window.CSS.supports('-webkit-text-decoration-line', 'none'));
  var MONOSPACE_FONT_STACK = 'monospace,monospace';
  var SYSTEM_FONT_STACK = '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';
  var STYLE_SHORT_FORM_EXPANSIONS = {
    borderColor: ['borderTopColor', 'borderRightColor', 'borderBottomColor', 'borderLeftColor'],
    borderBlockColor: ['borderTopColor', 'borderBottomColor'],
    borderInlineColor: ['borderRightColor', 'borderLeftColor'],
    borderRadius: ['borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomRightRadius', 'borderBottomLeftRadius'],
    borderStyle: ['borderTopStyle', 'borderRightStyle', 'borderBottomStyle', 'borderLeftStyle'],
    borderBlockStyle: ['borderTopStyle', 'borderBottomStyle'],
    borderInlineStyle: ['borderRightStyle', 'borderLeftStyle'],
    borderWidth: ['borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth'],
    borderBlockWidth: ['borderTopWidth', 'borderBottomWidth'],
    borderInlineWidth: ['borderRightWidth', 'borderLeftWidth'],
    insetBlock: ['top', 'bottom'],
    insetInline: ['left', 'right'],
    marginBlock: ['marginTop', 'marginBottom'],
    marginInline: ['marginRight', 'marginLeft'],
    paddingBlock: ['paddingTop', 'paddingBottom'],
    paddingInline: ['paddingRight', 'paddingLeft'],
    overflow: ['overflowX', 'overflowY'],
    overscrollBehavior: ['overscrollBehaviorX', 'overscrollBehaviorY'],
    borderBlockStartColor: ['borderTopColor'],
    borderBlockStartStyle: ['borderTopStyle'],
    borderBlockStartWidth: ['borderTopWidth'],
    borderBlockEndColor: ['borderBottomColor'],
    borderBlockEndStyle: ['borderBottomStyle'],
    borderBlockEndWidth: ['borderBottomWidth'],
    //borderInlineStartColor: ['borderLeftColor'],
    //borderInlineStartStyle: ['borderLeftStyle'],
    //borderInlineStartWidth: ['borderLeftWidth'],
    //borderInlineEndColor: ['borderRightColor'],
    //borderInlineEndStyle: ['borderRightStyle'],
    //borderInlineEndWidth: ['borderRightWidth'],
    borderEndStartRadius: ['borderBottomLeftRadius'],
    borderEndEndRadius: ['borderBottomRightRadius'],
    borderStartStartRadius: ['borderTopLeftRadius'],
    borderStartEndRadius: ['borderTopRightRadius'],
    insetBlockEnd: ['bottom'],
    insetBlockStart: ['top'],
    //insetInlineEnd: ['right'],
    //insetInlineStart: ['left'],
    marginBlockStart: ['marginTop'],
    marginBlockEnd: ['marginBottom'],
    //marginInlineStart: ['marginLeft'],
    //marginInlineEnd: ['marginRight'],
    paddingBlockStart: ['paddingTop'],
    paddingBlockEnd: ['paddingBottom']
    //paddingInlineStart: ['marginLeft'],
    //paddingInlineEnd: ['marginRight'],
  };

  /**
   * Reducer
   */

  var createReactDOMStyle = (style, isInline) => {
    if (!style) {
      return emptyObject;
    }
    var resolvedStyle = {};
    var _loop = function _loop() {
      var value = style[prop];
      if (
      // Ignore everything with a null value
      value == null) {
        return "continue";
      }
      if (prop === 'backgroundClip') {
        // TODO: remove once this issue is fixed
        // https://github.com/rofrischmann/inline-style-prefixer/issues/159
        if (value === 'text') {
          resolvedStyle.backgroundClip = value;
          resolvedStyle.WebkitBackgroundClip = value;
        }
      } else if (prop === 'flex') {
        if (value === -1) {
          resolvedStyle.flexGrow = 0;
          resolvedStyle.flexShrink = 1;
          resolvedStyle.flexBasis = 'auto';
        } else {
          resolvedStyle.flex = value;
        }
      } else if (prop === 'font') {
        resolvedStyle[prop] = value.replace('System', SYSTEM_FONT_STACK);
      } else if (prop === 'fontFamily') {
        if (value.indexOf('System') > -1) {
          var stack = value.split(/,\s*/);
          stack[stack.indexOf('System')] = SYSTEM_FONT_STACK;
          resolvedStyle[prop] = stack.join(',');
        } else if (value === 'monospace') {
          resolvedStyle[prop] = MONOSPACE_FONT_STACK;
        } else {
          resolvedStyle[prop] = value;
        }
      } else if (prop === 'textDecorationLine') {
        // use 'text-decoration' for browsers that only support CSS2
        // text-decoration (e.g., IE, Edge)
        if (!supportsCSS3TextDecoration) {
          resolvedStyle.textDecoration = value;
        } else {
          resolvedStyle.textDecorationLine = value;
        }
      } else if (prop === 'writingDirection') {
        resolvedStyle.direction = value;
      } else {
        var _value = (0, normalizeValueWithProperty.default)(style[prop], prop);
        var longFormProperties = STYLE_SHORT_FORM_EXPANSIONS[prop];
        if (isInline && prop === 'inset') {
          if (style.insetInline == null) {
            resolvedStyle.left = _value;
            resolvedStyle.right = _value;
          }
          if (style.insetBlock == null) {
            resolvedStyle.top = _value;
            resolvedStyle.bottom = _value;
          }
        } else if (isInline && prop === 'margin') {
          if (style.marginInline == null) {
            resolvedStyle.marginLeft = _value;
            resolvedStyle.marginRight = _value;
          }
          if (style.marginBlock == null) {
            resolvedStyle.marginTop = _value;
            resolvedStyle.marginBottom = _value;
          }
        } else if (isInline && prop === 'padding') {
          if (style.paddingInline == null) {
            resolvedStyle.paddingLeft = _value;
            resolvedStyle.paddingRight = _value;
          }
          if (style.paddingBlock == null) {
            resolvedStyle.paddingTop = _value;
            resolvedStyle.paddingBottom = _value;
          }
        } else if (longFormProperties) {
          longFormProperties.forEach((longForm, i) => {
            // The value of any longform property in the original styles takes
            // precedence over the shortform's value.
            if (style[longForm] == null) {
              resolvedStyle[longForm] = _value;
            }
          });
        } else {
          resolvedStyle[prop] = _value;
        }
      }
    };
    for (var prop in style) {
      var _ret = _loop();
      if (_ret === "continue") continue;
    }
    return resolvedStyle;
  };
  var _default = createReactDOMStyle;
},73,[74,67],"node_modules/react-native-web/dist/exports/StyleSheet/compiler/createReactDOMStyle.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return normalizeValueWithProperty;
    }
  });
  var _unitlessNumbers = require(_dependencyMap[0], "./unitlessNumbers");
  var unitlessNumbers = _interopDefault(_unitlessNumbers);
  var _normalizeColor = require(_dependencyMap[1], "./normalizeColor");
  var normalizeColor = _interopDefault(_normalizeColor);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var colorProps = {
    backgroundColor: true,
    borderColor: true,
    borderTopColor: true,
    borderRightColor: true,
    borderBottomColor: true,
    borderLeftColor: true,
    color: true,
    shadowColor: true,
    textDecorationColor: true,
    textShadowColor: true
  };
  function normalizeValueWithProperty(value, property) {
    var returnValue = value;
    if ((property == null || !unitlessNumbers.default[property]) && typeof value === 'number') {
      returnValue = value + "px";
    } else if (property != null && colorProps[property]) {
      returnValue = (0, normalizeColor.default)(value);
    }
    return returnValue;
  }
},74,[75,76],"node_modules/react-native-web/dist/exports/StyleSheet/compiler/normalizeValueWithProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var unitlessNumbers = {
    animationIterationCount: true,
    aspectRatio: true,
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    boxFlex: true,
    boxFlexGroup: true,
    boxOrdinalGroup: true,
    columnCount: true,
    flex: true,
    flexGrow: true,
    flexOrder: true,
    flexPositive: true,
    flexShrink: true,
    flexNegative: true,
    fontWeight: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowGap: true,
    gridRowStart: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnGap: true,
    gridColumnStart: true,
    lineClamp: true,
    opacity: true,
    order: true,
    orphans: true,
    tabSize: true,
    widows: true,
    zIndex: true,
    zoom: true,
    // SVG-related
    fillOpacity: true,
    floodOpacity: true,
    stopOpacity: true,
    strokeDasharray: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true,
    // transform types
    scale: true,
    scaleX: true,
    scaleY: true,
    scaleZ: true,
    // RN properties
    shadowOpacity: true
  };

  /**
   * Support style names that may come passed in prefixed by adding permutations
   * of vendor prefixes.
   */
  var prefixes = ['ms', 'Moz', 'O', 'Webkit'];
  var prefixKey = (prefix, key) => {
    return prefix + key.charAt(0).toUpperCase() + key.substring(1);
  };
  Object.keys(unitlessNumbers).forEach(prop => {
    prefixes.forEach(prefix => {
      unitlessNumbers[prefixKey(prefix, prop)] = unitlessNumbers[prop];
    });
  });
  var _default = unitlessNumbers;
},75,[],"node_modules/react-native-web/dist/exports/StyleSheet/compiler/unitlessNumbers.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _modulesIsWebColor = require(_dependencyMap[0], "../../../modules/isWebColor");
  var isWebColor = _interopDefault(_modulesIsWebColor);
  var _exportsProcessColor = require(_dependencyMap[1], "../../../exports/processColor");
  var processColor = _interopDefault(_exportsProcessColor);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var normalizeColor = function normalizeColor(color, opacity) {
    if (opacity === void 0) {
      opacity = 1;
    }
    if (color == null) return;
    if (typeof color === 'string' && (0, isWebColor.default)(color)) {
      return color;
    }
    var colorInt = (0, processColor.default)(color);
    if (colorInt != null) {
      var r = colorInt >> 16 & 255;
      var g = colorInt >> 8 & 255;
      var b = colorInt & 255;
      var a = (colorInt >> 24 & 255) / 255;
      var alpha = (a * opacity).toFixed(2);
      return "rgba(" + r + "," + g + "," + b + "," + alpha + ")";
    }
  };
  var _default = normalizeColor;
},76,[77,78],"node_modules/react-native-web/dist/exports/StyleSheet/compiler/normalizeColor.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var isWebColor = color => color === 'currentcolor' || color === 'currentColor' || color === 'inherit' || color.indexOf('var(') === 0;
  var _default = isWebColor;
},77,[],"node_modules/react-native-web/dist/modules/isWebColor/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactNativeNormalizeColors = require(_dependencyMap[0], "@react-native/normalize-colors");
  var normalizeColor = _interopDefault(_reactNativeNormalizeColors);
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var processColor = color => {
    if (color === undefined || color === null) {
      return color;
    }

    // convert number and hex
    var int32Color = (0, normalizeColor.default)(color);
    if (int32Color === undefined || int32Color === null) {
      return undefined;
    }
    int32Color = (int32Color << 24 | int32Color >>> 8) >>> 0;
    return int32Color;
  };
  var _default = processColor;
},78,[79],"node_modules/react-native-web/dist/exports/processColor/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * @format
   * 
   */

  /* eslint no-bitwise: 0 */

  'use strict';

  function normalizeColor(color) {
    if (typeof color === 'number') {
      if (color >>> 0 === color && color >= 0 && color <= 0xffffffff) {
        return color;
      }
      return null;
    }
    if (typeof color !== 'string') {
      return null;
    }
    const matchers = getMatchers();
    let match;

    // Ordered based on occurrences on Facebook codebase
    if (match = matchers.hex6.exec(color)) {
      return parseInt(match[1] + 'ff', 16) >>> 0;
    }
    const colorFromKeyword = normalizeKeyword(color);
    if (colorFromKeyword != null) {
      return colorFromKeyword;
    }
    if (match = matchers.rgb.exec(color)) {
      return (parse255(match[1]) << 24 |
      // r
      parse255(match[2]) << 16 |
      // g
      parse255(match[3]) << 8 |
      // b
      0x000000ff) >>>
      // a
      0;
    }
    if (match = matchers.rgba.exec(color)) {
      // rgba(R G B / A) notation
      if (match[6] !== undefined) {
        return (parse255(match[6]) << 24 |
        // r
        parse255(match[7]) << 16 |
        // g
        parse255(match[8]) << 8 |
        // b
        parse1(match[9])) >>>
        // a
        0;
      }

      // rgba(R, G, B, A) notation
      return (parse255(match[2]) << 24 |
      // r
      parse255(match[3]) << 16 |
      // g
      parse255(match[4]) << 8 |
      // b
      parse1(match[5])) >>>
      // a
      0;
    }
    if (match = matchers.hex3.exec(color)) {
      return parseInt(match[1] + match[1] +
      // r
      match[2] + match[2] +
      // g
      match[3] + match[3] +
      // b
      'ff',
      // a
      16) >>> 0;
    }

    // https://drafts.csswg.org/css-color-4/#hex-notation
    if (match = matchers.hex8.exec(color)) {
      return parseInt(match[1], 16) >>> 0;
    }
    if (match = matchers.hex4.exec(color)) {
      return parseInt(match[1] + match[1] +
      // r
      match[2] + match[2] +
      // g
      match[3] + match[3] +
      // b
      match[4] + match[4],
      // a
      16) >>> 0;
    }
    if (match = matchers.hsl.exec(color)) {
      return (hslToRgb(parse360(match[1]),
      // h
      parsePercentage(match[2]),
      // s
      parsePercentage(match[3]) // l
      ) | 0x000000ff) >>>
      // a
      0;
    }
    if (match = matchers.hsla.exec(color)) {
      // hsla(H S L / A) notation
      if (match[6] !== undefined) {
        return (hslToRgb(parse360(match[6]),
        // h
        parsePercentage(match[7]),
        // s
        parsePercentage(match[8]) // l
        ) | parse1(match[9])) >>>
        // a
        0;
      }

      // hsla(H, S, L, A) notation
      return (hslToRgb(parse360(match[2]),
      // h
      parsePercentage(match[3]),
      // s
      parsePercentage(match[4]) // l
      ) | parse1(match[5])) >>>
      // a
      0;
    }
    if (match = matchers.hwb.exec(color)) {
      return (hwbToRgb(parse360(match[1]),
      // h
      parsePercentage(match[2]),
      // w
      parsePercentage(match[3]) // b
      ) | 0x000000ff) >>>
      // a
      0;
    }
    return null;
  }
  function hue2rgb(p, q, t) {
    if (t < 0) {
      t += 1;
    }
    if (t > 1) {
      t -= 1;
    }
    if (t < 1 / 6) {
      return p + (q - p) * 6 * t;
    }
    if (t < 1 / 2) {
      return q;
    }
    if (t < 2 / 3) {
      return p + (q - p) * (2 / 3 - t) * 6;
    }
    return p;
  }
  function hslToRgb(h, s, l) {
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    const r = hue2rgb(p, q, h + 1 / 3);
    const g = hue2rgb(p, q, h);
    const b = hue2rgb(p, q, h - 1 / 3);
    return Math.round(r * 255) << 24 | Math.round(g * 255) << 16 | Math.round(b * 255) << 8;
  }
  function hwbToRgb(h, w, b) {
    if (w + b >= 1) {
      const gray = Math.round(w * 255 / (w + b));
      return gray << 24 | gray << 16 | gray << 8;
    }
    const red = hue2rgb(0, 1, h + 1 / 3) * (1 - w - b) + w;
    const green = hue2rgb(0, 1, h) * (1 - w - b) + w;
    const blue = hue2rgb(0, 1, h - 1 / 3) * (1 - w - b) + w;
    return Math.round(red * 255) << 24 | Math.round(green * 255) << 16 | Math.round(blue * 255) << 8;
  }
  const NUMBER = '[-+]?\\d*\\.?\\d+';
  const PERCENTAGE = NUMBER + '%';
  function call(...args) {
    return '\\(\\s*(' + args.join(')\\s*,?\\s*(') + ')\\s*\\)';
  }
  function callWithSlashSeparator(...args) {
    return '\\(\\s*(' + args.slice(0, args.length - 1).join(')\\s*,?\\s*(') + ')\\s*/\\s*(' + args[args.length - 1] + ')\\s*\\)';
  }
  function commaSeparatedCall(...args) {
    return '\\(\\s*(' + args.join(')\\s*,\\s*(') + ')\\s*\\)';
  }
  let cachedMatchers;
  function getMatchers() {
    if (cachedMatchers === undefined) {
      cachedMatchers = {
        rgb: new RegExp('rgb' + call(NUMBER, NUMBER, NUMBER)),
        rgba: new RegExp('rgba(' + commaSeparatedCall(NUMBER, NUMBER, NUMBER, NUMBER) + '|' + callWithSlashSeparator(NUMBER, NUMBER, NUMBER, NUMBER) + ')'),
        hsl: new RegExp('hsl' + call(NUMBER, PERCENTAGE, PERCENTAGE)),
        hsla: new RegExp('hsla(' + commaSeparatedCall(NUMBER, PERCENTAGE, PERCENTAGE, NUMBER) + '|' + callWithSlashSeparator(NUMBER, PERCENTAGE, PERCENTAGE, NUMBER) + ')'),
        hwb: new RegExp('hwb' + call(NUMBER, PERCENTAGE, PERCENTAGE)),
        hex3: /^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
        hex4: /^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
        hex6: /^#([0-9a-fA-F]{6})$/,
        hex8: /^#([0-9a-fA-F]{8})$/
      };
    }
    return cachedMatchers;
  }
  function parse255(str) {
    const int = parseInt(str, 10);
    if (int < 0) {
      return 0;
    }
    if (int > 255) {
      return 255;
    }
    return int;
  }
  function parse360(str) {
    const int = parseFloat(str);
    return (int % 360 + 360) % 360 / 360;
  }
  function parse1(str) {
    const num = parseFloat(str);
    if (num < 0) {
      return 0;
    }
    if (num > 1) {
      return 255;
    }
    return Math.round(num * 255);
  }
  function parsePercentage(str) {
    // parseFloat conveniently ignores the final %
    const int = parseFloat(str);
    if (int < 0) {
      return 0;
    }
    if (int > 100) {
      return 1;
    }
    return int / 100;
  }
  function normalizeKeyword(name) {
    // prettier-ignore
    switch (name) {
      case 'transparent':
        return 0x00000000;
      // http://www.w3.org/TR/css3-color/#svg-color
      case 'aliceblue':
        return 0xf0f8ffff;
      case 'antiquewhite':
        return 0xfaebd7ff;
      case 'aqua':
        return 0x00ffffff;
      case 'aquamarine':
        return 0x7fffd4ff;
      case 'azure':
        return 0xf0ffffff;
      case 'beige':
        return 0xf5f5dcff;
      case 'bisque':
        return 0xffe4c4ff;
      case 'black':
        return 0x000000ff;
      case 'blanchedalmond':
        return 0xffebcdff;
      case 'blue':
        return 0x0000ffff;
      case 'blueviolet':
        return 0x8a2be2ff;
      case 'brown':
        return 0xa52a2aff;
      case 'burlywood':
        return 0xdeb887ff;
      case 'burntsienna':
        return 0xea7e5dff;
      case 'cadetblue':
        return 0x5f9ea0ff;
      case 'chartreuse':
        return 0x7fff00ff;
      case 'chocolate':
        return 0xd2691eff;
      case 'coral':
        return 0xff7f50ff;
      case 'cornflowerblue':
        return 0x6495edff;
      case 'cornsilk':
        return 0xfff8dcff;
      case 'crimson':
        return 0xdc143cff;
      case 'cyan':
        return 0x00ffffff;
      case 'darkblue':
        return 0x00008bff;
      case 'darkcyan':
        return 0x008b8bff;
      case 'darkgoldenrod':
        return 0xb8860bff;
      case 'darkgray':
        return 0xa9a9a9ff;
      case 'darkgreen':
        return 0x006400ff;
      case 'darkgrey':
        return 0xa9a9a9ff;
      case 'darkkhaki':
        return 0xbdb76bff;
      case 'darkmagenta':
        return 0x8b008bff;
      case 'darkolivegreen':
        return 0x556b2fff;
      case 'darkorange':
        return 0xff8c00ff;
      case 'darkorchid':
        return 0x9932ccff;
      case 'darkred':
        return 0x8b0000ff;
      case 'darksalmon':
        return 0xe9967aff;
      case 'darkseagreen':
        return 0x8fbc8fff;
      case 'darkslateblue':
        return 0x483d8bff;
      case 'darkslategray':
        return 0x2f4f4fff;
      case 'darkslategrey':
        return 0x2f4f4fff;
      case 'darkturquoise':
        return 0x00ced1ff;
      case 'darkviolet':
        return 0x9400d3ff;
      case 'deeppink':
        return 0xff1493ff;
      case 'deepskyblue':
        return 0x00bfffff;
      case 'dimgray':
        return 0x696969ff;
      case 'dimgrey':
        return 0x696969ff;
      case 'dodgerblue':
        return 0x1e90ffff;
      case 'firebrick':
        return 0xb22222ff;
      case 'floralwhite':
        return 0xfffaf0ff;
      case 'forestgreen':
        return 0x228b22ff;
      case 'fuchsia':
        return 0xff00ffff;
      case 'gainsboro':
        return 0xdcdcdcff;
      case 'ghostwhite':
        return 0xf8f8ffff;
      case 'gold':
        return 0xffd700ff;
      case 'goldenrod':
        return 0xdaa520ff;
      case 'gray':
        return 0x808080ff;
      case 'green':
        return 0x008000ff;
      case 'greenyellow':
        return 0xadff2fff;
      case 'grey':
        return 0x808080ff;
      case 'honeydew':
        return 0xf0fff0ff;
      case 'hotpink':
        return 0xff69b4ff;
      case 'indianred':
        return 0xcd5c5cff;
      case 'indigo':
        return 0x4b0082ff;
      case 'ivory':
        return 0xfffff0ff;
      case 'khaki':
        return 0xf0e68cff;
      case 'lavender':
        return 0xe6e6faff;
      case 'lavenderblush':
        return 0xfff0f5ff;
      case 'lawngreen':
        return 0x7cfc00ff;
      case 'lemonchiffon':
        return 0xfffacdff;
      case 'lightblue':
        return 0xadd8e6ff;
      case 'lightcoral':
        return 0xf08080ff;
      case 'lightcyan':
        return 0xe0ffffff;
      case 'lightgoldenrodyellow':
        return 0xfafad2ff;
      case 'lightgray':
        return 0xd3d3d3ff;
      case 'lightgreen':
        return 0x90ee90ff;
      case 'lightgrey':
        return 0xd3d3d3ff;
      case 'lightpink':
        return 0xffb6c1ff;
      case 'lightsalmon':
        return 0xffa07aff;
      case 'lightseagreen':
        return 0x20b2aaff;
      case 'lightskyblue':
        return 0x87cefaff;
      case 'lightslategray':
        return 0x778899ff;
      case 'lightslategrey':
        return 0x778899ff;
      case 'lightsteelblue':
        return 0xb0c4deff;
      case 'lightyellow':
        return 0xffffe0ff;
      case 'lime':
        return 0x00ff00ff;
      case 'limegreen':
        return 0x32cd32ff;
      case 'linen':
        return 0xfaf0e6ff;
      case 'magenta':
        return 0xff00ffff;
      case 'maroon':
        return 0x800000ff;
      case 'mediumaquamarine':
        return 0x66cdaaff;
      case 'mediumblue':
        return 0x0000cdff;
      case 'mediumorchid':
        return 0xba55d3ff;
      case 'mediumpurple':
        return 0x9370dbff;
      case 'mediumseagreen':
        return 0x3cb371ff;
      case 'mediumslateblue':
        return 0x7b68eeff;
      case 'mediumspringgreen':
        return 0x00fa9aff;
      case 'mediumturquoise':
        return 0x48d1ccff;
      case 'mediumvioletred':
        return 0xc71585ff;
      case 'midnightblue':
        return 0x191970ff;
      case 'mintcream':
        return 0xf5fffaff;
      case 'mistyrose':
        return 0xffe4e1ff;
      case 'moccasin':
        return 0xffe4b5ff;
      case 'navajowhite':
        return 0xffdeadff;
      case 'navy':
        return 0x000080ff;
      case 'oldlace':
        return 0xfdf5e6ff;
      case 'olive':
        return 0x808000ff;
      case 'olivedrab':
        return 0x6b8e23ff;
      case 'orange':
        return 0xffa500ff;
      case 'orangered':
        return 0xff4500ff;
      case 'orchid':
        return 0xda70d6ff;
      case 'palegoldenrod':
        return 0xeee8aaff;
      case 'palegreen':
        return 0x98fb98ff;
      case 'paleturquoise':
        return 0xafeeeeff;
      case 'palevioletred':
        return 0xdb7093ff;
      case 'papayawhip':
        return 0xffefd5ff;
      case 'peachpuff':
        return 0xffdab9ff;
      case 'peru':
        return 0xcd853fff;
      case 'pink':
        return 0xffc0cbff;
      case 'plum':
        return 0xdda0ddff;
      case 'powderblue':
        return 0xb0e0e6ff;
      case 'purple':
        return 0x800080ff;
      case 'rebeccapurple':
        return 0x663399ff;
      case 'red':
        return 0xff0000ff;
      case 'rosybrown':
        return 0xbc8f8fff;
      case 'royalblue':
        return 0x4169e1ff;
      case 'saddlebrown':
        return 0x8b4513ff;
      case 'salmon':
        return 0xfa8072ff;
      case 'sandybrown':
        return 0xf4a460ff;
      case 'seagreen':
        return 0x2e8b57ff;
      case 'seashell':
        return 0xfff5eeff;
      case 'sienna':
        return 0xa0522dff;
      case 'silver':
        return 0xc0c0c0ff;
      case 'skyblue':
        return 0x87ceebff;
      case 'slateblue':
        return 0x6a5acdff;
      case 'slategray':
        return 0x708090ff;
      case 'slategrey':
        return 0x708090ff;
      case 'snow':
        return 0xfffafaff;
      case 'springgreen':
        return 0x00ff7fff;
      case 'steelblue':
        return 0x4682b4ff;
      case 'tan':
        return 0xd2b48cff;
      case 'teal':
        return 0x008080ff;
      case 'thistle':
        return 0xd8bfd8ff;
      case 'tomato':
        return 0xff6347ff;
      case 'turquoise':
        return 0x40e0d0ff;
      case 'violet':
        return 0xee82eeff;
      case 'wheat':
        return 0xf5deb3ff;
      case 'white':
        return 0xffffffff;
      case 'whitesmoke':
        return 0xf5f5f5ff;
      case 'yellow':
        return 0xffff00ff;
      case 'yellowgreen':
        return 0x9acd32ff;
    }
    return null;
  }
  module.exports = normalizeColor;
},79,[],"node_modules/react-native-web/node_modules/@react-native/normalize-colors/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /* eslint-disable */

  /**
   * JS Implementation of MurmurHash2
   *
   * @author <a href="mailto:gary.court@gmail.com">Gary Court</a>
   * @see http://github.com/garycourt/murmurhash-js
   * @author <a href="mailto:aappleby@gmail.com">Austin Appleby</a>
   * @see http://sites.google.com/site/murmurhash/
   *
   * @param {string} str ASCII only
   * @param {number} seed Positive integer only
   * @return {number} 32-bit positive integer hash
   *
   * 
   */

  function murmurhash2_32_gc(str, seed) {
    var l = str.length,
      h = seed ^ l,
      i = 0,
      k;
    while (l >= 4) {
      k = str.charCodeAt(i) & 0xff | (str.charCodeAt(++i) & 0xff) << 8 | (str.charCodeAt(++i) & 0xff) << 16 | (str.charCodeAt(++i) & 0xff) << 24;
      k = (k & 0xffff) * 0x5bd1e995 + (((k >>> 16) * 0x5bd1e995 & 0xffff) << 16);
      k ^= k >>> 24;
      k = (k & 0xffff) * 0x5bd1e995 + (((k >>> 16) * 0x5bd1e995 & 0xffff) << 16);
      h = (h & 0xffff) * 0x5bd1e995 + (((h >>> 16) * 0x5bd1e995 & 0xffff) << 16) ^ k;
      l -= 4;
      ++i;
    }
    switch (l) {
      case 3:
        h ^= (str.charCodeAt(i + 2) & 0xff) << 16;
      case 2:
        h ^= (str.charCodeAt(i + 1) & 0xff) << 8;
      case 1:
        h ^= str.charCodeAt(i) & 0xff;
        h = (h & 0xffff) * 0x5bd1e995 + (((h >>> 16) * 0x5bd1e995 & 0xffff) << 16);
    }
    h ^= h >>> 13;
    h = (h & 0xffff) * 0x5bd1e995 + (((h >>> 16) * 0x5bd1e995 & 0xffff) << 16);
    h ^= h >>> 15;
    return h >>> 0;
  }
  var hash = str => murmurhash2_32_gc(str, 1).toString(36);
  var _default = hash;
},80,[],"node_modules/react-native-web/dist/exports/StyleSheet/compiler/hash.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var uppercasePattern = /[A-Z]/g;
  var msPattern = /^ms-/;
  var cache = {};
  function toHyphenLower(match) {
    return '-' + match.toLowerCase();
  }
  function hyphenateStyleName(name) {
    if (name in cache) {
      return cache[name];
    }
    var hName = name.replace(uppercasePattern, toHyphenLower);
    return cache[name] = msPattern.test(hName) ? '-' + hName : hName;
  }
  var _default = hyphenateStyleName;
},81,[],"node_modules/react-native-web/dist/exports/StyleSheet/compiler/hyphenateStyleName.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _inlineStylePrefixerLibCreatePrefixer = require(_dependencyMap[0], "inline-style-prefixer/lib/createPrefixer");
  var createPrefixer = _interopDefault(_inlineStylePrefixerLibCreatePrefixer);
  var _static = require(_dependencyMap[1], "./static");
  var staticData = _interopDefault(_static);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var prefixAll = (0, createPrefixer.default)(staticData.default);
  var _default = prefixAll;
},82,[83,89],"node_modules/react-native-web/dist/modules/prefixStyles/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = createPrefixer;
  var _prefixProperty = require(_dependencyMap[0], "./utils/prefixProperty");
  var _prefixProperty2 = _interopRequireDefault(_prefixProperty);
  var _prefixValue = require(_dependencyMap[1], "./utils/prefixValue");
  var _prefixValue2 = _interopRequireDefault(_prefixValue);
  var _addNewValuesOnly = require(_dependencyMap[2], "./utils/addNewValuesOnly");
  var _addNewValuesOnly2 = _interopRequireDefault(_addNewValuesOnly);
  var _isObject = require(_dependencyMap[3], "./utils/isObject");
  var _isObject2 = _interopRequireDefault(_isObject);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  function createPrefixer(_ref) {
    var prefixMap = _ref.prefixMap,
      plugins = _ref.plugins;
    return function prefix(style) {
      for (var property in style) {
        var value = style[property];

        // handle nested objects
        if ((0, _isObject2.default)(value)) {
          style[property] = prefix(value);
          // handle array values
        } else if (Array.isArray(value)) {
          var combinedValue = [];
          for (var i = 0, len = value.length; i < len; ++i) {
            var processedValue = (0, _prefixValue2.default)(plugins, property, value[i], style, prefixMap);
            (0, _addNewValuesOnly2.default)(combinedValue, processedValue || value[i]);
          }

          // only modify the value if it was touched
          // by any plugin to prevent unnecessary mutations
          if (combinedValue.length > 0) {
            style[property] = combinedValue;
          }
        } else {
          var _processedValue = (0, _prefixValue2.default)(plugins, property, value, style, prefixMap);

          // only modify the value if it was touched
          // by any plugin to prevent unnecessary mutations
          if (_processedValue) {
            style[property] = _processedValue;
          }
          style = (0, _prefixProperty2.default)(prefixMap, property, style);
        }
      }
      return style;
    };
  }
},83,[84,86,87,88],"node_modules/inline-style-prefixer/lib/createPrefixer.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = prefixProperty;
  var _capitalizeString = require(_dependencyMap[0], "./capitalizeString");
  var _capitalizeString2 = _interopRequireDefault(_capitalizeString);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  function prefixProperty(prefixProperties, property, style) {
    var requiredPrefixes = prefixProperties[property];
    if (requiredPrefixes && style.hasOwnProperty(property)) {
      var capitalizedProperty = (0, _capitalizeString2.default)(property);
      for (var i = 0; i < requiredPrefixes.length; ++i) {
        var prefixedProperty = requiredPrefixes[i] + capitalizedProperty;
        if (!style[prefixedProperty]) {
          style[prefixedProperty] = style[property];
        }
      }
    }
    return style;
  }
},84,[85],"node_modules/inline-style-prefixer/lib/utils/prefixProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = capitalizeString;
  function capitalizeString(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
},85,[],"node_modules/inline-style-prefixer/lib/utils/capitalizeString.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = prefixValue;
  function prefixValue(plugins, property, value, style, metaData) {
    for (var i = 0, len = plugins.length; i < len; ++i) {
      var processedValue = plugins[i](property, value, style, metaData);

      // we can stop processing if a value is returned
      // as all plugin criteria are unique
      if (processedValue) {
        return processedValue;
      }
    }
  }
},86,[],"node_modules/inline-style-prefixer/lib/utils/prefixValue.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = addNewValuesOnly;
  function addIfNew(list, value) {
    if (list.indexOf(value) === -1) {
      list.push(value);
    }
  }
  function addNewValuesOnly(list, values) {
    if (Array.isArray(values)) {
      for (var i = 0, len = values.length; i < len; ++i) {
        addIfNew(list, values[i]);
      }
    } else {
      addIfNew(list, values);
    }
  }
},87,[],"node_modules/inline-style-prefixer/lib/utils/addNewValuesOnly.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isObject;
  function isObject(value) {
    return value instanceof Object && !Array.isArray(value);
  }
},88,[],"node_modules/inline-style-prefixer/lib/utils/isObject.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _inlineStylePrefixerLibPluginsCrossFade = require(_dependencyMap[0], "inline-style-prefixer/lib/plugins/crossFade");
  var crossFade = _interopDefault(_inlineStylePrefixerLibPluginsCrossFade);
  var _inlineStylePrefixerLibPluginsImageSet = require(_dependencyMap[1], "inline-style-prefixer/lib/plugins/imageSet");
  var imageSet = _interopDefault(_inlineStylePrefixerLibPluginsImageSet);
  var _inlineStylePrefixerLibPluginsLogical = require(_dependencyMap[2], "inline-style-prefixer/lib/plugins/logical");
  var logical = _interopDefault(_inlineStylePrefixerLibPluginsLogical);
  var _inlineStylePrefixerLibPluginsPosition = require(_dependencyMap[3], "inline-style-prefixer/lib/plugins/position");
  var position = _interopDefault(_inlineStylePrefixerLibPluginsPosition);
  var _inlineStylePrefixerLibPluginsSizing = require(_dependencyMap[4], "inline-style-prefixer/lib/plugins/sizing");
  var sizing = _interopDefault(_inlineStylePrefixerLibPluginsSizing);
  var _inlineStylePrefixerLibPluginsTransition = require(_dependencyMap[5], "inline-style-prefixer/lib/plugins/transition");
  var transition = _interopDefault(_inlineStylePrefixerLibPluginsTransition);
  var w = ['Webkit'];
  var m = ['Moz'];
  var wm = ['Webkit', 'Moz'];
  var wms = ['Webkit', 'ms'];
  var wmms = ['Webkit', 'Moz', 'ms'];
  var _default = {
    plugins: [crossFade.default, imageSet.default, logical.default, position.default, sizing.default, transition.default],
    prefixMap: {
      appearance: wmms,
      userSelect: wm,
      textEmphasisPosition: wms,
      textEmphasis: wms,
      textEmphasisStyle: wms,
      textEmphasisColor: wms,
      boxDecorationBreak: wms,
      clipPath: w,
      maskImage: wms,
      maskMode: wms,
      maskRepeat: wms,
      maskPosition: wms,
      maskClip: wms,
      maskOrigin: wms,
      maskSize: wms,
      maskComposite: wms,
      mask: wms,
      maskBorderSource: wms,
      maskBorderMode: wms,
      maskBorderSlice: wms,
      maskBorderWidth: wms,
      maskBorderOutset: wms,
      maskBorderRepeat: wms,
      maskBorder: wms,
      maskType: wms,
      textDecorationStyle: w,
      textDecorationSkip: w,
      textDecorationLine: w,
      textDecorationColor: w,
      filter: w,
      breakAfter: w,
      breakBefore: w,
      breakInside: w,
      columnCount: w,
      columnFill: w,
      columnGap: w,
      columnRule: w,
      columnRuleColor: w,
      columnRuleStyle: w,
      columnRuleWidth: w,
      columns: w,
      columnSpan: w,
      columnWidth: w,
      backdropFilter: w,
      hyphens: w,
      flowInto: w,
      flowFrom: w,
      regionFragment: w,
      textOrientation: w,
      tabSize: m,
      fontKerning: w,
      textSizeAdjust: w
    }
  };
},89,[90,105,107,108,109,110],"node_modules/react-native-web/dist/modules/prefixStyles/static.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = crossFade;
  var _cssInJsUtils = require(_dependencyMap[0], "css-in-js-utils");
  var CROSS_FADE_REGEX = /cross-fade\(/g;
  // http://caniuse.com/#search=cross-fade
  var prefixes = ['-webkit-', ''];
  function crossFade(property, value) {
    if (typeof value === 'string' && !(0, _cssInJsUtils.isPrefixedValue)(value) && value.indexOf('cross-fade(') !== -1) {
      return prefixes.map(function (prefix) {
        return value.replace(CROSS_FADE_REGEX, prefix + 'cross-fade(');
      });
    }
  }
},90,[91],"node_modules/inline-style-prefixer/lib/plugins/crossFade.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "assignStyle", {
    enumerable: true,
    get: function () {
      return assignStyle.default;
    }
  });
  Object.defineProperty(exports, "camelCaseProperty", {
    enumerable: true,
    get: function () {
      return camelCaseProperty.default;
    }
  });
  Object.defineProperty(exports, "cssifyDeclaration", {
    enumerable: true,
    get: function () {
      return cssifyDeclaration.default;
    }
  });
  Object.defineProperty(exports, "cssifyObject", {
    enumerable: true,
    get: function () {
      return cssifyObject.default;
    }
  });
  Object.defineProperty(exports, "hyphenateProperty", {
    enumerable: true,
    get: function () {
      return hyphenateProperty.default;
    }
  });
  Object.defineProperty(exports, "isPrefixedProperty", {
    enumerable: true,
    get: function () {
      return isPrefixedProperty.default;
    }
  });
  Object.defineProperty(exports, "isPrefixedValue", {
    enumerable: true,
    get: function () {
      return isPrefixedValue.default;
    }
  });
  Object.defineProperty(exports, "isUnitlessProperty", {
    enumerable: true,
    get: function () {
      return isUnitlessProperty.default;
    }
  });
  Object.defineProperty(exports, "normalizeProperty", {
    enumerable: true,
    get: function () {
      return normalizeProperty.default;
    }
  });
  Object.defineProperty(exports, "resolveArrayValue", {
    enumerable: true,
    get: function () {
      return resolveArrayValue.default;
    }
  });
  Object.defineProperty(exports, "unprefixProperty", {
    enumerable: true,
    get: function () {
      return unprefixProperty.default;
    }
  });
  Object.defineProperty(exports, "unprefixValue", {
    enumerable: true,
    get: function () {
      return unprefixValue.default;
    }
  });
  var _assignStyle = require(_dependencyMap[0], "./assignStyle");
  var assignStyle = _interopDefault(_assignStyle);
  var _camelCaseProperty = require(_dependencyMap[1], "./camelCaseProperty");
  var camelCaseProperty = _interopDefault(_camelCaseProperty);
  var _cssifyDeclaration = require(_dependencyMap[2], "./cssifyDeclaration");
  var cssifyDeclaration = _interopDefault(_cssifyDeclaration);
  var _cssifyObject = require(_dependencyMap[3], "./cssifyObject");
  var cssifyObject = _interopDefault(_cssifyObject);
  var _hyphenateProperty = require(_dependencyMap[4], "./hyphenateProperty");
  var hyphenateProperty = _interopDefault(_hyphenateProperty);
  var _isPrefixedProperty = require(_dependencyMap[5], "./isPrefixedProperty");
  var isPrefixedProperty = _interopDefault(_isPrefixedProperty);
  var _isPrefixedValue = require(_dependencyMap[6], "./isPrefixedValue");
  var isPrefixedValue = _interopDefault(_isPrefixedValue);
  var _isUnitlessProperty = require(_dependencyMap[7], "./isUnitlessProperty");
  var isUnitlessProperty = _interopDefault(_isUnitlessProperty);
  var _normalizeProperty = require(_dependencyMap[8], "./normalizeProperty");
  var normalizeProperty = _interopDefault(_normalizeProperty);
  var _resolveArrayValue = require(_dependencyMap[9], "./resolveArrayValue");
  var resolveArrayValue = _interopDefault(_resolveArrayValue);
  var _unprefixProperty = require(_dependencyMap[10], "./unprefixProperty");
  var unprefixProperty = _interopDefault(_unprefixProperty);
  var _unprefixValue = require(_dependencyMap[11], "./unprefixValue");
  var unprefixValue = _interopDefault(_unprefixValue);
},91,[92,93,94,97,95,98,99,100,101,103,102,104],"node_modules/css-in-js-utils/es/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return assignStyle;
    }
  });
  function _typeof(obj) {
    "@babel/helpers - typeof";

    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
      _typeof = function _typeof(obj) {
        return typeof obj;
      };
    } else {
      _typeof = function _typeof(obj) {
        return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
      };
    }
    return _typeof(obj);
  }
  function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
  }
  function _iterableToArray(iter) {
    if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
  }
  function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) return _arrayLikeToArray(arr);
  }
  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for (var i = 0, arr2 = new Array(len); i < len; i++) {
      arr2[i] = arr[i];
    }
    return arr2;
  }
  function filterUniqueArray(arr) {
    return arr.filter(function (val, index) {
      return arr.lastIndexOf(val) === index;
    });
  }
  function assignStyle(base) {
    for (var i = 0, len = arguments.length <= 1 ? 0 : arguments.length - 1; i < len; ++i) {
      var style = i + 1 < 1 || arguments.length <= i + 1 ? undefined : arguments[i + 1];
      for (var property in style) {
        var value = style[property];
        var baseValue = base[property];
        if (baseValue && value) {
          if (Array.isArray(baseValue)) {
            base[property] = filterUniqueArray(baseValue.concat(value));
            continue;
          }
          if (Array.isArray(value)) {
            base[property] = filterUniqueArray([baseValue].concat(_toConsumableArray(value)));
            continue;
          }
          if (_typeof(value) === 'object') {
            base[property] = assignStyle({}, baseValue, value);
            continue;
          }
        }
        base[property] = value;
      }
    }
    return base;
  }
},92,[],"node_modules/css-in-js-utils/es/assignStyle.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return camelCaseProperty;
    }
  });
  var DASH = /-([a-z])/g;
  var MS = /^Ms/g;
  var cache = {};
  function toUpper(match) {
    return match[1].toUpperCase();
  }
  function camelCaseProperty(property) {
    if (cache.hasOwnProperty(property)) {
      return cache[property];
    }
    var camelProp = property.replace(DASH, toUpper).replace(MS, 'ms');
    cache[property] = camelProp;
    return camelProp;
  }
},93,[],"node_modules/css-in-js-utils/es/camelCaseProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return cssifyDeclaration;
    }
  });
  var _hyphenateProperty = require(_dependencyMap[0], "./hyphenateProperty");
  var hyphenateProperty = _interopDefault(_hyphenateProperty);
  function cssifyDeclaration(property, value) {
    return (0, hyphenateProperty.default)(property) + ':' + value;
  }
},94,[95],"node_modules/css-in-js-utils/es/cssifyDeclaration.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return hyphenateProperty;
    }
  });
  var _hyphenateStyleName = require(_dependencyMap[0], "hyphenate-style-name");
  var hyphenateStyleName = _interopDefault(_hyphenateStyleName);
  function hyphenateProperty(property) {
    return (0, hyphenateStyleName.default)(property);
  }
},95,[96],"node_modules/css-in-js-utils/es/hyphenateProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /* eslint-disable no-var, prefer-template */
  var uppercasePattern = /[A-Z]/g;
  var msPattern = /^ms-/;
  var cache = {};
  function toHyphenLower(match) {
    return '-' + match.toLowerCase();
  }
  function hyphenateStyleName(name) {
    if (cache.hasOwnProperty(name)) {
      return cache[name];
    }
    var hName = name.replace(uppercasePattern, toHyphenLower);
    return cache[name] = msPattern.test(hName) ? '-' + hName : hName;
  }
  var _default = hyphenateStyleName;
},96,[],"node_modules/hyphenate-style-name/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return cssifyObject;
    }
  });
  var _cssifyDeclaration = require(_dependencyMap[0], "./cssifyDeclaration");
  var cssifyDeclaration = _interopDefault(_cssifyDeclaration);
  function cssifyObject(style) {
    var css = '';
    for (var property in style) {
      var value = style[property];
      if (typeof value !== 'string' && typeof value !== 'number') {
        continue;
      } // prevents the semicolon after
      // the last rule declaration

      if (css) {
        css += ';';
      }
      css += (0, cssifyDeclaration.default)(property, value);
    }
    return css;
  }
},97,[94],"node_modules/css-in-js-utils/es/cssifyObject.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return isPrefixedProperty;
    }
  });
  var RE = /^(Webkit|Moz|O|ms)/;
  function isPrefixedProperty(property) {
    return RE.test(property);
  }
},98,[],"node_modules/css-in-js-utils/es/isPrefixedProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return isPrefixedValue;
    }
  });
  var RE = /-webkit-|-moz-|-ms-/;
  function isPrefixedValue(value) {
    return typeof value === 'string' && RE.test(value);
  }
},99,[],"node_modules/css-in-js-utils/es/isPrefixedValue.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return isUnitlessProperty;
    }
  });
  var _hyphenateProperty = require(_dependencyMap[0], "./hyphenateProperty");
  var hyphenateProperty = _interopDefault(_hyphenateProperty);
  var unitlessProperties = {
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    fontWeight: true,
    lineHeight: true,
    opacity: true,
    orphans: true,
    tabSize: true,
    widows: true,
    zIndex: true,
    zoom: true,
    // SVG-related properties
    fillOpacity: true,
    floodOpacity: true,
    stopOpacity: true,
    strokeDasharray: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true
  };
  var prefixedUnitlessProperties = ['animationIterationCount', 'boxFlex', 'boxFlexGroup', 'boxOrdinalGroup', 'columnCount', 'flex', 'flexGrow', 'flexPositive', 'flexShrink', 'flexNegative', 'flexOrder', 'gridColumn', 'gridColumnEnd', 'gridColumnStart', 'gridRow', 'gridRowEnd', 'gridRowStart', 'lineClamp', 'order'];
  var prefixes = ['Webkit', 'ms', 'Moz', 'O'];
  function getPrefixedProperty(prefix, property) {
    return prefix + property.charAt(0).toUpperCase() + property.slice(1);
  } // add all prefixed properties to the unitless properties

  for (var i = 0, len = prefixedUnitlessProperties.length; i < len; ++i) {
    var property = prefixedUnitlessProperties[i];
    unitlessProperties[property] = true;
    for (var j = 0, jLen = prefixes.length; j < jLen; ++j) {
      unitlessProperties[getPrefixedProperty(prefixes[j], property)] = true;
    }
  } // add all hypenated properties as well

  for (var _property in unitlessProperties) {
    unitlessProperties[(0, hyphenateProperty.default)(_property)] = true;
  }
  function isUnitlessProperty(property) {
    return unitlessProperties.hasOwnProperty(property);
  }
},100,[95],"node_modules/css-in-js-utils/es/isUnitlessProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return normalizeProperty;
    }
  });
  var _camelCaseProperty = require(_dependencyMap[0], "./camelCaseProperty");
  var camelCaseProperty = _interopDefault(_camelCaseProperty);
  var _unprefixProperty = require(_dependencyMap[1], "./unprefixProperty");
  var unprefixProperty = _interopDefault(_unprefixProperty);
  function normalizeProperty(property) {
    return (0, unprefixProperty.default)((0, camelCaseProperty.default)(property));
  }
},101,[93,102],"node_modules/css-in-js-utils/es/normalizeProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return unprefixProperty;
    }
  });
  var RE = /^(ms|Webkit|Moz|O)/;
  function unprefixProperty(property) {
    var propertyWithoutPrefix = property.replace(RE, '');
    return propertyWithoutPrefix.charAt(0).toLowerCase() + propertyWithoutPrefix.slice(1);
  }
},102,[],"node_modules/css-in-js-utils/es/unprefixProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return resolveArrayValue;
    }
  });
  var _hyphenateProperty = require(_dependencyMap[0], "./hyphenateProperty");
  var hyphenateProperty = _interopDefault(_hyphenateProperty);
  function resolveArrayValue(property, value) {
    return value.join(';' + (0, hyphenateProperty.default)(property) + ':');
  }
},103,[95],"node_modules/css-in-js-utils/es/resolveArrayValue.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return unprefixValue;
    }
  });
  var RE = /(-ms-|-webkit-|-moz-|-o-)/g;
  function unprefixValue(value) {
    if (typeof value === 'string') {
      return value.replace(RE, '');
    }
    return value;
  }
},104,[],"node_modules/css-in-js-utils/es/unprefixValue.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = imageSet;
  var _isPrefixedValue = require(_dependencyMap[0], "css-in-js-utils/lib/isPrefixedValue");
  var _isPrefixedValue2 = _interopRequireDefault(_isPrefixedValue);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }

  // http://caniuse.com/#feat=css-image-set
  var prefixes = ['-webkit-', ''];
  function imageSet(property, value) {
    if (typeof value === 'string' && !(0, _isPrefixedValue2.default)(value) && value.indexOf('image-set(') > -1) {
      return prefixes.map(function (prefix) {
        return value.replace(/image-set\(/g, prefix + 'image-set(');
      });
    }
  }
},105,[106],"node_modules/inline-style-prefixer/lib/plugins/imageSet.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = isPrefixedValue;
  var RE = /-webkit-|-moz-|-ms-/;
  function isPrefixedValue(value) {
    return typeof value === 'string' && RE.test(value);
  }
},106,[],"node_modules/css-in-js-utils/lib/isPrefixedValue.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = logical;
  var alternativeProps = {
    marginBlockStart: ['WebkitMarginBefore'],
    marginBlockEnd: ['WebkitMarginAfter'],
    marginInlineStart: ['WebkitMarginStart', 'MozMarginStart'],
    marginInlineEnd: ['WebkitMarginEnd', 'MozMarginEnd'],
    paddingBlockStart: ['WebkitPaddingBefore'],
    paddingBlockEnd: ['WebkitPaddingAfter'],
    paddingInlineStart: ['WebkitPaddingStart', 'MozPaddingStart'],
    paddingInlineEnd: ['WebkitPaddingEnd', 'MozPaddingEnd'],
    borderBlockStart: ['WebkitBorderBefore'],
    borderBlockStartColor: ['WebkitBorderBeforeColor'],
    borderBlockStartStyle: ['WebkitBorderBeforeStyle'],
    borderBlockStartWidth: ['WebkitBorderBeforeWidth'],
    borderBlockEnd: ['WebkitBorderAfter'],
    borderBlockEndColor: ['WebkitBorderAfterColor'],
    borderBlockEndStyle: ['WebkitBorderAfterStyle'],
    borderBlockEndWidth: ['WebkitBorderAfterWidth'],
    borderInlineStart: ['WebkitBorderStart', 'MozBorderStart'],
    borderInlineStartColor: ['WebkitBorderStartColor', 'MozBorderStartColor'],
    borderInlineStartStyle: ['WebkitBorderStartStyle', 'MozBorderStartStyle'],
    borderInlineStartWidth: ['WebkitBorderStartWidth', 'MozBorderStartWidth'],
    borderInlineEnd: ['WebkitBorderEnd', 'MozBorderEnd'],
    borderInlineEndColor: ['WebkitBorderEndColor', 'MozBorderEndColor'],
    borderInlineEndStyle: ['WebkitBorderEndStyle', 'MozBorderEndStyle'],
    borderInlineEndWidth: ['WebkitBorderEndWidth', 'MozBorderEndWidth']
  };
  function logical(property, value, style) {
    if (Object.prototype.hasOwnProperty.call(alternativeProps, property)) {
      var alternativePropList = alternativeProps[property];
      for (var i = 0, len = alternativePropList.length; i < len; ++i) {
        style[alternativePropList[i]] = value;
      }
    }
  }
},107,[],"node_modules/inline-style-prefixer/lib/plugins/logical.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = position;
  function position(property, value) {
    if (property === 'position' && value === 'sticky') {
      return ['-webkit-sticky', 'sticky'];
    }
  }
},108,[],"node_modules/inline-style-prefixer/lib/plugins/position.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = sizing;
  var prefixes = ['-webkit-', '-moz-', ''];
  var properties = {
    maxHeight: true,
    maxWidth: true,
    width: true,
    height: true,
    columnWidth: true,
    minWidth: true,
    minHeight: true
  };
  var values = {
    'min-content': true,
    'max-content': true,
    'fill-available': true,
    'fit-content': true,
    'contain-floats': true
  };
  function sizing(property, value) {
    if (properties.hasOwnProperty(property) && values.hasOwnProperty(value)) {
      return prefixes.map(function (prefix) {
        return prefix + value;
      });
    }
  }
},109,[],"node_modules/inline-style-prefixer/lib/plugins/sizing.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = transition;
  var _hyphenateProperty = require(_dependencyMap[0], "css-in-js-utils/lib/hyphenateProperty");
  var _hyphenateProperty2 = _interopRequireDefault(_hyphenateProperty);
  var _isPrefixedValue = require(_dependencyMap[1], "css-in-js-utils/lib/isPrefixedValue");
  var _isPrefixedValue2 = _interopRequireDefault(_isPrefixedValue);
  var _capitalizeString = require(_dependencyMap[2], "../utils/capitalizeString");
  var _capitalizeString2 = _interopRequireDefault(_capitalizeString);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  var properties = {
    transition: true,
    transitionProperty: true,
    WebkitTransition: true,
    WebkitTransitionProperty: true,
    MozTransition: true,
    MozTransitionProperty: true
  };
  var prefixMapping = {
    Webkit: '-webkit-',
    Moz: '-moz-',
    ms: '-ms-'
  };
  function prefixValue(value, propertyPrefixMap) {
    if ((0, _isPrefixedValue2.default)(value)) {
      return value;
    }

    // only split multi values, not cubic beziers
    var multipleValues = value.split(/,(?![^()]*(?:\([^()]*\))?\))/g);
    for (var i = 0, len = multipleValues.length; i < len; ++i) {
      var singleValue = multipleValues[i];
      var values = [singleValue];
      for (var property in propertyPrefixMap) {
        var dashCaseProperty = (0, _hyphenateProperty2.default)(property);
        if (singleValue.indexOf(dashCaseProperty) > -1 && dashCaseProperty !== 'order') {
          var prefixes = propertyPrefixMap[property];
          for (var j = 0, pLen = prefixes.length; j < pLen; ++j) {
            // join all prefixes and create a new value
            values.unshift(singleValue.replace(dashCaseProperty, prefixMapping[prefixes[j]] + dashCaseProperty));
          }
        }
      }
      multipleValues[i] = values.join(',');
    }
    return multipleValues.join(',');
  }
  function transition(property, value, style, propertyPrefixMap) {
    // also check for already prefixed transitions
    if (typeof value === 'string' && properties.hasOwnProperty(property)) {
      var outputValue = prefixValue(value, propertyPrefixMap);
      // if the property is already prefixed
      var webkitOutput = outputValue.split(/,(?![^()]*(?:\([^()]*\))?\))/g).filter(function (val) {
        return !/-moz-|-ms-/.test(val);
      }).join(',');
      if (property.indexOf('Webkit') > -1) {
        return webkitOutput;
      }
      var mozOutput = outputValue.split(/,(?![^()]*(?:\([^()]*\))?\))/g).filter(function (val) {
        return !/-webkit-|-ms-/.test(val);
      }).join(',');
      if (property.indexOf('Moz') > -1) {
        return mozOutput;
      }
      style['Webkit' + (0, _capitalizeString2.default)(property)] = webkitOutput;
      style['Moz' + (0, _capitalizeString2.default)(property)] = mozOutput;
      return outputValue;
    }
  }
},110,[111,106,85],"node_modules/inline-style-prefixer/lib/plugins/transition.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = hyphenateProperty;
  var _hyphenateStyleName = require(_dependencyMap[0], "hyphenate-style-name");
  var _hyphenateStyleName2 = _interopRequireDefault(_hyphenateStyleName);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      "default": obj
    };
  }
  function hyphenateProperty(property) {
    return (0, _hyphenateStyleName2["default"])(property);
  }
},111,[96],"node_modules/css-in-js-utils/lib/hyphenateProperty.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Nicolas Gallagher
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  module.exports = require(_dependencyMap[0], "./dist/transform-localize-style");
},112,[113],"node_modules/styleq/transform-localize-style.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Nicolas Gallagher
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.localizeStyle = localizeStyle;
  var cache = new WeakMap();
  var markerProp = '$$css$localize';
  /**
   * The compiler polyfills logical properties and values, generating a class
   * name for both writing directions. The style objects are annotated by
   * the compiler as needing this runtime transform. The results are memoized.
   *
   * { '$$css$localize': true, float: [ 'float-left', 'float-right' ] }
   * => { float: 'float-left' }
   */

  function compileStyle(style, isRTL) {
    // Create a new compiled style for styleq
    var compiledStyle = {};
    for (var prop in style) {
      if (prop !== markerProp) {
        var value = style[prop];
        if (Array.isArray(value)) {
          compiledStyle[prop] = isRTL ? value[1] : value[0];
        } else {
          compiledStyle[prop] = value;
        }
      }
    }
    return compiledStyle;
  }
  function localizeStyle(style, isRTL) {
    if (style[markerProp] != null) {
      var compiledStyleIndex = isRTL ? 1 : 0; // Check the cache in case we've already seen this object

      if (cache.has(style)) {
        var _cachedStyles = cache.get(style);
        var _compiledStyle = _cachedStyles[compiledStyleIndex];
        if (_compiledStyle == null) {
          // Update the missing cache entry
          _compiledStyle = compileStyle(style, isRTL);
          _cachedStyles[compiledStyleIndex] = _compiledStyle;
          cache.set(style, _cachedStyles);
        }
        return _compiledStyle;
      } // Create a new compiled style for styleq

      var compiledStyle = compileStyle(style, isRTL);
      var cachedStyles = new Array(2);
      cachedStyles[compiledStyleIndex] = compiledStyle;
      cache.set(style, cachedStyles);
      return compiledStyle;
    }
    return style;
  }
},113,[],"node_modules/styleq/dist/transform-localize-style.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  Object.defineProperty(exports, "createBoxShadowValue", {
    enumerable: true,
    get: function () {
      return createBoxShadowValue;
    }
  });
  Object.defineProperty(exports, "createTextShadowValue", {
    enumerable: true,
    get: function () {
      return createTextShadowValue;
    }
  });
  Object.defineProperty(exports, "createBoxShadowArrayValue", {
    enumerable: true,
    get: function () {
      return createBoxShadowArrayValue;
    }
  });
  Object.defineProperty(exports, "createTransformValue", {
    enumerable: true,
    get: function () {
      return createTransformValue;
    }
  });
  Object.defineProperty(exports, "createTransformOriginValue", {
    enumerable: true,
    get: function () {
      return createTransformOriginValue;
    }
  });
  Object.defineProperty(exports, "preprocess", {
    enumerable: true,
    get: function () {
      return preprocess;
    }
  });
  var _compilerNormalizeColor = require(_dependencyMap[0], "./compiler/normalizeColor");
  var normalizeColor = _interopDefault(_compilerNormalizeColor);
  var _compilerNormalizeValueWithProperty = require(_dependencyMap[1], "./compiler/normalizeValueWithProperty");
  var normalizeValueWithProperty = _interopDefault(_compilerNormalizeValueWithProperty);
  var _modulesWarnOnce = require(_dependencyMap[2], "../../modules/warnOnce");
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var emptyObject = {};

  /**
   * Shadows
   */

  var defaultOffset = {
    height: 0,
    width: 0
  };
  var createBoxShadowValue = style => {
    var shadowColor = style.shadowColor,
      shadowOffset = style.shadowOffset,
      shadowOpacity = style.shadowOpacity,
      shadowRadius = style.shadowRadius;
    var _ref = shadowOffset || defaultOffset,
      height = _ref.height,
      width = _ref.width;
    var offsetX = (0, normalizeValueWithProperty.default)(width);
    var offsetY = (0, normalizeValueWithProperty.default)(height);
    var blurRadius = (0, normalizeValueWithProperty.default)(shadowRadius || 0);
    var color = (0, normalizeColor.default)(shadowColor || 'black', shadowOpacity);
    if (color != null && offsetX != null && offsetY != null && blurRadius != null) {
      return offsetX + " " + offsetY + " " + blurRadius + " " + color;
    }
  };
  var createTextShadowValue = style => {
    var textShadowColor = style.textShadowColor,
      textShadowOffset = style.textShadowOffset,
      textShadowRadius = style.textShadowRadius;
    var _ref2 = textShadowOffset || defaultOffset,
      height = _ref2.height,
      width = _ref2.width;
    var radius = textShadowRadius || 0;
    var offsetX = (0, normalizeValueWithProperty.default)(width);
    var offsetY = (0, normalizeValueWithProperty.default)(height);
    var blurRadius = (0, normalizeValueWithProperty.default)(radius);
    var color = (0, normalizeValueWithProperty.default)(textShadowColor, 'textShadowColor');
    if (color && (height !== 0 || width !== 0 || radius !== 0) && offsetX != null && offsetY != null && blurRadius != null) {
      return offsetX + " " + offsetY + " " + blurRadius + " " + color;
    }
  };

  // { offsetX: 1, offsetY: 2, blurRadius: 3, spreadDistance: 4, color: 'rgba(255, 0, 0)', inset: true }
  // => 'rgba(255, 0, 0) 1px 2px 3px 4px inset'
  var mapBoxShadow = boxShadow => {
    if (typeof boxShadow === 'string') {
      return boxShadow;
    }
    var offsetX = (0, normalizeValueWithProperty.default)(boxShadow.offsetX) || 0;
    var offsetY = (0, normalizeValueWithProperty.default)(boxShadow.offsetY) || 0;
    var blurRadius = (0, normalizeValueWithProperty.default)(boxShadow.blurRadius) || 0;
    var spreadDistance = (0, normalizeValueWithProperty.default)(boxShadow.spreadDistance) || 0;
    var color = (0, normalizeColor.default)(boxShadow.color) || 'black';
    var position = boxShadow.inset ? 'inset ' : '';
    return "" + position + offsetX + " " + offsetY + " " + blurRadius + " " + spreadDistance + " " + color;
  };
  var createBoxShadowArrayValue = value => {
    return value.map(mapBoxShadow).join(', ');
  };

  // { scale: 2 } => 'scale(2)'
  // { translateX: 20 } => 'translateX(20px)'
  // { matrix: [1,2,3,4,5,6] } => 'matrix(1,2,3,4,5,6)'
  var mapTransform = transform => {
    var type = Object.keys(transform)[0];
    var value = transform[type];
    if (type === 'matrix' || type === 'matrix3d') {
      return type + "(" + value.join(',') + ")";
    } else {
      var normalizedValue = (0, normalizeValueWithProperty.default)(value, type);
      return type + "(" + normalizedValue + ")";
    }
  };
  var createTransformValue = value => {
    return value.map(mapTransform).join(' ');
  };

  // [2, '30%', 10] => '2px 30% 10px'
  var createTransformOriginValue = value => {
    return value.map(v => (0, normalizeValueWithProperty.default)(v)).join(' ');
  };
  var PROPERTIES_STANDARD = {
    borderBottomEndRadius: 'borderEndEndRadius',
    borderBottomStartRadius: 'borderEndStartRadius',
    borderTopEndRadius: 'borderStartEndRadius',
    borderTopStartRadius: 'borderStartStartRadius',
    borderEndColor: 'borderInlineEndColor',
    borderEndStyle: 'borderInlineEndStyle',
    borderEndWidth: 'borderInlineEndWidth',
    borderStartColor: 'borderInlineStartColor',
    borderStartStyle: 'borderInlineStartStyle',
    borderStartWidth: 'borderInlineStartWidth',
    end: 'insetInlineEnd',
    marginEnd: 'marginInlineEnd',
    marginHorizontal: 'marginInline',
    marginStart: 'marginInlineStart',
    marginVertical: 'marginBlock',
    paddingEnd: 'paddingInlineEnd',
    paddingHorizontal: 'paddingInline',
    paddingStart: 'paddingInlineStart',
    paddingVertical: 'paddingBlock',
    start: 'insetInlineStart'
  };
  var ignoredProps = {
    elevation: true,
    overlayColor: true,
    resizeMode: true,
    tintColor: true
  };

  /**
   * Preprocess styles
   */
  var preprocess = function preprocess(originalStyle, options) {
    if (options === void 0) {
      options = {};
    }
    var style = originalStyle || emptyObject;
    var nextStyle = {};

    // Convert shadow styles
    if (options.shadow === true, style.shadowColor != null || style.shadowOffset != null || style.shadowOpacity != null || style.shadowRadius != null) {
      (0, _modulesWarnOnce.warnOnce)('shadowStyles', "\"shadow*\" style props are deprecated. Use \"boxShadow\".");
      var boxShadowValue = createBoxShadowValue(style);
      if (boxShadowValue != null) {
        nextStyle.boxShadow = boxShadowValue;
      }
    }

    // Convert text shadow styles
    if (options.textShadow === true, style.textShadowColor != null || style.textShadowOffset != null || style.textShadowRadius != null) {
      (0, _modulesWarnOnce.warnOnce)('textShadowStyles', "\"textShadow*\" style props are deprecated. Use \"textShadow\".");
      var textShadowValue = createTextShadowValue(style);
      if (textShadowValue != null && nextStyle.textShadow == null) {
        var textShadow = style.textShadow;
        var value = textShadow ? textShadow + ", " + textShadowValue : textShadowValue;
        nextStyle.textShadow = value;
      }
    }
    for (var originalProp in style) {
      if (
      // Ignore some React Native styles
      ignoredProps[originalProp] != null || originalProp === 'shadowColor' || originalProp === 'shadowOffset' || originalProp === 'shadowOpacity' || originalProp === 'shadowRadius' || originalProp === 'textShadowColor' || originalProp === 'textShadowOffset' || originalProp === 'textShadowRadius') {
        continue;
      }
      var originalValue = style[originalProp];
      var prop = PROPERTIES_STANDARD[originalProp] || originalProp;
      var _value = originalValue;
      if (!Object.prototype.hasOwnProperty.call(style, originalProp) || prop !== originalProp && style[prop] != null) {
        continue;
      }
      if (prop === 'aspectRatio' && typeof _value === 'number') {
        nextStyle[prop] = _value.toString();
      } else if (prop === 'boxShadow') {
        if (Array.isArray(_value)) {
          _value = createBoxShadowArrayValue(_value);
        }
        var boxShadow = nextStyle.boxShadow;
        nextStyle.boxShadow = boxShadow ? _value + ", " + boxShadow : _value;
      } else if (prop === 'fontVariant') {
        if (Array.isArray(_value) && _value.length > 0) {
          /*
          warnOnce(
            'fontVariant',
            '"fontVariant" style array value is deprecated. Use space-separated values.'
          );
          */
          _value = _value.join(' ');
        }
        nextStyle[prop] = _value;
      } else if (prop === 'textAlignVertical') {
        /*
        warnOnce(
          'textAlignVertical',
          '"textAlignVertical" style is deprecated. Use "verticalAlign".'
        );
        */
        if (style.verticalAlign == null) {
          nextStyle.verticalAlign = _value === 'center' ? 'middle' : _value;
        }
      } else if (prop === 'transform') {
        if (Array.isArray(_value)) {
          _value = createTransformValue(_value);
        }
        nextStyle.transform = _value;
      } else if (prop === 'transformOrigin') {
        if (Array.isArray(_value)) {
          _value = createTransformOriginValue(_value);
        }
        nextStyle.transformOrigin = _value;
      } else {
        nextStyle[prop] = _value;
      }
    }

    // $FlowIgnore
    return nextStyle;
  };
  var _default = preprocess;
},114,[76,74,115],"node_modules/react-native-web/dist/exports/StyleSheet/preprocess.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.warnOnce = warnOnce;
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var warnedKeys = {};

  /**
   * A simple function that prints a warning message once per session.
   *
   * @param {string} key - The key used to ensure the message is printed once.
   *                       This should be unique to the callsite.
   * @param {string} message - The message to print
   */
  function warnOnce(key, message) {
    if (process.env.NODE_ENV !== 'production') {
      if (warnedKeys[key]) {
        return;
      }
      console.warn(message);
      warnedKeys[key] = true;
    }
  }
},115,[],"node_modules/react-native-web/dist/modules/warnOnce/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Nicolas Gallagher
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.styleq = void 0;
  var cache = new WeakMap();
  var compiledKey = '$$css';
  function createStyleq(options) {
    var disableCache;
    var disableMix;
    var transform;
    if (options != null) {
      disableCache = options.disableCache === true;
      disableMix = options.disableMix === true;
      transform = options.transform;
    }
    return function styleq() {
      // Keep track of property commits to the className
      var definedProperties = []; // The className and inline style to build up

      var className = '';
      var inlineStyle = null; // The current position in the cache graph

      var nextCache = disableCache ? null : cache; // This way of creating an array from arguments is fastest

      var styles = new Array(arguments.length);
      for (var i = 0; i < arguments.length; i++) {
        styles[i] = arguments[i];
      } // Iterate over styles from last to first

      while (styles.length > 0) {
        var possibleStyle = styles.pop(); // Skip empty items

        if (possibleStyle == null || possibleStyle === false) {
          continue;
        } // Push nested styles back onto the stack to be processed

        if (Array.isArray(possibleStyle)) {
          for (var _i = 0; _i < possibleStyle.length; _i++) {
            styles.push(possibleStyle[_i]);
          }
          continue;
        } // Process an individual style object

        var style = transform != null ? transform(possibleStyle) : possibleStyle;
        if (style.$$css) {
          // Build up the class names defined by this object
          var classNameChunk = ''; // Check the cache to see if we've already done this work

          if (nextCache != null && nextCache.has(style)) {
            // Cache: read
            var cacheEntry = nextCache.get(style);
            if (cacheEntry != null) {
              classNameChunk = cacheEntry[0]; // $FlowIgnore

              definedProperties.push.apply(definedProperties, cacheEntry[1]);
              nextCache = cacheEntry[2];
            }
          } // Update the chunks with data from this object
          else {
            // The properties defined by this object
            var definedPropertiesChunk = [];
            for (var prop in style) {
              var value = style[prop];
              if (prop === compiledKey) continue; // Each property value is used as an HTML class name
              // { 'debug.string': 'debug.string', opacity: 's-jskmnoqp' }

              if (typeof value === 'string' || value === null) {
                // Only add to chunks if this property hasn't already been seen
                if (!definedProperties.includes(prop)) {
                  definedProperties.push(prop);
                  if (nextCache != null) {
                    definedPropertiesChunk.push(prop);
                  }
                  if (typeof value === 'string') {
                    classNameChunk += classNameChunk ? ' ' + value : value;
                  }
                }
              } // If we encounter a value that isn't a string or `null`
              else {
                console.error("styleq: ".concat(prop, " typeof ").concat(String(value), " is not \"string\" or \"null\"."));
              }
            } // Cache: write

            if (nextCache != null) {
              // Create the next WeakMap for this sequence of styles
              var weakMap = new WeakMap();
              nextCache.set(style, [classNameChunk, definedPropertiesChunk, weakMap]);
              nextCache = weakMap;
            }
          } // Order of classes in chunks matches property-iteration order of style
          // object. Order of chunks matches passed order of styles from first to
          // last (which we iterate over in reverse).

          if (classNameChunk) {
            className = className ? classNameChunk + ' ' + className : classNameChunk;
          }
        } // ----- DYNAMIC: Process inline style object -----
        else {
          if (disableMix) {
            if (inlineStyle == null) {
              inlineStyle = {};
            }
            inlineStyle = Object.assign({}, style, inlineStyle);
          } else {
            var subStyle = null;
            for (var _prop in style) {
              var _value = style[_prop];
              if (_value !== undefined) {
                if (!definedProperties.includes(_prop)) {
                  if (_value != null) {
                    if (inlineStyle == null) {
                      inlineStyle = {};
                    }
                    if (subStyle == null) {
                      subStyle = {};
                    }
                    subStyle[_prop] = _value;
                  }
                  definedProperties.push(_prop); // Cache is unnecessary overhead if results can't be reused.

                  nextCache = null;
                }
              }
            }
            if (subStyle != null) {
              inlineStyle = Object.assign(subStyle, inlineStyle);
            }
          }
        }
      }
      var styleProps = [className, inlineStyle];
      return styleProps;
    };
  }
  var styleq = createStyleq();
  exports.styleq = styleq;
  styleq.factory = createStyleq;
},116,[],"node_modules/styleq/dist/styleq.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.validate = validate;
  var _postcssValueParser = require(_dependencyMap[0], "postcss-value-parser");
  var valueParser = _interopDefault(_postcssValueParser);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var invalidShortforms = {
    background: true,
    borderBottom: true,
    borderLeft: true,
    borderRight: true,
    borderTop: true,
    font: true,
    grid: true,
    outline: true,
    textDecoration: true
  };
  var invalidMultiValueShortforms = {
    flex: true,
    margin: true,
    padding: true,
    borderColor: true,
    borderRadius: true,
    borderStyle: true,
    borderWidth: true,
    inset: true,
    insetBlock: true,
    insetInline: true,
    marginBlock: true,
    marginInline: true,
    marginHorizontal: true,
    marginVertical: true,
    paddingBlock: true,
    paddingInline: true,
    paddingHorizontal: true,
    paddingVertical: true,
    overflow: true,
    overscrollBehavior: true,
    backgroundPosition: true
  };
  function error(message) {
    console.error(message);
  }
  function validate(obj) {
    for (var k in obj) {
      var prop = k.trim();
      var value = obj[prop];
      var isInvalid = false;
      if (value === null) {
        continue;
      }
      if (typeof value === 'string' && value.indexOf('!important') > -1) {
        error("Invalid style declaration \"" + prop + ":" + value + "\". Values cannot include \"!important\"");
        isInvalid = true;
      } else {
        var suggestion = '';
        if (prop === 'animation' || prop === 'animationName') {
          suggestion = 'Did you mean "animationKeyframes"?';
          isInvalid = true;
        } else if (prop === 'direction') {
          suggestion = 'Did you mean "writingDirection"?';
          isInvalid = true;
        } else if (invalidShortforms[prop]) {
          suggestion = 'Please use long-form properties.';
          isInvalid = true;
        } else if (invalidMultiValueShortforms[prop]) {
          if (typeof value === 'string' && (0, valueParser.default)(value).nodes.length > 1) {
            suggestion = "Value is \"" + value + "\" but only single values are supported.";
            isInvalid = true;
          }
        }
        if (suggestion !== '') {
          error("Invalid style property of \"" + prop + "\". " + suggestion);
        }
      }
      if (isInvalid) {
        delete obj[k];
      }
    }
  }
},117,[118],"node_modules/react-native-web/dist/exports/StyleSheet/validate.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  var parse = require(_dependencyMap[0], "./parse");
  var walk = require(_dependencyMap[1], "./walk");
  var stringify = require(_dependencyMap[2], "./stringify");
  function ValueParser(value) {
    if (this instanceof ValueParser) {
      this.nodes = parse(value);
      return this;
    }
    return new ValueParser(value);
  }
  ValueParser.prototype.toString = function () {
    return Array.isArray(this.nodes) ? stringify(this.nodes) : "";
  };
  ValueParser.prototype.walk = function (cb, bubble) {
    walk(this.nodes, cb, bubble);
    return this;
  };
  ValueParser.unit = require(_dependencyMap[3], "./unit");
  ValueParser.walk = walk;
  ValueParser.stringify = stringify;
  module.exports = ValueParser;
},118,[119,120,121,122],"node_modules/postcss-value-parser/lib/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  var openParentheses = "(".charCodeAt(0);
  var closeParentheses = ")".charCodeAt(0);
  var singleQuote = "'".charCodeAt(0);
  var doubleQuote = '"'.charCodeAt(0);
  var backslash = "\\".charCodeAt(0);
  var slash = "/".charCodeAt(0);
  var comma = ",".charCodeAt(0);
  var colon = ":".charCodeAt(0);
  var star = "*".charCodeAt(0);
  var uLower = "u".charCodeAt(0);
  var uUpper = "U".charCodeAt(0);
  var plus = "+".charCodeAt(0);
  var isUnicodeRange = /^[a-f0-9?-]+$/i;
  module.exports = function (input) {
    var tokens = [];
    var value = input;
    var next, quote, prev, token, escape, escapePos, whitespacePos, parenthesesOpenPos;
    var pos = 0;
    var code = value.charCodeAt(pos);
    var max = value.length;
    var stack = [{
      nodes: tokens
    }];
    var balanced = 0;
    var parent;
    var name = "";
    var before = "";
    var after = "";
    while (pos < max) {
      // Whitespaces
      if (code <= 32) {
        next = pos;
        do {
          next += 1;
          code = value.charCodeAt(next);
        } while (code <= 32);
        token = value.slice(pos, next);
        prev = tokens[tokens.length - 1];
        if (code === closeParentheses && balanced) {
          after = token;
        } else if (prev && prev.type === "div") {
          prev.after = token;
          prev.sourceEndIndex += token.length;
        } else if (code === comma || code === colon || code === slash && value.charCodeAt(next + 1) !== star && (!parent || parent && parent.type === "function" && parent.value !== "calc")) {
          before = token;
        } else {
          tokens.push({
            type: "space",
            sourceIndex: pos,
            sourceEndIndex: next,
            value: token
          });
        }
        pos = next;

        // Quotes
      } else if (code === singleQuote || code === doubleQuote) {
        next = pos;
        quote = code === singleQuote ? "'" : '"';
        token = {
          type: "string",
          sourceIndex: pos,
          quote: quote
        };
        do {
          escape = false;
          next = value.indexOf(quote, next + 1);
          if (~next) {
            escapePos = next;
            while (value.charCodeAt(escapePos - 1) === backslash) {
              escapePos -= 1;
              escape = !escape;
            }
          } else {
            value += quote;
            next = value.length - 1;
            token.unclosed = true;
          }
        } while (escape);
        token.value = value.slice(pos + 1, next);
        token.sourceEndIndex = token.unclosed ? next : next + 1;
        tokens.push(token);
        pos = next + 1;
        code = value.charCodeAt(pos);

        // Comments
      } else if (code === slash && value.charCodeAt(pos + 1) === star) {
        next = value.indexOf("*/", pos);
        token = {
          type: "comment",
          sourceIndex: pos,
          sourceEndIndex: next + 2
        };
        if (next === -1) {
          token.unclosed = true;
          next = value.length;
          token.sourceEndIndex = next;
        }
        token.value = value.slice(pos + 2, next);
        tokens.push(token);
        pos = next + 2;
        code = value.charCodeAt(pos);

        // Operation within calc
      } else if ((code === slash || code === star) && parent && parent.type === "function" && parent.value === "calc") {
        token = value[pos];
        tokens.push({
          type: "word",
          sourceIndex: pos - before.length,
          sourceEndIndex: pos + token.length,
          value: token
        });
        pos += 1;
        code = value.charCodeAt(pos);

        // Dividers
      } else if (code === slash || code === comma || code === colon) {
        token = value[pos];
        tokens.push({
          type: "div",
          sourceIndex: pos - before.length,
          sourceEndIndex: pos + token.length,
          value: token,
          before: before,
          after: ""
        });
        before = "";
        pos += 1;
        code = value.charCodeAt(pos);

        // Open parentheses
      } else if (openParentheses === code) {
        // Whitespaces after open parentheses
        next = pos;
        do {
          next += 1;
          code = value.charCodeAt(next);
        } while (code <= 32);
        parenthesesOpenPos = pos;
        token = {
          type: "function",
          sourceIndex: pos - name.length,
          value: name,
          before: value.slice(parenthesesOpenPos + 1, next)
        };
        pos = next;
        if (name === "url" && code !== singleQuote && code !== doubleQuote) {
          next -= 1;
          do {
            escape = false;
            next = value.indexOf(")", next + 1);
            if (~next) {
              escapePos = next;
              while (value.charCodeAt(escapePos - 1) === backslash) {
                escapePos -= 1;
                escape = !escape;
              }
            } else {
              value += ")";
              next = value.length - 1;
              token.unclosed = true;
            }
          } while (escape);
          // Whitespaces before closed
          whitespacePos = next;
          do {
            whitespacePos -= 1;
            code = value.charCodeAt(whitespacePos);
          } while (code <= 32);
          if (parenthesesOpenPos < whitespacePos) {
            if (pos !== whitespacePos + 1) {
              token.nodes = [{
                type: "word",
                sourceIndex: pos,
                sourceEndIndex: whitespacePos + 1,
                value: value.slice(pos, whitespacePos + 1)
              }];
            } else {
              token.nodes = [];
            }
            if (token.unclosed && whitespacePos + 1 !== next) {
              token.after = "";
              token.nodes.push({
                type: "space",
                sourceIndex: whitespacePos + 1,
                sourceEndIndex: next,
                value: value.slice(whitespacePos + 1, next)
              });
            } else {
              token.after = value.slice(whitespacePos + 1, next);
              token.sourceEndIndex = next;
            }
          } else {
            token.after = "";
            token.nodes = [];
          }
          pos = next + 1;
          token.sourceEndIndex = token.unclosed ? next : pos;
          code = value.charCodeAt(pos);
          tokens.push(token);
        } else {
          balanced += 1;
          token.after = "";
          token.sourceEndIndex = pos + 1;
          tokens.push(token);
          stack.push(token);
          tokens = token.nodes = [];
          parent = token;
        }
        name = "";

        // Close parentheses
      } else if (closeParentheses === code && balanced) {
        pos += 1;
        code = value.charCodeAt(pos);
        parent.after = after;
        parent.sourceEndIndex += after.length;
        after = "";
        balanced -= 1;
        stack[stack.length - 1].sourceEndIndex = pos;
        stack.pop();
        parent = stack[balanced];
        tokens = parent.nodes;

        // Words
      } else {
        next = pos;
        do {
          if (code === backslash) {
            next += 1;
          }
          next += 1;
          code = value.charCodeAt(next);
        } while (next < max && !(code <= 32 || code === singleQuote || code === doubleQuote || code === comma || code === colon || code === slash || code === openParentheses || code === star && parent && parent.type === "function" && parent.value === "calc" || code === slash && parent.type === "function" && parent.value === "calc" || code === closeParentheses && balanced));
        token = value.slice(pos, next);
        if (openParentheses === code) {
          name = token;
        } else if ((uLower === token.charCodeAt(0) || uUpper === token.charCodeAt(0)) && plus === token.charCodeAt(1) && isUnicodeRange.test(token.slice(2))) {
          tokens.push({
            type: "unicode-range",
            sourceIndex: pos,
            sourceEndIndex: next,
            value: token
          });
        } else {
          tokens.push({
            type: "word",
            sourceIndex: pos,
            sourceEndIndex: next,
            value: token
          });
        }
        pos = next;
      }
    }
    for (pos = stack.length - 1; pos; pos -= 1) {
      stack[pos].unclosed = true;
      stack[pos].sourceEndIndex = value.length;
    }
    return stack[0].nodes;
  };
},119,[],"node_modules/postcss-value-parser/lib/parse.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  module.exports = function walk(nodes, cb, bubble) {
    var i, max, node, result;
    for (i = 0, max = nodes.length; i < max; i += 1) {
      node = nodes[i];
      if (!bubble) {
        result = cb(node, i, nodes);
      }
      if (result !== false && node.type === "function" && Array.isArray(node.nodes)) {
        walk(node.nodes, cb, bubble);
      }
      if (bubble) {
        cb(node, i, nodes);
      }
    }
  };
},120,[],"node_modules/postcss-value-parser/lib/walk.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  function stringifyNode(node, custom) {
    var type = node.type;
    var value = node.value;
    var buf;
    var customResult;
    if (custom && (customResult = custom(node)) !== undefined) {
      return customResult;
    } else if (type === "word" || type === "space") {
      return value;
    } else if (type === "string") {
      buf = node.quote || "";
      return buf + value + (node.unclosed ? "" : buf);
    } else if (type === "comment") {
      return "/*" + value + (node.unclosed ? "" : "*/");
    } else if (type === "div") {
      return (node.before || "") + value + (node.after || "");
    } else if (Array.isArray(node.nodes)) {
      buf = stringify(node.nodes, custom);
      if (type !== "function") {
        return buf;
      }
      return value + "(" + (node.before || "") + buf + (node.after || "") + (node.unclosed ? "" : ")");
    }
    return value;
  }
  function stringify(nodes, custom) {
    var result, i;
    if (Array.isArray(nodes)) {
      result = "";
      for (i = nodes.length - 1; ~i; i -= 1) {
        result = stringifyNode(nodes[i], custom) + result;
      }
      return result;
    }
    return stringifyNode(nodes, custom);
  }
  module.exports = stringify;
},121,[],"node_modules/postcss-value-parser/lib/stringify.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  var minus = "-".charCodeAt(0);
  var plus = "+".charCodeAt(0);
  var dot = ".".charCodeAt(0);
  var exp = "e".charCodeAt(0);
  var EXP = "E".charCodeAt(0);

  // Check if three code points would start a number
  // https://www.w3.org/TR/css-syntax-3/#starts-with-a-number
  function likeNumber(value) {
    var code = value.charCodeAt(0);
    var nextCode;
    if (code === plus || code === minus) {
      nextCode = value.charCodeAt(1);
      if (nextCode >= 48 && nextCode <= 57) {
        return true;
      }
      var nextNextCode = value.charCodeAt(2);
      if (nextCode === dot && nextNextCode >= 48 && nextNextCode <= 57) {
        return true;
      }
      return false;
    }
    if (code === dot) {
      nextCode = value.charCodeAt(1);
      if (nextCode >= 48 && nextCode <= 57) {
        return true;
      }
      return false;
    }
    if (code >= 48 && code <= 57) {
      return true;
    }
    return false;
  }

  // Consume a number
  // https://www.w3.org/TR/css-syntax-3/#consume-number
  module.exports = function (value) {
    var pos = 0;
    var length = value.length;
    var code;
    var nextCode;
    var nextNextCode;
    if (length === 0 || !likeNumber(value)) {
      return false;
    }
    code = value.charCodeAt(pos);
    if (code === plus || code === minus) {
      pos++;
    }
    while (pos < length) {
      code = value.charCodeAt(pos);
      if (code < 48 || code > 57) {
        break;
      }
      pos += 1;
    }
    code = value.charCodeAt(pos);
    nextCode = value.charCodeAt(pos + 1);
    if (code === dot && nextCode >= 48 && nextCode <= 57) {
      pos += 2;
      while (pos < length) {
        code = value.charCodeAt(pos);
        if (code < 48 || code > 57) {
          break;
        }
        pos += 1;
      }
    }
    code = value.charCodeAt(pos);
    nextCode = value.charCodeAt(pos + 1);
    nextNextCode = value.charCodeAt(pos + 2);
    if ((code === exp || code === EXP) && (nextCode >= 48 && nextCode <= 57 || (nextCode === plus || nextCode === minus) && nextNextCode >= 48 && nextNextCode <= 57)) {
      pos += nextCode === plus || nextCode === minus ? 3 : 2;
      while (pos < length) {
        code = value.charCodeAt(pos);
        if (code < 48 || code > 57) {
          break;
        }
        pos += 1;
      }
    }
    return {
      number: value.slice(0, pos),
      unit: value.slice(pos)
    };
  };
},122,[],"node_modules/postcss-value-parser/lib/unit.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var Platform = {
    OS: 'web',
    select: obj => 'web' in obj ? obj.web : obj.default,
    get isTesting() {
      if (process.env.NODE_ENV === 'test') {
        return true;
      }
      return false;
    },
    get Version() {
      return '0.0.0';
    }
  };
  var _default = Platform;
},123,[],"node_modules/react-native-web/dist/exports/Platform/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _vendorReactNativeEventEmitterNativeEventEmitter = require(_dependencyMap[0], "../../vendor/react-native/EventEmitter/NativeEventEmitter");
  var NativeEventEmitter = _interopDefault(_vendorReactNativeEventEmitterNativeEventEmitter);
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var _default = NativeEventEmitter.default;
},126,[127],"node_modules/react-native-web/dist/exports/NativeEventEmitter/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   * @format
   */

  'use strict';

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return NativeEventEmitter;
    }
  });
  var _exportsPlatform = require(_dependencyMap[0], "../../../exports/Platform");
  var Platform = _interopDefault(_exportsPlatform);
  var _RCTDeviceEventEmitter = require(_dependencyMap[1], "./RCTDeviceEventEmitter");
  var RCTDeviceEventEmitter = _interopDefault(_RCTDeviceEventEmitter);
  var _fbjsLibInvariant = require(_dependencyMap[2], "fbjs/lib/invariant");
  var invariant = _interopDefault(_fbjsLibInvariant);
  /**
   * `NativeEventEmitter` is intended for use by Native Modules to emit events to
   * JavaScript listeners. If a `NativeModule` is supplied to the constructor, it
   * will be notified (via `addListener` and `removeListeners`) when the listener
   * count changes to manage "native memory".
   *
   * Currently, all native events are fired via a global `RCTDeviceEventEmitter`.
   * This means event names must be globally unique, and it means that call sites
   * can theoretically listen to `RCTDeviceEventEmitter` (although discouraged).
   */
  class NativeEventEmitter {
    constructor(nativeModule) {
      if (Platform.default.OS === 'ios') {
        (0, invariant.default)(nativeModule != null, '`new NativeEventEmitter()` requires a non-null argument.');
        this._nativeModule = nativeModule;
      }
    }
    addListener(eventType, listener, context) {
      var _this$_nativeModule;
      (_this$_nativeModule = this._nativeModule) == null ? void 0 : _this$_nativeModule.addListener(eventType);
      var subscription = RCTDeviceEventEmitter.default.addListener(eventType, listener, context);
      return {
        remove: () => {
          if (subscription != null) {
            var _this$_nativeModule2;
            (_this$_nativeModule2 = this._nativeModule) == null ? void 0 : _this$_nativeModule2.removeListeners(1);
            // $FlowFixMe[incompatible-use]
            subscription.remove();
            subscription = null;
          }
        }
      };
    }

    /**
     * @deprecated Use `remove` on the EventSubscription from `addListener`.
     */
    removeListener(eventType, listener) {
      var _this$_nativeModule3;
      (_this$_nativeModule3 = this._nativeModule) == null ? void 0 : _this$_nativeModule3.removeListeners(1);
      // NOTE: This will report a deprecation notice via `console.error`.
      // $FlowFixMe[prop-missing] - `removeListener` exists but is deprecated.
      RCTDeviceEventEmitter.default.removeListener(eventType, listener);
    }
    emit(eventType) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      // Generally, `RCTDeviceEventEmitter` is directly invoked. But this is
      // included for completeness.
      RCTDeviceEventEmitter.default.emit(eventType, ...args);
    }
    removeAllListeners(eventType) {
      var _this$_nativeModule4;
      (0, invariant.default)(eventType != null, '`NativeEventEmitter.removeAllListener()` requires a non-null argument.');
      (_this$_nativeModule4 = this._nativeModule) == null ? void 0 : _this$_nativeModule4.removeListeners(this.listenerCount(eventType));
      RCTDeviceEventEmitter.default.removeAllListeners(eventType);
    }
    listenerCount(eventType) {
      return RCTDeviceEventEmitter.default.listenerCount(eventType);
    }
  }
},127,[123,29,52],"node_modules/react-native-web/dist/vendor/react-native/EventEmitter/NativeEventEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "EventEmitter", {
    enumerable: true,
    get: function () {
      return _EventEmitter.EventEmitter;
    }
  });
  Object.defineProperty(exports, "NativeModule", {
    enumerable: true,
    get: function () {
      return _NativeModule.NativeModule;
    }
  });
  Object.defineProperty(exports, "SharedObject", {
    enumerable: true,
    get: function () {
      return _SharedObject.SharedObject;
    }
  });
  Object.defineProperty(exports, "SharedRef", {
    enumerable: true,
    get: function () {
      return _SharedRef.SharedRef;
    }
  });
  Object.defineProperty(exports, "Platform", {
    enumerable: true,
    get: function () {
      return _Platform2.default;
    }
  });
  Object.defineProperty(exports, "uuid", {
    enumerable: true,
    get: function () {
      return _uuid2.default;
    }
  });
  Object.defineProperty(exports, "requireNativeViewManager", {
    enumerable: true,
    get: function () {
      return _NativeViewManagerAdapter.requireNativeViewManager;
    }
  });
  Object.defineProperty(exports, "CodedError", {
    enumerable: true,
    get: function () {
      return _errorsCodedError.CodedError;
    }
  });
  Object.defineProperty(exports, "UnavailabilityError", {
    enumerable: true,
    get: function () {
      return _errorsUnavailabilityError.UnavailabilityError;
    }
  });
  Object.defineProperty(exports, "LegacyEventEmitter", {
    enumerable: true,
    get: function () {
      return _LegacyEventEmitter.LegacyEventEmitter;
    }
  });
  Object.defineProperty(exports, "NativeModulesProxy", {
    enumerable: true,
    get: function () {
      return _NativeModulesProxy2.default;
    }
  });
  require(_dependencyMap[0], "./sweet/setUpJsLogger.fx");
  require(_dependencyMap[1], "./polyfill");
  var _EventEmitter = require(_dependencyMap[2], "./EventEmitter");
  var _NativeModule = require(_dependencyMap[3], "./NativeModule");
  var _SharedObject = require(_dependencyMap[4], "./SharedObject");
  var _SharedRef = require(_dependencyMap[5], "./SharedRef");
  var _Platform = require(_dependencyMap[6], "./Platform");
  var _Platform2 = _interopDefault(_Platform);
  var _uuid = require(_dependencyMap[7], "./uuid");
  var _uuid2 = _interopDefault(_uuid);
  var _NativeViewManagerAdapter = require(_dependencyMap[8], "./NativeViewManagerAdapter");
  var _requireNativeModule = require(_dependencyMap[9], "./requireNativeModule");
  Object.keys(_requireNativeModule).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _requireNativeModule[k];
        }
      });
    }
  });
  var _registerWebModule = require(_dependencyMap[10], "./registerWebModule");
  Object.keys(_registerWebModule).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _registerWebModule[k];
        }
      });
    }
  });
  var _TypedArraysTypes = require(_dependencyMap[11], "./TypedArrays.types");
  Object.keys(_TypedArraysTypes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _TypedArraysTypes[k];
        }
      });
    }
  });
  var _PermissionsInterface = require(_dependencyMap[12], "./PermissionsInterface");
  Object.keys(_PermissionsInterface).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _PermissionsInterface[k];
        }
      });
    }
  });
  var _PermissionsHook = require(_dependencyMap[13], "./PermissionsHook");
  Object.keys(_PermissionsHook).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _PermissionsHook[k];
        }
      });
    }
  });
  var _Refs = require(_dependencyMap[14], "./Refs");
  Object.keys(_Refs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _Refs[k];
        }
      });
    }
  });
  var _hooksUseReleasingSharedObject = require(_dependencyMap[15], "./hooks/useReleasingSharedObject");
  Object.keys(_hooksUseReleasingSharedObject).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _hooksUseReleasingSharedObject[k];
        }
      });
    }
  });
  var _reload = require(_dependencyMap[16], "./reload");
  Object.keys(_reload).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _reload[k];
        }
      });
    }
  });
  var _errorsCodedError = require(_dependencyMap[17], "./errors/CodedError");
  var _errorsUnavailabilityError = require(_dependencyMap[18], "./errors/UnavailabilityError");
  var _LegacyEventEmitter = require(_dependencyMap[19], "./LegacyEventEmitter");
  var _NativeModulesProxy = require(_dependencyMap[20], "./NativeModulesProxy");
  var _NativeModulesProxy2 = _interopDefault(_NativeModulesProxy);
},131,[132,133,146,148,149,150,151,136,153,156,157,158,159,160,161,162,163,155,154,164,166],"node_modules/expo-modules-core/src/index.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {},132,[],"node_modules/expo-modules-core/src/sweet/setUpJsLogger.fx.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var _dangerousInternal = require(_dependencyMap[0], "./dangerous-internal");
  (0, _dangerousInternal.installExpoGlobalPolyfill)();
},133,[134],"node_modules/expo-modules-core/src/polyfill/index.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.installExpoGlobalPolyfill = installExpoGlobalPolyfill;
  var _CoreModule = require(_dependencyMap[0], "./CoreModule");
  var _uuidIndexWeb = require(_dependencyMap[1], "../uuid/index.web");
  var uuid = _interopDefault(_uuidIndexWeb);
  var _tsDeclarationsGlobal = require(_dependencyMap[2], "../ts-declarations/global");
  Object.keys(_tsDeclarationsGlobal).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _tsDeclarationsGlobal[k];
        }
      });
    }
  });
  // jest-expo imports to this file directly without going through the global types
  // Exporting the types to let jest-expo to know the globalThis types

  function installExpoGlobalPolyfill() {
    if (globalThis.expo) return;
    globalThis.expo = {
      EventEmitter: _CoreModule.EventEmitter,
      NativeModule: _CoreModule.NativeModule,
      SharedObject: _CoreModule.SharedObject,
      SharedRef: _CoreModule.SharedRef,
      modules: globalThis.ExpoDomWebView?.expoModulesProxy ?? {},
      uuidv4: uuid.default.v4,
      uuidv5: uuid.default.v5,
      getViewConfig: () => {
        throw new Error('Method not implemented.');
      },
      reloadAppAsync: async () => {
        window.location.reload();
      },
      expoModulesCoreVersion: undefined,
      cacheDir: undefined,
      documentsDir: undefined
    };
  }
},134,[135,136,141],"node_modules/expo-modules-core/src/polyfill/dangerous-internal.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "EventEmitter", {
    enumerable: true,
    get: function () {
      return EventEmitter;
    }
  });
  Object.defineProperty(exports, "NativeModule", {
    enumerable: true,
    get: function () {
      return NativeModule;
    }
  });
  Object.defineProperty(exports, "SharedObject", {
    enumerable: true,
    get: function () {
      return SharedObject;
    }
  });
  Object.defineProperty(exports, "SharedRef", {
    enumerable: true,
    get: function () {
      return SharedRef;
    }
  });
  class EventEmitter {
    addListener(eventName, listener) {
      if (!this.listeners) {
        this.listeners = new Map();
      }
      if (!this.listeners?.has(eventName)) {
        this.listeners?.set(eventName, new Set());
      }
      const previousListenerCount = this.listenerCount(eventName);
      this.listeners?.get(eventName)?.add(listener);
      if (previousListenerCount === 0 && this.listenerCount(eventName) === 1) {
        this.startObserving(eventName);
      }
      return {
        remove: () => {
          this.removeListener(eventName, listener);
        }
      };
    }
    removeListener(eventName, listener) {
      const hasRemovedListener = this.listeners?.get(eventName)?.delete(listener);
      if (this.listenerCount(eventName) === 0 && hasRemovedListener) {
        this.stopObserving(eventName);
      }
    }
    removeAllListeners(eventName) {
      const previousListenerCount = this.listenerCount(eventName);
      this.listeners?.get(eventName)?.clear();
      if (previousListenerCount > 0) {
        this.stopObserving(eventName);
      }
    }
    emit(eventName, ...args) {
      const listeners = new Set(this.listeners?.get(eventName));
      listeners.forEach(listener => {
        // When the listener throws an error, don't stop the execution of subsequent listeners and
        // don't propagate the error to the `emit` function. The motivation behind this is that
        // errors thrown from a module or user's code shouldn't affect other modules' behavior.
        try {
          listener(...args);
        } catch (error) {
          console.error(error);
        }
      });
    }
    listenerCount(eventName) {
      return this.listeners?.get(eventName)?.size ?? 0;
    }
    startObserving(eventName) {}
    stopObserving(eventName) {}
  }
  class NativeModule extends EventEmitter {}
  class SharedObject extends EventEmitter {
    release() {
      // no-op on Web, but subclasses can override it if needed.
    }
  }
  class SharedRef extends SharedObject {
    nativeRefType = 'unknown';
  }
},135,[],"node_modules/expo-modules-core/src/polyfill/CoreModule.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _libSha = require(_dependencyMap[0], "./lib/sha1");
  var sha1 = _interopDefault(_libSha);
  var _libV = require(_dependencyMap[1], "./lib/v35");
  var v35 = _interopDefault(_libV);
  var _uuidTypes = require(_dependencyMap[2], "./uuid.types");
  function uuidv4() {
    if (
    // We use this code path in jest-expo.
    process.env.NODE_ENV === 'test' ||
    // Node.js has supported global crypto since v15.
    typeof crypto === 'undefined' &&
    // Only use abstract imports in server environments.
    typeof window === 'undefined') {
      // NOTE: Metro statically extracts all `require` statements to resolve them for environments
      // that don't support `require` natively. Here we check if we're running in a server environment
      // by using the standard `typeof window` check, then running `eval` to skip Metro's static
      // analysis and keep the `require` statement intact for runtime evaluation.
      // eslint-disable-next-line no-eval
      return eval('require')('node:crypto').randomUUID();
    }
    return crypto.randomUUID();
  }
  const uuid = {
    v4: uuidv4,
    v5: (0, v35.default)('v5', 0x50, sha1.default),
    namespace: _uuidTypes.Uuidv5Namespace
  };
  var _default = uuid;
},136,[137,138,140],"node_modules/expo-modules-core/src/uuid/index.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  // Adapted from Chris Veness' SHA1 code at
  // http://www.movable-type.co.uk/scripts/sha1.html
  'use strict';

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  function f(s, x, y, z) {
    switch (s) {
      case 0:
        return x & y ^ ~x & z;
      case 1:
        return x ^ y ^ z;
      case 2:
        return x & y ^ x & z ^ y & z;
      case 3:
        return x ^ y ^ z;
      default:
        return 0;
    }
  }
  function ROTL(x, n) {
    return x << n | x >>> 32 - n;
  }
  function sha1(bytes) {
    const K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
    const H = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];
    if (typeof bytes == 'string') {
      const msg = unescape(encodeURIComponent(bytes)); // UTF8 escape
      bytes = new Array(msg.length);
      for (let i = 0; i < msg.length; i++) bytes[i] = msg.charCodeAt(i);
    }
    bytes.push(0x80);
    const l = bytes.length / 4 + 2;
    const N = Math.ceil(l / 16);
    const M = new Array(N);
    for (let i = 0; i < N; i++) {
      M[i] = new Array(16);
      for (let j = 0; j < 16; j++) {
        M[i][j] = bytes[i * 64 + j * 4] << 24 | bytes[i * 64 + j * 4 + 1] << 16 | bytes[i * 64 + j * 4 + 2] << 8 | bytes[i * 64 + j * 4 + 3];
      }
    }
    M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
    M[N - 1][14] = Math.floor(M[N - 1][14]);
    M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;
    for (let i = 0; i < N; i++) {
      const W = new Array(80);
      for (let t = 0; t < 16; t++) W[t] = M[i][t];
      for (let t = 16; t < 80; t++) {
        W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
      }
      let a = H[0];
      let b = H[1];
      let c = H[2];
      let d = H[3];
      let e = H[4];
      for (let t = 0; t < 80; t++) {
        const s = Math.floor(t / 20);
        const T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t] >>> 0;
        e = d;
        d = c;
        c = ROTL(b, 30) >>> 0;
        b = a;
        a = T;
      }
      H[0] = H[0] + a >>> 0;
      H[1] = H[1] + b >>> 0;
      H[2] = H[2] + c >>> 0;
      H[3] = H[3] + d >>> 0;
      H[4] = H[4] + e >>> 0;
    }
    return [H[0] >> 24 & 0xff, H[0] >> 16 & 0xff, H[0] >> 8 & 0xff, H[0] & 0xff, H[1] >> 24 & 0xff, H[1] >> 16 & 0xff, H[1] >> 8 & 0xff, H[1] & 0xff, H[2] >> 24 & 0xff, H[2] >> 16 & 0xff, H[2] >> 8 & 0xff, H[2] & 0xff, H[3] >> 24 & 0xff, H[3] >> 16 & 0xff, H[3] >> 8 & 0xff, H[3] & 0xff, H[4] >> 24 & 0xff, H[4] >> 16 & 0xff, H[4] >> 8 & 0xff, H[4] & 0xff];
  }
  var _default = sha1;
},137,[],"node_modules/expo-modules-core/src/uuid/lib/sha1.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _ref;
    }
  });
  var _bytesToUuid = require(_dependencyMap[0], "./bytesToUuid");
  var bytesToUuid = _interopDefault(_bytesToUuid);
  function uuidToBytes(uuid) {
    // Note: We assume we're being passed a valid uuid string
    const bytes = [];
    uuid.replace(/[a-fA-F0-9]{2}/g, hex => {
      bytes.push(parseInt(hex, 16));
      return '';
    });
    return bytes;
  }
  function stringToBytes(str) {
    str = unescape(encodeURIComponent(str)); // UTF8 escape
    const bytes = new Array(str.length);
    for (let i = 0; i < str.length; i++) {
      bytes[i] = str.charCodeAt(i);
    }
    return bytes;
  }
  function _ref(name, version, hashfunc) {
    const generateUUID = function (value, namespace, buf, offset) {
      const off = buf && offset || 0;
      if (typeof value == 'string') value = stringToBytes(value);
      if (typeof namespace == 'string') namespace = uuidToBytes(namespace);
      if (!Array.isArray(value)) throw TypeError('value must be an array of bytes');
      if (!Array.isArray(namespace) || namespace.length !== 16) throw TypeError('namespace must be uuid string or an Array of 16 byte values');

      // Per 4.3
      const bytes = hashfunc(namespace.concat(value));
      bytes[6] = bytes[6] & 0x0f | version;
      bytes[8] = bytes[8] & 0x3f | 0x80;
      if (buf) {
        for (let idx = 0; idx < 16; ++idx) {
          buf[off + idx] = bytes[idx];
        }
      }
      return (0, bytesToUuid.default)(bytes);
    };

    // Function#name is not settable on some platforms (#270)
    try {
      generateUUID.name = name;
    } catch {}

    // Pre-defined namespaces, per Appendix C
    generateUUID.DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
    generateUUID.URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
    return generateUUID;
  }
},138,[139],"node_modules/expo-modules-core/src/uuid/lib/v35.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Convert array of 16 byte values to UUID string format of the form:
   * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
   */
  const byteToHex = [];
  for (let i = 0; i < 256; ++i) {
    byteToHex[i] = (i + 0x100).toString(16).substr(1);
  }
  function bytesToUuid(buf, offset) {
    let i = offset || 0;
    const bth = byteToHex;
    // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4
    return [bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]]].join('');
  }
  var _default = bytesToUuid;
},139,[],"node_modules/expo-modules-core/src/uuid/lib/bytesToUuid.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "Uuidv5Namespace", {
    enumerable: true,
    get: function () {
      return Uuidv5Namespace;
    }
  });
  /**
   * Collection of utilities used for generating Universally Unique Identifiers.
   */
  /**
   * Default namespaces for UUID v5 defined in RFC 4122
   */
  let Uuidv5Namespace = /*#__PURE__*/function (Uuidv5Namespace) {
    // Source of the UUIDs: https://datatracker.ietf.org/doc/html/rfc4122
    Uuidv5Namespace["dns"] = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
    Uuidv5Namespace["url"] = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
    Uuidv5Namespace["oid"] = "6ba7b812-9dad-11d1-80b4-00c04fd430c8";
    Uuidv5Namespace["x500"] = "6ba7b814-9dad-11d1-80b4-00c04fd430c8";
    return Uuidv5Namespace;
  }({});
},140,[],"node_modules/expo-modules-core/src/uuid/uuid.types.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  require(_dependencyMap[0], "./EventEmitter");
  require(_dependencyMap[1], "./NativeModule");
  require(_dependencyMap[2], "./SharedObject");
  require(_dependencyMap[3], "./SharedRef");
},141,[142,143,144,145],"node_modules/expo-modules-core/src/ts-declarations/global.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},142,[],"node_modules/expo-modules-core/src/ts-declarations/EventEmitter.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},143,[],"node_modules/expo-modules-core/src/ts-declarations/NativeModule.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},144,[],"node_modules/expo-modules-core/src/ts-declarations/SharedObject.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},145,[],"node_modules/expo-modules-core/src/ts-declarations/SharedRef.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "EventEmitter", {
    enumerable: true,
    get: function () {
      return EventEmitter;
    }
  });
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();

  /**
   * A subscription object that allows to conveniently remove an event listener from the emitter.
   */

  const EventEmitter = globalThis.expo.EventEmitter;
},146,[147],"node_modules/expo-modules-core/src/EventEmitter.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.ensureNativeModulesAreInstalled = ensureNativeModulesAreInstalled;
  require(_dependencyMap[0], "./polyfill");
  // Installs the expo global on web

  /**
   * Ensures that the native modules are installed in the current runtime.
   * Otherwise, it synchronously calls a native function that installs them.
   */
  function ensureNativeModulesAreInstalled() {
    // No-op on web
  }
},147,[133],"node_modules/expo-modules-core/src/ensureNativeModulesAreInstalled.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "NativeModule", {
    enumerable: true,
    get: function () {
      return NativeModule;
    }
  });
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();
  const NativeModule = globalThis.expo.NativeModule;
},148,[147],"node_modules/expo-modules-core/src/NativeModule.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "SharedObject", {
    enumerable: true,
    get: function () {
      return SharedObject;
    }
  });
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();
  const SharedObject = globalThis.expo.SharedObject;
},149,[147],"node_modules/expo-modules-core/src/SharedObject.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "SharedRef", {
    enumerable: true,
    get: function () {
      return SharedRef;
    }
  });
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();
  const SharedRef = globalThis.expo.SharedRef;
},150,[147],"node_modules/expo-modules-core/src/SharedRef.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactNativeWebDistExportsPlatform = require(_dependencyMap[0], "react-native-web/dist/exports/Platform");
  var ReactNativePlatform = _interopDefault(_reactNativeWebDistExportsPlatform);
  var _environmentBrowser = require(_dependencyMap[1], "./environment/browser");
  if (__DEV__ && typeof "web" === 'undefined') {
    console.warn(`The global process.env.EXPO_OS is not defined. This should be inlined by babel-preset-expo during transformation.`);
  }
  const nativeSelect = typeof window !== 'undefined' ? ReactNativePlatform.default.select :
  // process.env.EXPO_OS is injected by `babel-preset-expo` and available in both client and `react-server` environments.
  // Opt to use the env var when possible, and fallback to the React Native Platform module when it's not (arbitrary bundlers and transformers).
  function select(specifics) {
    if (!"web") return undefined;
    if (specifics.hasOwnProperty("web")) {
      return specifics["web"];
    } else if (false && specifics.hasOwnProperty('native')) {
      return specifics.native;
    } else if (specifics.hasOwnProperty('default')) {
      return specifics.default;
    }
    // do nothing...
    return undefined;
  };
  const Platform = {
    /**
     * Denotes the currently running platform.
     * Can be one of ios, android, web.
     */
    OS: "web" || ReactNativePlatform.default.OS,
    /**
     * Returns the value with the matching platform.
     * Object keys can be any of ios, android, native, web, default.
     *
     * @ios ios, native, default
     * @android android, native, default
     * @web web, default
     */
    select: nativeSelect,
    /**
     * Denotes if the DOM API is available in the current environment.
     * The DOM is not available in native React runtimes and Node.js.
     */
    isDOMAvailable: _environmentBrowser.isDOMAvailable,
    /**
     * Denotes if the current environment can attach event listeners
     * to the window. This will return false in native React
     * runtimes and Node.js.
     */
    canUseEventListeners: _environmentBrowser.canUseEventListeners,
    /**
     * Denotes if the current environment can inspect properties of the
     * screen on which the current window is being rendered. This will
     * return false in native React runtimes and Node.js.
     */
    canUseViewport: _environmentBrowser.canUseViewport,
    /**
     * If the JavaScript is being executed in a remote JavaScript environment.
     * When `true`, synchronous native invocations cannot be executed.
     */
    isAsyncDebugging: _environmentBrowser.isAsyncDebugging
  };
  var _default = Platform;
},151,[123,152],"node_modules/expo-modules-core/src/Platform.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "isDOMAvailable", {
    enumerable: true,
    get: function () {
      return isDOMAvailable;
    }
  });
  Object.defineProperty(exports, "canUseEventListeners", {
    enumerable: true,
    get: function () {
      return canUseEventListeners;
    }
  });
  Object.defineProperty(exports, "canUseViewport", {
    enumerable: true,
    get: function () {
      return canUseViewport;
    }
  });
  Object.defineProperty(exports, "isAsyncDebugging", {
    enumerable: true,
    get: function () {
      return isAsyncDebugging;
    }
  });
  // Used for delegating node actions when browser APIs aren't available
  // like in SSR websites.
  const isDOMAvailable = typeof window !== 'undefined' && !!window.document?.createElement;
  const canUseEventListeners = isDOMAvailable && !!(window.addEventListener || window.attachEvent);
  const canUseViewport = isDOMAvailable && !!window.screen;
  const isAsyncDebugging = false;
},152,[],"node_modules/expo-modules-core/src/environment/browser.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.requireNativeViewManager = requireNativeViewManager;
  var _errorsUnavailabilityError = require(_dependencyMap[0], "./errors/UnavailabilityError");
  /**
   * A drop-in replacement for `requireNativeComponent`.
   */
  function requireNativeViewManager(moduleName, viewName) {
    throw new _errorsUnavailabilityError.UnavailabilityError('expo-modules-core', 'requireNativeViewManager');
  }
},153,[154],"node_modules/expo-modules-core/src/NativeViewManagerAdapter.tsx");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "UnavailabilityError", {
    enumerable: true,
    get: function () {
      return UnavailabilityError;
    }
  });
  var _CodedError = require(_dependencyMap[0], "./CodedError");
  var _Platform = require(_dependencyMap[1], "../Platform");
  var Platform = _interopDefault(_Platform);
  /**
   * A class for errors to be thrown when a property is accessed which is
   * unavailable, unsupported, or not currently implemented on the running
   * platform.
   */
  class UnavailabilityError extends _CodedError.CodedError {
    constructor(moduleName, propertyName) {
      super('ERR_UNAVAILABLE', `The method or property ${moduleName}.${propertyName} is not available on ${Platform.default.OS}, are you sure you've linked all the native dependencies properly?`);
    }
  }
},154,[155,151],"node_modules/expo-modules-core/src/errors/UnavailabilityError.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "CodedError", {
    enumerable: true,
    get: function () {
      return CodedError;
    }
  });
  /**
   * A general error class that should be used for all errors in Expo modules.
   * Guarantees a `code` field that can be used to differentiate between different
   * types of errors without further subclassing Error.
   */
  class CodedError extends Error {
    constructor(code, message) {
      super(message);
      this.code = code;
    }
  }
},155,[],"node_modules/expo-modules-core/src/errors/CodedError.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.requireNativeModule = requireNativeModule;
  exports.requireOptionalNativeModule = requireOptionalNativeModule;
  function requireNativeModule(moduleName) {
    const nativeModule = requireOptionalNativeModule(moduleName);
    if (nativeModule != null) {
      return nativeModule;
    }
    if (typeof window === 'undefined') {
      // For SSR, we expect not to have native modules available, but to avoid crashing from SSR resolutions, we return an empty object.
      return {};
    }
    throw new Error(`Cannot find native module '${moduleName}'`);
  }
  function requireOptionalNativeModule(moduleName) {
    if (typeof globalThis.ExpoDomWebView === 'object' && globalThis?.expo?.modules != null) {
      return globalThis.expo?.modules?.[moduleName] ?? null;
    }
    return null;
  }
},156,[],"node_modules/expo-modules-core/src/requireNativeModule.web.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.registerWebModule = registerWebModule;
  var _ensureNativeModulesAreInstalled = require(_dependencyMap[0], "./ensureNativeModulesAreInstalled");
  /**
   * Registers a web module.
   * @param moduleImplementation A class that extends `NativeModule`. The class is registered under `globalThis.expo.modules[className]`.
   * @param moduleName – a name to register the module under `globalThis.expo.modules[className]`.
   * @returns A singleton instance of the class passed into arguments.
   */

  function registerWebModule(moduleImplementation, moduleName) {
    (0, _ensureNativeModulesAreInstalled.ensureNativeModulesAreInstalled)();
    moduleName = moduleName ?? moduleImplementation.name;
    if (!moduleName) {
      throw new Error('Web module implementation is missing a name - it is either not a class or has been minified. Pass the name as a second argument to the `registerWebModule` function.');
    }
    if (!globalThis?.expo?.modules) {
      globalThis.expo.modules = {};
    }
    if (globalThis.expo.modules[moduleName]) {
      return globalThis.expo.modules[moduleName];
    }
    globalThis.expo.modules[moduleName] = new moduleImplementation();
    return globalThis.expo.modules[moduleName];
  }
},157,[147],"node_modules/expo-modules-core/src/registerWebModule.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},158,[],"node_modules/expo-modules-core/src/TypedArrays.types.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "PermissionStatus", {
    enumerable: true,
    get: function () {
      return PermissionStatus;
    }
  });
  let PermissionStatus = /*#__PURE__*/function (PermissionStatus) {
    /**
     * User has granted the permission.
     */
    PermissionStatus["GRANTED"] = "granted";
    /**
     * User hasn't granted or denied the permission yet.
     */
    PermissionStatus["UNDETERMINED"] = "undetermined";
    /**
     * User has denied the permission.
     */
    PermissionStatus["DENIED"] = "denied";
    return PermissionStatus;
  }({});
  /**
   * Permission expiration time. Currently, all permissions are granted permanently.
   */
  /**
   * An object obtained by permissions get and request functions.
   */
},159,[],"node_modules/expo-modules-core/src/PermissionsInterface.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  // Copyright © 2024 650 Industries.

  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.createPermissionHook = createPermissionHook;
  var _react = require(_dependencyMap[0], "react");
  // These types are identical, but improves the readability for suggestions in editors

  /**
   * Get or request permission for protected functionality within the app.
   * It uses separate permission requesters to interact with a single permission.
   * By default, the hook will only retrieve the permission status.
   */
  function usePermission(methods, options) {
    const isMounted = (0, _react.useRef)(true);
    const [status, setStatus] = (0, _react.useState)(null);
    const {
      get = true,
      request = false,
      ...permissionOptions
    } = options || {};
    const getPermission = (0, _react.useCallback)(async () => {
      let response;
      if (Object.keys(permissionOptions).length > 0) {
        response = await methods.getMethod(permissionOptions);
      } else {
        response = await methods.getMethod();
      }
      if (isMounted.current) setStatus(response);
      return response;
    }, [methods.getMethod]);
    const requestPermission = (0, _react.useCallback)(async () => {
      let response;
      if (Object.keys(permissionOptions).length > 0) {
        response = await methods.requestMethod(permissionOptions);
      } else {
        response = await methods.requestMethod();
      }
      if (isMounted.current) setStatus(response);
      return response;
    }, [methods.requestMethod]);
    (0, _react.useEffect)(function runMethods() {
      if (request) requestPermission();
      if (!request && get) getPermission();
    }, [get, request, requestPermission, getPermission]);

    // Workaround for unmounting components receiving state updates
    (0, _react.useEffect)(function didMount() {
      isMounted.current = true;
      return () => {
        isMounted.current = false;
      };
    }, []);
    return [status, requestPermission, getPermission];
  }

  /**
   * Create a new permission hook with the permission methods built-in.
   * This can be used to quickly create specific permission hooks in every module.
   */
  function createPermissionHook(methods) {
    return options => usePermission(methods, options);
  }
},160,[62],"node_modules/expo-modules-core/src/PermissionsHook.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.createSnapshotFriendlyRef = createSnapshotFriendlyRef;
  var _react = require(_dependencyMap[0], "react");
  /**
   * Create a React ref object that is friendly for snapshots.
   * It will be represented as `[React.ref]` in snapshots.
   * @returns A React ref object.
   */
  function createSnapshotFriendlyRef() {
    return /*#__PURE__*/(0, _react.createRef)();
  }
},161,[62],"node_modules/expo-modules-core/src/Refs.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.useReleasingSharedObject = useReleasingSharedObject;
  var _react = require(_dependencyMap[0], "react");
  /**
   * Returns a shared object, which is automatically cleaned up when the component is unmounted.
   */
  function useReleasingSharedObject(factory, dependencies) {
    const objectRef = (0, _react.useRef)(null);
    const isFastRefresh = (0, _react.useRef)(false);
    const previousDependencies = (0, _react.useRef)(dependencies);
    if (objectRef.current == null) {
      objectRef.current = factory();
    }
    const object = (0, _react.useMemo)(() => {
      let newObject = objectRef.current;
      const dependenciesAreEqual = previousDependencies.current?.length === dependencies.length && dependencies.every((value, index) => value === previousDependencies.current[index]);

      // If the dependencies have changed, release the previous object and create a new one, otherwise this has been called
      // because of an unrelated fast refresh, and we don't want to release the object.
      if (!newObject || !dependenciesAreEqual) {
        objectRef.current?.release();
        newObject = factory();
        objectRef.current = newObject;
        previousDependencies.current = dependencies;
      }
      return newObject;
    }, dependencies);
    (0, _react.useMemo)(() => {
      isFastRefresh.current = true;
    }, []);
    (0, _react.useEffect)(() => {
      isFastRefresh.current = false;
      return () => {
        // This will be called on every fast refresh and on unmount, but we only want to release the object on unmount.
        if (!isFastRefresh.current && objectRef.current) {
          objectRef.current.release();
        }
      };
    }, []);
    return object;
  }
},162,[62],"node_modules/expo-modules-core/src/hooks/useReleasingSharedObject.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.reloadAppAsync = reloadAppAsync;
  /**
   * Reloads the app. This method works for both release and debug builds.
   *
   * Unlike [`Updates.reloadAsync()`](/versions/latest/sdk/updates/#updatesreloadasync),
   * this function does not use a new update even if one is available. It only reloads the app using the same JavaScript bundle that is currently running.
   *
   * @param reason The reason for reloading the app. This is used only for some platforms.
   */
  async function reloadAppAsync(reason = 'Reloaded from JS call') {
    await globalThis.expo?.reloadAppAsync(reason);
  }
},163,[],"node_modules/expo-modules-core/src/reload.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "LegacyEventEmitter", {
    enumerable: true,
    get: function () {
      return LegacyEventEmitter;
    }
  });
  var _invariant = require(_dependencyMap[0], "invariant");
  var invariant = _interopDefault(_invariant);
  var _reactNativeWebDistExportsNativeEventEmitter = require(_dependencyMap[1], "react-native-web/dist/exports/NativeEventEmitter");
  var NativeEventEmitter = _interopDefault(_reactNativeWebDistExportsNativeEventEmitter);
  var _reactNativeWebDistExportsPlatform = require(_dependencyMap[2], "react-native-web/dist/exports/Platform");
  var Platform = _interopDefault(_reactNativeWebDistExportsPlatform);
  const nativeEmitterSubscriptionKey = '@@nativeEmitterSubscription@@';
  /**
   * @deprecated Deprecated in favor of `EventEmitter`.
   */
  class LegacyEventEmitter {
    _listenerCount = 0;

    // @ts-expect-error

    // @ts-expect-error

    constructor(nativeModule) {
      // If the native module is a new module, just return it back as it's already an event emitter.
      // This is for backwards compatibility until we stop using this legacy class in other packages.
      if (nativeModule.__expo_module_name__) {
        // @ts-expect-error
        return nativeModule;
      }
      this._nativeModule = nativeModule;
      this._eventEmitter = new NativeEventEmitter.default(nativeModule);
    }
    addListener(eventName, listener) {
      if (!this._listenerCount && Platform.default.OS !== 'ios' && this._nativeModule.startObserving) {
        this._nativeModule.startObserving();
      }
      this._listenerCount++;
      const nativeEmitterSubscription = this._eventEmitter.addListener(eventName, listener);
      const subscription = {
        [nativeEmitterSubscriptionKey]: nativeEmitterSubscription,
        remove: () => {
          this.removeSubscription(subscription);
        }
      };
      return subscription;
    }
    removeAllListeners(eventName) {
      // @ts-ignore: the EventEmitter interface has been changed in react-native@0.64.0
      const removedListenerCount = this._eventEmitter.listenerCount ?
      // @ts-ignore: this is available since 0.64
      this._eventEmitter.listenerCount(eventName) :
      // @ts-ignore: this is available in older versions
      this._eventEmitter.listeners(eventName).length;
      this._eventEmitter.removeAllListeners(eventName);
      this._listenerCount -= removedListenerCount;
      (0, invariant.default)(this._listenerCount >= 0, `EventEmitter must have a non-negative number of listeners`);
      if (!this._listenerCount && Platform.default.OS !== 'ios' && this._nativeModule.stopObserving) {
        this._nativeModule.stopObserving();
      }
    }
    removeSubscription(subscription) {
      const state = subscription;
      const nativeEmitterSubscription = state[nativeEmitterSubscriptionKey];
      if (!nativeEmitterSubscription) {
        return;
      }
      if ('remove' in nativeEmitterSubscription) {
        nativeEmitterSubscription.remove?.();
      }
      this._listenerCount--;

      // Ensure that the emitter's internal state remains correct even if `removeSubscription` is
      // called again with the same subscription
      delete state[nativeEmitterSubscriptionKey];

      // Release closed-over references to the emitter
      subscription.remove = () => {};
      if (!this._listenerCount && Platform.default.OS !== 'ios' && this._nativeModule.stopObserving) {
        this._nativeModule.stopObserving();
      }
    }
    emit(eventName, ...params) {
      this._eventEmitter.emit(eventName, ...params);
    }
  }
},164,[165,126,123],"node_modules/expo-modules-core/src/LegacyEventEmitter.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  'use strict';

  /**
   * Use invariant() to assert state which your program assumes to be true.
   *
   * Provide sprintf-style format (only %s is supported) and arguments
   * to provide information about what broke and what you were
   * expecting.
   *
   * The invariant message will be stripped in production, but the invariant
   * will remain to ensure logic does not differ in production.
   */
  var invariant = function (condition, format, a, b, c, d, e, f) {
    if (process.env.NODE_ENV !== 'production') {
      if (format === undefined) {
        throw new Error('invariant requires an error message argument');
      }
    }
    if (!condition) {
      var error;
      if (format === undefined) {
        error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
      } else {
        var args = [a, b, c, d, e, f];
        var argIndex = 0;
        error = new Error(format.replace(/%s/g, function () {
          return args[argIndex++];
        }));
        error.name = 'Invariant Violation';
      }
      error.framesToPop = 1; // we don't care about invariant's own frame
      throw error;
    }
  };
  module.exports = invariant;
},165,[],"node_modules/invariant/browser.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  // We default to an empty object shim wherever we don't have an environment-specific implementation

  /**
   * @deprecated `NativeModulesProxy` is deprecated and might be removed in the future releases.
   * Use `requireNativeModule` or `requireOptionalNativeModule` instead.
   */
  var _default = {};
},166,[],"node_modules/expo-modules-core/src/NativeModulesProxy.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _babelRuntimeHelpersObjectWithoutPropertiesLoose = require(_dependencyMap[0], "@babel/runtime/helpers/objectWithoutPropertiesLoose");
  var _objectWithoutPropertiesLoose = _interopDefault(_babelRuntimeHelpersObjectWithoutPropertiesLoose);
  var _react = require(_dependencyMap[1], "react");
  var React = _interopNamespace(_react);
  var _createElement = require(_dependencyMap[2], "../createElement");
  var createElement = _interopDefault(_createElement);
  var _modulesForwardedProps = require(_dependencyMap[3], "../../modules/forwardedProps");
  var forwardedProps = _interopNamespace(_modulesForwardedProps);
  var _modulesPick = require(_dependencyMap[4], "../../modules/pick");
  var pick = _interopDefault(_modulesPick);
  var _modulesUseElementLayout = require(_dependencyMap[5], "../../modules/useElementLayout");
  var useElementLayout = _interopDefault(_modulesUseElementLayout);
  var _modulesUseMergeRefs = require(_dependencyMap[6], "../../modules/useMergeRefs");
  var useMergeRefs = _interopDefault(_modulesUseMergeRefs);
  var _modulesUsePlatformMethods = require(_dependencyMap[7], "../../modules/usePlatformMethods");
  var usePlatformMethods = _interopDefault(_modulesUsePlatformMethods);
  var _modulesUseResponderEvents = require(_dependencyMap[8], "../../modules/useResponderEvents");
  var useResponderEvents = _interopDefault(_modulesUseResponderEvents);
  var _StyleSheet = require(_dependencyMap[9], "../StyleSheet");
  var StyleSheet = _interopDefault(_StyleSheet);
  var _TextTextAncestorContext = require(_dependencyMap[10], "../Text/TextAncestorContext");
  var TextAncestorContext = _interopDefault(_TextTextAncestorContext);
  var _modulesUseLocale = require(_dependencyMap[11], "../../modules/useLocale");
  var _excluded = ["hrefAttrs", "onLayout", "onMoveShouldSetResponder", "onMoveShouldSetResponderCapture", "onResponderEnd", "onResponderGrant", "onResponderMove", "onResponderReject", "onResponderRelease", "onResponderStart", "onResponderTerminate", "onResponderTerminationRequest", "onScrollShouldSetResponder", "onScrollShouldSetResponderCapture", "onSelectionChangeShouldSetResponder", "onSelectionChangeShouldSetResponderCapture", "onStartShouldSetResponder", "onStartShouldSetResponderCapture"];
  var forwardPropsList = Object.assign({}, forwardedProps.defaultProps, forwardedProps.accessibilityProps, forwardedProps.clickProps, forwardedProps.focusProps, forwardedProps.keyboardProps, forwardedProps.mouseProps, forwardedProps.touchProps, forwardedProps.styleProps, {
    href: true,
    lang: true,
    onScroll: true,
    onWheel: true,
    pointerEvents: true
  });
  var pickProps = props => (0, pick.default)(props, forwardPropsList);
  var View = /*#__PURE__*/React.forwardRef((props, forwardedRef) => {
    var hrefAttrs = props.hrefAttrs,
      onLayout = props.onLayout,
      onMoveShouldSetResponder = props.onMoveShouldSetResponder,
      onMoveShouldSetResponderCapture = props.onMoveShouldSetResponderCapture,
      onResponderEnd = props.onResponderEnd,
      onResponderGrant = props.onResponderGrant,
      onResponderMove = props.onResponderMove,
      onResponderReject = props.onResponderReject,
      onResponderRelease = props.onResponderRelease,
      onResponderStart = props.onResponderStart,
      onResponderTerminate = props.onResponderTerminate,
      onResponderTerminationRequest = props.onResponderTerminationRequest,
      onScrollShouldSetResponder = props.onScrollShouldSetResponder,
      onScrollShouldSetResponderCapture = props.onScrollShouldSetResponderCapture,
      onSelectionChangeShouldSetResponder = props.onSelectionChangeShouldSetResponder,
      onSelectionChangeShouldSetResponderCapture = props.onSelectionChangeShouldSetResponderCapture,
      onStartShouldSetResponder = props.onStartShouldSetResponder,
      onStartShouldSetResponderCapture = props.onStartShouldSetResponderCapture,
      rest = (0, _objectWithoutPropertiesLoose.default)(props, _excluded);
    if (process.env.NODE_ENV !== 'production') {
      React.Children.toArray(props.children).forEach(item => {
        if (typeof item === 'string') {
          console.error("Unexpected text node: " + item + ". A text node cannot be a child of a <View>.");
        }
      });
    }
    var hasTextAncestor = React.useContext(TextAncestorContext.default);
    var hostRef = React.useRef(null);
    var _useLocaleContext = (0, _modulesUseLocale.useLocaleContext)(),
      contextDirection = _useLocaleContext.direction;
    (0, useElementLayout.default)(hostRef, onLayout);
    (0, useResponderEvents.default)(hostRef, {
      onMoveShouldSetResponder,
      onMoveShouldSetResponderCapture,
      onResponderEnd,
      onResponderGrant,
      onResponderMove,
      onResponderReject,
      onResponderRelease,
      onResponderStart,
      onResponderTerminate,
      onResponderTerminationRequest,
      onScrollShouldSetResponder,
      onScrollShouldSetResponderCapture,
      onSelectionChangeShouldSetResponder,
      onSelectionChangeShouldSetResponderCapture,
      onStartShouldSetResponder,
      onStartShouldSetResponderCapture
    });
    var component = 'div';
    var langDirection = props.lang != null ? (0, _modulesUseLocale.getLocaleDirection)(props.lang) : null;
    var componentDirection = props.dir || langDirection;
    var writingDirection = componentDirection || contextDirection;
    var supportedProps = pickProps(rest);
    supportedProps.dir = componentDirection;
    supportedProps.style = [styles.view$raw, hasTextAncestor && styles.inline, props.style];
    if (props.href != null) {
      component = 'a';
      if (hrefAttrs != null) {
        var download = hrefAttrs.download,
          rel = hrefAttrs.rel,
          target = hrefAttrs.target;
        if (download != null) {
          supportedProps.download = download;
        }
        if (rel != null) {
          supportedProps.rel = rel;
        }
        if (typeof target === 'string') {
          supportedProps.target = target.charAt(0) !== '_' ? '_' + target : target;
        }
      }
    }
    var platformMethodsRef = (0, usePlatformMethods.default)(supportedProps);
    var setRef = (0, useMergeRefs.default)(hostRef, platformMethodsRef, forwardedRef);
    supportedProps.ref = setRef;
    return (0, createElement.default)(component, supportedProps, {
      writingDirection
    });
  });
  View.displayName = 'View';
  var styles = StyleSheet.default.create({
    view$raw: {
      alignContent: 'flex-start',
      alignItems: 'stretch',
      backgroundColor: 'transparent',
      border: '0 solid black',
      boxSizing: 'border-box',
      display: 'flex',
      flexBasis: 'auto',
      flexDirection: 'column',
      flexShrink: 0,
      listStyle: 'none',
      margin: 0,
      minHeight: 0,
      minWidth: 0,
      padding: 0,
      position: 'relative',
      textDecoration: 'none',
      zIndex: 0
    },
    inline: {
      display: 'inline-flex'
    }
  });
  var _default = View;
},169,[71,62,170,178,179,180,187,189,191,70,198,176],"node_modules/react-native-web/dist/exports/View/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _modulesAccessibilityUtil = require(_dependencyMap[0], "../../modules/AccessibilityUtil");
  var AccessibilityUtil = _interopDefault(_modulesAccessibilityUtil);
  var _modulesCreateDOMProps = require(_dependencyMap[1], "../../modules/createDOMProps");
  var createDOMProps = _interopDefault(_modulesCreateDOMProps);
  var _react = require(_dependencyMap[2], "react");
  var React = _interopDefault(_react);
  var _modulesUseLocale = require(_dependencyMap[3], "../../modules/useLocale");
  var createElement = (component, props, options) => {
    // Use equivalent platform elements where possible.
    var accessibilityComponent;
    if (component && component.constructor === String) {
      accessibilityComponent = AccessibilityUtil.default.propsToAccessibilityComponent(props);
    }
    var Component = accessibilityComponent || component;
    var domProps = (0, createDOMProps.default)(Component, props, options);
    var element = /*#__PURE__*/React.default.createElement(Component, domProps);

    // Update locale context if element's writing direction prop changes
    var elementWithLocaleProvider = domProps.dir ? /*#__PURE__*/React.default.createElement(_modulesUseLocale.LocaleProvider, {
      children: element,
      direction: domProps.dir,
      locale: domProps.lang
    }) : element;
    return elementWithLocaleProvider;
  };
  var _default = createElement;
},170,[171,175,62,176],"node_modules/react-native-web/dist/exports/createElement/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _isDisabled = require(_dependencyMap[0], "./isDisabled");
  var isDisabled = _interopDefault(_isDisabled);
  var _propsToAccessibilityComponent = require(_dependencyMap[1], "./propsToAccessibilityComponent");
  var propsToAccessibilityComponent = _interopDefault(_propsToAccessibilityComponent);
  var _propsToAriaRole = require(_dependencyMap[2], "./propsToAriaRole");
  var propsToAriaRole = _interopDefault(_propsToAriaRole);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var AccessibilityUtil = {
    isDisabled: isDisabled.default,
    propsToAccessibilityComponent: propsToAccessibilityComponent.default,
    propsToAriaRole: propsToAriaRole.default
  };
  var _default = AccessibilityUtil;
},171,[172,173,174],"node_modules/react-native-web/dist/modules/AccessibilityUtil/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var isDisabled = props => props.disabled || Array.isArray(props.accessibilityStates) && props.accessibilityStates.indexOf('disabled') > -1;
  var _default = isDisabled;
},172,[],"node_modules/react-native-web/dist/modules/AccessibilityUtil/isDisabled.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _propsToAriaRole = require(_dependencyMap[0], "./propsToAriaRole");
  var propsToAriaRole = _interopDefault(_propsToAriaRole);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var roleComponents = {
    article: 'article',
    banner: 'header',
    blockquote: 'blockquote',
    button: 'button',
    code: 'code',
    complementary: 'aside',
    contentinfo: 'footer',
    deletion: 'del',
    emphasis: 'em',
    figure: 'figure',
    insertion: 'ins',
    form: 'form',
    list: 'ul',
    listitem: 'li',
    main: 'main',
    navigation: 'nav',
    paragraph: 'p',
    region: 'section',
    strong: 'strong'
  };
  var emptyObject = {};
  var propsToAccessibilityComponent = function propsToAccessibilityComponent(props) {
    if (props === void 0) {
      props = emptyObject;
    }
    var roleProp = props.role || props.accessibilityRole;
    // special-case for "label" role which doesn't map to an ARIA role
    if (roleProp === 'label') {
      return 'label';
    }
    var role = (0, propsToAriaRole.default)(props);
    if (role) {
      if (role === 'heading') {
        var level = props.accessibilityLevel || props['aria-level'];
        if (level != null) {
          return "h" + level;
        }
        return 'h1';
      }
      return roleComponents[role];
    }
  };
  var _default = propsToAccessibilityComponent;
},173,[174],"node_modules/react-native-web/dist/modules/AccessibilityUtil/propsToAccessibilityComponent.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var accessibilityRoleToWebRole = {
    adjustable: 'slider',
    button: 'button',
    header: 'heading',
    image: 'img',
    imagebutton: null,
    keyboardkey: null,
    label: null,
    link: 'link',
    none: 'presentation',
    search: 'search',
    summary: 'region',
    text: null
  };
  var propsToAriaRole = _ref => {
    var accessibilityRole = _ref.accessibilityRole,
      role = _ref.role;
    var _role = role || accessibilityRole;
    if (_role) {
      var inferredRole = accessibilityRoleToWebRole[_role];
      if (inferredRole !== null) {
        // ignore roles that don't map to web
        return inferredRole || _role;
      }
    }
  };
  var _default = propsToAriaRole;
},174,[],"node_modules/react-native-web/dist/modules/AccessibilityUtil/propsToAriaRole.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _babelRuntimeHelpersObjectSpread = require(_dependencyMap[0], "@babel/runtime/helpers/objectSpread2");
  var _objectSpread = _interopDefault(_babelRuntimeHelpersObjectSpread);
  var _babelRuntimeHelpersObjectWithoutPropertiesLoose = require(_dependencyMap[1], "@babel/runtime/helpers/objectWithoutPropertiesLoose");
  var _objectWithoutPropertiesLoose = _interopDefault(_babelRuntimeHelpersObjectWithoutPropertiesLoose);
  var _AccessibilityUtil = require(_dependencyMap[2], "../AccessibilityUtil");
  var AccessibilityUtil = _interopDefault(_AccessibilityUtil);
  var _exportsStyleSheet = require(_dependencyMap[3], "../../exports/StyleSheet");
  var StyleSheet = _interopDefault(_exportsStyleSheet);
  var _warnOnce = require(_dependencyMap[4], "../warnOnce");
  var _excluded = ["aria-activedescendant", "accessibilityActiveDescendant", "aria-atomic", "accessibilityAtomic", "aria-autocomplete", "accessibilityAutoComplete", "aria-busy", "accessibilityBusy", "aria-checked", "accessibilityChecked", "aria-colcount", "accessibilityColumnCount", "aria-colindex", "accessibilityColumnIndex", "aria-colspan", "accessibilityColumnSpan", "aria-controls", "accessibilityControls", "aria-current", "accessibilityCurrent", "aria-describedby", "accessibilityDescribedBy", "aria-details", "accessibilityDetails", "aria-disabled", "accessibilityDisabled", "aria-errormessage", "accessibilityErrorMessage", "aria-expanded", "accessibilityExpanded", "aria-flowto", "accessibilityFlowTo", "aria-haspopup", "accessibilityHasPopup", "aria-hidden", "accessibilityHidden", "aria-invalid", "accessibilityInvalid", "aria-keyshortcuts", "accessibilityKeyShortcuts", "aria-label", "accessibilityLabel", "aria-labelledby", "accessibilityLabelledBy", "aria-level", "accessibilityLevel", "aria-live", "accessibilityLiveRegion", "aria-modal", "accessibilityModal", "aria-multiline", "accessibilityMultiline", "aria-multiselectable", "accessibilityMultiSelectable", "aria-orientation", "accessibilityOrientation", "aria-owns", "accessibilityOwns", "aria-placeholder", "accessibilityPlaceholder", "aria-posinset", "accessibilityPosInSet", "aria-pressed", "accessibilityPressed", "aria-readonly", "accessibilityReadOnly", "aria-required", "accessibilityRequired", "role", "accessibilityRole", "aria-roledescription", "accessibilityRoleDescription", "aria-rowcount", "accessibilityRowCount", "aria-rowindex", "accessibilityRowIndex", "aria-rowspan", "accessibilityRowSpan", "aria-selected", "accessibilitySelected", "aria-setsize", "accessibilitySetSize", "aria-sort", "accessibilitySort", "aria-valuemax", "accessibilityValueMax", "aria-valuemin", "accessibilityValueMin", "aria-valuenow", "accessibilityValueNow", "aria-valuetext", "accessibilityValueText", "dataSet", "focusable", "id", "nativeID", "pointerEvents", "style", "tabIndex", "testID"];
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var emptyObject = {};
  var hasOwnProperty = Object.prototype.hasOwnProperty;
  var isArray = Array.isArray;
  var uppercasePattern = /[A-Z]/g;
  function toHyphenLower(match) {
    return '-' + match.toLowerCase();
  }
  function hyphenateString(str) {
    return str.replace(uppercasePattern, toHyphenLower);
  }
  function processIDRefList(idRefList) {
    return isArray(idRefList) ? idRefList.join(' ') : idRefList;
  }
  var pointerEventsStyles = StyleSheet.default.create({
    auto: {
      pointerEvents: 'auto'
    },
    'box-none': {
      pointerEvents: 'box-none'
    },
    'box-only': {
      pointerEvents: 'box-only'
    },
    none: {
      pointerEvents: 'none'
    }
  });
  var createDOMProps = (elementType, props, options) => {
    if (!props) {
      props = emptyObject;
    }
    var _props = props,
      ariaActiveDescendant = _props['aria-activedescendant'],
      accessibilityActiveDescendant = _props.accessibilityActiveDescendant,
      ariaAtomic = _props['aria-atomic'],
      accessibilityAtomic = _props.accessibilityAtomic,
      ariaAutoComplete = _props['aria-autocomplete'],
      accessibilityAutoComplete = _props.accessibilityAutoComplete,
      ariaBusy = _props['aria-busy'],
      accessibilityBusy = _props.accessibilityBusy,
      ariaChecked = _props['aria-checked'],
      accessibilityChecked = _props.accessibilityChecked,
      ariaColumnCount = _props['aria-colcount'],
      accessibilityColumnCount = _props.accessibilityColumnCount,
      ariaColumnIndex = _props['aria-colindex'],
      accessibilityColumnIndex = _props.accessibilityColumnIndex,
      ariaColumnSpan = _props['aria-colspan'],
      accessibilityColumnSpan = _props.accessibilityColumnSpan,
      ariaControls = _props['aria-controls'],
      accessibilityControls = _props.accessibilityControls,
      ariaCurrent = _props['aria-current'],
      accessibilityCurrent = _props.accessibilityCurrent,
      ariaDescribedBy = _props['aria-describedby'],
      accessibilityDescribedBy = _props.accessibilityDescribedBy,
      ariaDetails = _props['aria-details'],
      accessibilityDetails = _props.accessibilityDetails,
      ariaDisabled = _props['aria-disabled'],
      accessibilityDisabled = _props.accessibilityDisabled,
      ariaErrorMessage = _props['aria-errormessage'],
      accessibilityErrorMessage = _props.accessibilityErrorMessage,
      ariaExpanded = _props['aria-expanded'],
      accessibilityExpanded = _props.accessibilityExpanded,
      ariaFlowTo = _props['aria-flowto'],
      accessibilityFlowTo = _props.accessibilityFlowTo,
      ariaHasPopup = _props['aria-haspopup'],
      accessibilityHasPopup = _props.accessibilityHasPopup,
      ariaHidden = _props['aria-hidden'],
      accessibilityHidden = _props.accessibilityHidden,
      ariaInvalid = _props['aria-invalid'],
      accessibilityInvalid = _props.accessibilityInvalid,
      ariaKeyShortcuts = _props['aria-keyshortcuts'],
      accessibilityKeyShortcuts = _props.accessibilityKeyShortcuts,
      ariaLabel = _props['aria-label'],
      accessibilityLabel = _props.accessibilityLabel,
      ariaLabelledBy = _props['aria-labelledby'],
      accessibilityLabelledBy = _props.accessibilityLabelledBy,
      ariaLevel = _props['aria-level'],
      accessibilityLevel = _props.accessibilityLevel,
      ariaLive = _props['aria-live'],
      accessibilityLiveRegion = _props.accessibilityLiveRegion,
      ariaModal = _props['aria-modal'],
      accessibilityModal = _props.accessibilityModal,
      ariaMultiline = _props['aria-multiline'],
      accessibilityMultiline = _props.accessibilityMultiline,
      ariaMultiSelectable = _props['aria-multiselectable'],
      accessibilityMultiSelectable = _props.accessibilityMultiSelectable,
      ariaOrientation = _props['aria-orientation'],
      accessibilityOrientation = _props.accessibilityOrientation,
      ariaOwns = _props['aria-owns'],
      accessibilityOwns = _props.accessibilityOwns,
      ariaPlaceholder = _props['aria-placeholder'],
      accessibilityPlaceholder = _props.accessibilityPlaceholder,
      ariaPosInSet = _props['aria-posinset'],
      accessibilityPosInSet = _props.accessibilityPosInSet,
      ariaPressed = _props['aria-pressed'],
      accessibilityPressed = _props.accessibilityPressed,
      ariaReadOnly = _props['aria-readonly'],
      accessibilityReadOnly = _props.accessibilityReadOnly,
      ariaRequired = _props['aria-required'],
      accessibilityRequired = _props.accessibilityRequired,
      ariaRole = _props.role,
      accessibilityRole = _props.accessibilityRole,
      ariaRoleDescription = _props['aria-roledescription'],
      accessibilityRoleDescription = _props.accessibilityRoleDescription,
      ariaRowCount = _props['aria-rowcount'],
      accessibilityRowCount = _props.accessibilityRowCount,
      ariaRowIndex = _props['aria-rowindex'],
      accessibilityRowIndex = _props.accessibilityRowIndex,
      ariaRowSpan = _props['aria-rowspan'],
      accessibilityRowSpan = _props.accessibilityRowSpan,
      ariaSelected = _props['aria-selected'],
      accessibilitySelected = _props.accessibilitySelected,
      ariaSetSize = _props['aria-setsize'],
      accessibilitySetSize = _props.accessibilitySetSize,
      ariaSort = _props['aria-sort'],
      accessibilitySort = _props.accessibilitySort,
      ariaValueMax = _props['aria-valuemax'],
      accessibilityValueMax = _props.accessibilityValueMax,
      ariaValueMin = _props['aria-valuemin'],
      accessibilityValueMin = _props.accessibilityValueMin,
      ariaValueNow = _props['aria-valuenow'],
      accessibilityValueNow = _props.accessibilityValueNow,
      ariaValueText = _props['aria-valuetext'],
      accessibilityValueText = _props.accessibilityValueText,
      dataSet = _props.dataSet,
      focusable = _props.focusable,
      id = _props.id,
      nativeID = _props.nativeID,
      pointerEvents = _props.pointerEvents,
      style = _props.style,
      tabIndex = _props.tabIndex,
      testID = _props.testID,
      domProps = (0, _objectWithoutPropertiesLoose.default)(_props, _excluded);

    /*
    if (accessibilityDisabled != null) {
      warnOnce('accessibilityDisabled', `accessibilityDisabled is deprecated.`);
    }
    */
    var disabled = ariaDisabled || accessibilityDisabled;
    var role = AccessibilityUtil.default.propsToAriaRole(props);

    // ACCESSIBILITY
    /*
    if (accessibilityActiveDescendant != null) {
      warnOnce(
        'accessibilityActiveDescendant',
        `accessibilityActiveDescendant is deprecated. Use aria-activedescendant.`
      );
    }
    */
    var _ariaActiveDescendant = ariaActiveDescendant != null ? ariaActiveDescendant : accessibilityActiveDescendant;
    if (_ariaActiveDescendant != null) {
      domProps['aria-activedescendant'] = _ariaActiveDescendant;
    }

    /*
    if (accessibilityAtomic != null) {
      warnOnce(
        'accessibilityAtomic',
        `accessibilityAtomic is deprecated. Use aria-atomic.`
      );
    }
    */
    var _ariaAtomic = ariaAtomic != null ? ariaActiveDescendant : accessibilityAtomic;
    if (_ariaAtomic != null) {
      domProps['aria-atomic'] = _ariaAtomic;
    }

    /*
    if (accessibilityAutoComplete != null) {
      warnOnce(
        'accessibilityAutoComplete',
        `accessibilityAutoComplete is deprecated. Use aria-autocomplete.`
      );
    }
    */
    var _ariaAutoComplete = ariaAutoComplete != null ? ariaAutoComplete : accessibilityAutoComplete;
    if (_ariaAutoComplete != null) {
      domProps['aria-autocomplete'] = _ariaAutoComplete;
    }

    /*
    if (accessibilityBusy != null) {
      warnOnce(
        'accessibilityBusy',
        `accessibilityBusy is deprecated. Use aria-busy.`
      );
    }
    */
    var _ariaBusy = ariaBusy != null ? ariaBusy : accessibilityBusy;
    if (_ariaBusy != null) {
      domProps['aria-busy'] = _ariaBusy;
    }

    /*
    if (accessibilityChecked != null) {
      warnOnce(
        'accessibilityChecked',
        `accessibilityChecked is deprecated. Use aria-checked.`
      );
    }
    */
    var _ariaChecked = ariaChecked != null ? ariaChecked : accessibilityChecked;
    if (_ariaChecked != null) {
      domProps['aria-checked'] = _ariaChecked;
    }

    /*
    if (accessibilityColumnCount != null) {
      warnOnce(
        'accessibilityColumnCount',
        `accessibilityColumnCount is deprecated. Use aria-colcount.`
      );
    }
    */
    var _ariaColumnCount = ariaColumnCount != null ? ariaColumnCount : accessibilityColumnCount;
    if (_ariaColumnCount != null) {
      domProps['aria-colcount'] = _ariaColumnCount;
    }

    /*
    if (accessibilityColumnIndex != null) {
      warnOnce(
        'accessibilityColumnIndex',
        `accessibilityColumnIndex is deprecated. Use aria-colindex.`
      );
    }
    */
    var _ariaColumnIndex = ariaColumnIndex != null ? ariaColumnIndex : accessibilityColumnIndex;
    if (_ariaColumnIndex != null) {
      domProps['aria-colindex'] = _ariaColumnIndex;
    }

    /*
    if (accessibilityColumnSpan != null) {
      warnOnce(
        'accessibilityColumnSpan',
        `accessibilityColumnSpan is deprecated. Use aria-colspan.`
      );
    }
    */
    var _ariaColumnSpan = ariaColumnSpan != null ? ariaColumnSpan : accessibilityColumnSpan;
    if (_ariaColumnSpan != null) {
      domProps['aria-colspan'] = _ariaColumnSpan;
    }

    /*
    if (accessibilityControls != null) {
      warnOnce(
        'accessibilityControls',
        `accessibilityControls is deprecated. Use aria-controls.`
      );
    }
    */
    var _ariaControls = ariaControls != null ? ariaControls : accessibilityControls;
    if (_ariaControls != null) {
      domProps['aria-controls'] = processIDRefList(_ariaControls);
    }

    /*
    if (accessibilityCurrent != null) {
      warnOnce(
        'accessibilityCurrent',
        `accessibilityCurrent is deprecated. Use aria-current.`
      );
    }
    */
    var _ariaCurrent = ariaCurrent != null ? ariaCurrent : accessibilityCurrent;
    if (_ariaCurrent != null) {
      domProps['aria-current'] = _ariaCurrent;
    }

    /*
    if (accessibilityDescribedBy != null) {
      warnOnce(
        'accessibilityDescribedBy',
        `accessibilityDescribedBy is deprecated. Use aria-describedby.`
      );
    }
    */
    var _ariaDescribedBy = ariaDescribedBy != null ? ariaDescribedBy : accessibilityDescribedBy;
    if (_ariaDescribedBy != null) {
      domProps['aria-describedby'] = processIDRefList(_ariaDescribedBy);
    }

    /*
    if (accessibilityDetails != null) {
      warnOnce(
        'accessibilityDetails',
        `accessibilityDetails is deprecated. Use aria-details.`
      );
    }
    */
    var _ariaDetails = ariaDetails != null ? ariaDetails : accessibilityDetails;
    if (_ariaDetails != null) {
      domProps['aria-details'] = _ariaDetails;
    }
    if (disabled === true) {
      domProps['aria-disabled'] = true;
      // Enhance with native semantics
      if (elementType === 'button' || elementType === 'form' || elementType === 'input' || elementType === 'select' || elementType === 'textarea') {
        domProps.disabled = true;
      }
    }

    /*
    if (accessibilityErrorMessage != null) {
      warnOnce(
        'accessibilityErrorMessage',
        `accessibilityErrorMessage is deprecated. Use aria-errormessage.`
      );
    }
    */
    var _ariaErrorMessage = ariaErrorMessage != null ? ariaErrorMessage : accessibilityErrorMessage;
    if (_ariaErrorMessage != null) {
      domProps['aria-errormessage'] = _ariaErrorMessage;
    }

    /*
    if (accessibilityExpanded != null) {
      warnOnce(
        'accessibilityExpanded',
        `accessibilityExpanded is deprecated. Use aria-expanded.`
      );
    }
    */
    var _ariaExpanded = ariaExpanded != null ? ariaExpanded : accessibilityExpanded;
    if (_ariaExpanded != null) {
      domProps['aria-expanded'] = _ariaExpanded;
    }

    /*
    if (accessibilityFlowTo != null) {
      warnOnce(
        'accessibilityFlowTo',
        `accessibilityFlowTo is deprecated. Use aria-flowto.`
      );
    }
    */
    var _ariaFlowTo = ariaFlowTo != null ? ariaFlowTo : accessibilityFlowTo;
    if (_ariaFlowTo != null) {
      domProps['aria-flowto'] = processIDRefList(_ariaFlowTo);
    }

    /*
    if (accessibilityHasPopup != null) {
      warnOnce(
        'accessibilityHasPopup',
        `accessibilityHasPopup is deprecated. Use aria-haspopup.`
      );
    }
    */
    var _ariaHasPopup = ariaHasPopup != null ? ariaHasPopup : accessibilityHasPopup;
    if (_ariaHasPopup != null) {
      domProps['aria-haspopup'] = _ariaHasPopup;
    }

    /*
    if (accessibilityHidden != null) {
      warnOnce(
        'accessibilityHidden',
        `accessibilityHidden is deprecated. Use aria-hidden.`
      );
    }
    */
    var _ariaHidden = ariaHidden != null ? ariaHidden : accessibilityHidden;
    if (_ariaHidden === true) {
      domProps['aria-hidden'] = _ariaHidden;
    }

    /*
    if (accessibilityInvalid != null) {
      warnOnce(
        'accessibilityInvalid',
        `accessibilityInvalid is deprecated. Use aria-invalid.`
      );
    }
    */
    var _ariaInvalid = ariaInvalid != null ? ariaInvalid : accessibilityInvalid;
    if (_ariaInvalid != null) {
      domProps['aria-invalid'] = _ariaInvalid;
    }

    /*
    if (accessibilityKeyShortcuts != null) {
      warnOnce(
        'accessibilityKeyShortcuts',
        `accessibilityKeyShortcuts is deprecated. Use aria-keyshortcuts.`
      );
    }
    */
    var _ariaKeyShortcuts = ariaKeyShortcuts != null ? ariaKeyShortcuts : accessibilityKeyShortcuts;
    if (_ariaKeyShortcuts != null) {
      domProps['aria-keyshortcuts'] = processIDRefList(_ariaKeyShortcuts);
    }

    /*
    if (accessibilityLabel != null) {
      warnOnce(
        'accessibilityLabel',
        `accessibilityLabel is deprecated. Use aria-label.`
      );
    }
    */
    var _ariaLabel = ariaLabel != null ? ariaLabel : accessibilityLabel;
    if (_ariaLabel != null) {
      domProps['aria-label'] = _ariaLabel;
    }

    /*
    if (accessibilityLabelledBy != null) {
      warnOnce(
        'accessibilityLabelledBy',
        `accessibilityLabelledBy is deprecated. Use aria-labelledby.`
      );
    }
    */
    var _ariaLabelledBy = ariaLabelledBy != null ? ariaLabelledBy : accessibilityLabelledBy;
    if (_ariaLabelledBy != null) {
      domProps['aria-labelledby'] = processIDRefList(_ariaLabelledBy);
    }

    /*
    if (accessibilityLevel != null) {
      warnOnce(
        'accessibilityLevel',
        `accessibilityLevel is deprecated. Use aria-level.`
      );
    }
    */
    var _ariaLevel = ariaLevel != null ? ariaLevel : accessibilityLevel;
    if (_ariaLevel != null) {
      domProps['aria-level'] = _ariaLevel;
    }

    /*
    if (accessibilityLiveRegion != null) {
      warnOnce(
        'accessibilityLiveRegion',
        `accessibilityLiveRegion is deprecated. Use aria-live.`
      );
    }
    */
    var _ariaLive = ariaLive != null ? ariaLive : accessibilityLiveRegion;
    if (_ariaLive != null) {
      domProps['aria-live'] = _ariaLive === 'none' ? 'off' : _ariaLive;
    }

    /*
    if (accessibilityModal != null) {
      warnOnce(
        'accessibilityModal',
        `accessibilityModal is deprecated. Use aria-modal.`
      );
    }
    */
    var _ariaModal = ariaModal != null ? ariaModal : accessibilityModal;
    if (_ariaModal != null) {
      domProps['aria-modal'] = _ariaModal;
    }

    /*
    if (accessibilityMultiline != null) {
      warnOnce(
        'accessibilityMultiline',
        `accessibilityMultiline is deprecated. Use aria-multiline.`
      );
    }
    */
    var _ariaMultiline = ariaMultiline != null ? ariaMultiline : accessibilityMultiline;
    if (_ariaMultiline != null) {
      domProps['aria-multiline'] = _ariaMultiline;
    }

    /*
    if (accessibilityMultiSelectable != null) {
      warnOnce(
        'accessibilityMultiSelectable',
        `accessibilityMultiSelectable is deprecated. Use aria-multiselectable.`
      );
    }
    */
    var _ariaMultiSelectable = ariaMultiSelectable != null ? ariaMultiSelectable : accessibilityMultiSelectable;
    if (_ariaMultiSelectable != null) {
      domProps['aria-multiselectable'] = _ariaMultiSelectable;
    }

    /*
    if (accessibilityOrientation != null) {
      warnOnce(
        'accessibilityOrientation',
        `accessibilityOrientation is deprecated. Use aria-orientation.`
      );
    }
    */
    var _ariaOrientation = ariaOrientation != null ? ariaOrientation : accessibilityOrientation;
    if (_ariaOrientation != null) {
      domProps['aria-orientation'] = _ariaOrientation;
    }

    /*
    if (accessibilityOwns != null) {
      warnOnce(
        'accessibilityOwns',
        `accessibilityOwns is deprecated. Use aria-owns.`
      );
    }
    */
    var _ariaOwns = ariaOwns != null ? ariaOwns : accessibilityOwns;
    if (_ariaOwns != null) {
      domProps['aria-owns'] = processIDRefList(_ariaOwns);
    }

    /*
    if (accessibilityPlaceholder != null) {
      warnOnce(
        'accessibilityPlaceholder',
        `accessibilityPlaceholder is deprecated. Use aria-placeholder.`
      );
    }
    */
    var _ariaPlaceholder = ariaPlaceholder != null ? ariaPlaceholder : accessibilityPlaceholder;
    if (_ariaPlaceholder != null) {
      domProps['aria-placeholder'] = _ariaPlaceholder;
    }

    /*
    if (accessibilityPosInSet != null) {
      warnOnce(
        'accessibilityPosInSet',
        `accessibilityPosInSet is deprecated. Use aria-posinset.`
      );
    }
    */
    var _ariaPosInSet = ariaPosInSet != null ? ariaPosInSet : accessibilityPosInSet;
    if (_ariaPosInSet != null) {
      domProps['aria-posinset'] = _ariaPosInSet;
    }

    /*
    if (accessibilityPressed != null) {
      warnOnce(
        'accessibilityPressed',
        `accessibilityPressed is deprecated. Use aria-pressed.`
      );
    }
    */
    var _ariaPressed = ariaPressed != null ? ariaPressed : accessibilityPressed;
    if (_ariaPressed != null) {
      domProps['aria-pressed'] = _ariaPressed;
    }

    /*
    if (accessibilityReadOnly != null) {
      warnOnce(
        'accessibilityReadOnly',
        `accessibilityReadOnly is deprecated. Use aria-readonly.`
      );
    }
    */
    var _ariaReadOnly = ariaReadOnly != null ? ariaReadOnly : accessibilityReadOnly;
    if (_ariaReadOnly != null) {
      domProps['aria-readonly'] = _ariaReadOnly;
      // Enhance with native semantics
      if (elementType === 'input' || elementType === 'select' || elementType === 'textarea') {
        domProps.readOnly = true;
      }
    }

    /*
    if (accessibilityRequired != null) {
      warnOnce(
        'accessibilityRequired',
        `accessibilityRequired is deprecated. Use aria-required.`
      );
    }
    */
    var _ariaRequired = ariaRequired != null ? ariaRequired : accessibilityRequired;
    if (_ariaRequired != null) {
      domProps['aria-required'] = _ariaRequired;
      // Enhance with native semantics
      if (elementType === 'input' || elementType === 'select' || elementType === 'textarea') {
        domProps.required = accessibilityRequired;
      }
    }

    /*
    if (accessibilityRole != null) {
      warnOnce('accessibilityRole', `accessibilityRole is deprecated. Use role.`);
    }
    */
    if (role != null) {
      // 'presentation' synonym has wider browser support
      domProps['role'] = role === 'none' ? 'presentation' : role;
    }

    /*
    if (accessibilityRoleDescription != null) {
      warnOnce(
        'accessibilityRoleDescription',
        `accessibilityRoleDescription is deprecated. Use aria-roledescription.`
      );
    }
    */
    var _ariaRoleDescription = ariaRoleDescription != null ? ariaRoleDescription : accessibilityRoleDescription;
    if (_ariaRoleDescription != null) {
      domProps['aria-roledescription'] = _ariaRoleDescription;
    }

    /*
    if (accessibilityRowCount != null) {
      warnOnce(
        'accessibilityRowCount',
        `accessibilityRowCount is deprecated. Use aria-rowcount.`
      );
    }
    */
    var _ariaRowCount = ariaRowCount != null ? ariaRowCount : accessibilityRowCount;
    if (_ariaRowCount != null) {
      domProps['aria-rowcount'] = _ariaRowCount;
    }

    /*
    if (accessibilityRowIndex != null) {
      warnOnce(
        'accessibilityRowIndex',
        `accessibilityRowIndex is deprecated. Use aria-rowindex.`
      );
    }
    */
    var _ariaRowIndex = ariaRowIndex != null ? ariaRowIndex : accessibilityRowIndex;
    if (_ariaRowIndex != null) {
      domProps['aria-rowindex'] = _ariaRowIndex;
    }

    /*
    if (accessibilityRowSpan != null) {
      warnOnce(
        'accessibilityRowSpan',
        `accessibilityRowSpan is deprecated. Use aria-rowspan.`
      );
    }
    */
    var _ariaRowSpan = ariaRowSpan != null ? ariaRowSpan : accessibilityRowSpan;
    if (_ariaRowSpan != null) {
      domProps['aria-rowspan'] = _ariaRowSpan;
    }

    /*
    if (accessibilitySelected != null) {
      warnOnce(
        'accessibilitySelected',
        `accessibilitySelected is deprecated. Use aria-selected.`
      );
    }
    */
    var _ariaSelected = ariaSelected != null ? ariaSelected : accessibilitySelected;
    if (_ariaSelected != null) {
      domProps['aria-selected'] = _ariaSelected;
    }

    /*
    if (accessibilitySetSize != null) {
      warnOnce(
        'accessibilitySetSize',
        `accessibilitySetSize is deprecated. Use aria-setsize.`
      );
    }
    */
    var _ariaSetSize = ariaSetSize != null ? ariaSetSize : accessibilitySetSize;
    if (_ariaSetSize != null) {
      domProps['aria-setsize'] = _ariaSetSize;
    }

    /*
    if (accessibilitySort != null) {
      warnOnce(
        'accessibilitySort',
        `accessibilitySort is deprecated. Use aria-sort.`
      );
    }
    */
    var _ariaSort = ariaSort != null ? ariaSort : accessibilitySort;
    if (_ariaSort != null) {
      domProps['aria-sort'] = _ariaSort;
    }

    /*
    if (accessibilityValueMax != null) {
      warnOnce(
        'accessibilityValueMax',
        `accessibilityValueMax is deprecated. Use aria-valuemax.`
      );
    }
    */
    var _ariaValueMax = ariaValueMax != null ? ariaValueMax : accessibilityValueMax;
    if (_ariaValueMax != null) {
      domProps['aria-valuemax'] = _ariaValueMax;
    }

    /*
    if (accessibilityValueMin != null) {
      warnOnce(
        'accessibilityValueMin',
        `accessibilityValueMin is deprecated. Use aria-valuemin.`
      );
    }
    */
    var _ariaValueMin = ariaValueMin != null ? ariaValueMin : accessibilityValueMin;
    if (_ariaValueMin != null) {
      domProps['aria-valuemin'] = _ariaValueMin;
    }

    /*
    if (accessibilityValueNow != null) {
      warnOnce(
        'accessibilityValueNow',
        `accessibilityValueNow is deprecated. Use aria-valuenow.`
      );
    }
    */
    var _ariaValueNow = ariaValueNow != null ? ariaValueNow : accessibilityValueNow;
    if (_ariaValueNow != null) {
      domProps['aria-valuenow'] = _ariaValueNow;
    }

    /*
    if (accessibilityValueText != null) {
      warnOnce(
        'accessibilityValueText',
        `accessibilityValueText is deprecated. Use aria-valuetext.`
      );
    }
    */
    var _ariaValueText = ariaValueText != null ? ariaValueText : accessibilityValueText;
    if (_ariaValueText != null) {
      domProps['aria-valuetext'] = _ariaValueText;
    }

    // "dataSet" replaced with "data-*"
    if (dataSet != null) {
      for (var dataProp in dataSet) {
        if (hasOwnProperty.call(dataSet, dataProp)) {
          var dataName = hyphenateString(dataProp);
          var dataValue = dataSet[dataProp];
          if (dataValue != null) {
            domProps["data-" + dataName] = dataValue;
          }
        }
      }
    }

    // FOCUS
    if (tabIndex === 0 || tabIndex === '0' || tabIndex === -1 || tabIndex === '-1') {
      domProps.tabIndex = tabIndex;
    } else {
      /*
      if (focusable != null) {
        warnOnce('focusable', `focusable is deprecated.`);
      }
      */

      // "focusable" indicates that an element may be a keyboard tab-stop.
      if (focusable === false) {
        domProps.tabIndex = '-1';
      }
      if (
      // These native elements are keyboard focusable by default
      elementType === 'a' || elementType === 'button' || elementType === 'input' || elementType === 'select' || elementType === 'textarea') {
        if (focusable === false || accessibilityDisabled === true) {
          domProps.tabIndex = '-1';
        }
      } else if (
      // These roles are made keyboard focusable by default
      role === 'button' || role === 'checkbox' || role === 'link' || role === 'radio' || role === 'textbox' || role === 'switch') {
        if (focusable !== false) {
          domProps.tabIndex = '0';
        }
      } else {
        // Everything else must explicitly set the prop
        if (focusable === true) {
          domProps.tabIndex = '0';
        }
      }
    }

    // Resolve styles
    if (pointerEvents != null) {
      (0, _warnOnce.warnOnce)('pointerEvents', "props.pointerEvents is deprecated. Use style.pointerEvents");
    }
    var _StyleSheet = (0, StyleSheet.default)([style, pointerEvents && pointerEventsStyles[pointerEvents]], (0, _objectSpread.default)({
        writingDirection: 'ltr'
      }, options)),
      className = _StyleSheet[0],
      inlineStyle = _StyleSheet[1];
    if (className) {
      domProps.className = className;
    }
    if (inlineStyle) {
      domProps.style = inlineStyle;
    }

    // OTHER
    // Native element ID
    /*
    if (nativeID != null) {
      warnOnce('nativeID', `nativeID is deprecated. Use id.`);
    }
    */
    var _id = id != null ? id : nativeID;
    if (_id != null) {
      domProps.id = _id;
    }
    // Automated test IDs
    if (testID != null) {
      domProps['data-testid'] = testID;
    }
    if (domProps.type == null && elementType === 'button') {
      domProps.type = 'button';
    }
    return domProps;
  };
  var _default = createDOMProps;
},175,[47,71,171,70,115],"node_modules/react-native-web/dist/modules/createDOMProps/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.getLocaleDirection = getLocaleDirection;
  exports.LocaleProvider = LocaleProvider;
  exports.useLocaleContext = useLocaleContext;
  var _react = require(_dependencyMap[0], "react");
  var React = _interopDefault(_react);
  var _isLocaleRTL = require(_dependencyMap[1], "./isLocaleRTL");
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var defaultLocale = {
    direction: 'ltr',
    locale: 'en-US'
  };
  var LocaleContext = /*#__PURE__*/(0, _react.createContext)(defaultLocale);
  function getLocaleDirection(locale) {
    return (0, _isLocaleRTL.isLocaleRTL)(locale) ? 'rtl' : 'ltr';
  }
  function LocaleProvider(props) {
    var direction = props.direction,
      locale = props.locale,
      children = props.children;
    var needsContext = direction || locale;
    return needsContext ? /*#__PURE__*/React.default.createElement(LocaleContext.Provider, {
      children: children,
      value: {
        direction: locale ? getLocaleDirection(locale) : direction,
        locale
      }
    }) : children;
  }
  function useLocaleContext() {
    return (0, _react.useContext)(LocaleContext);
  }
},176,[62,177],"node_modules/react-native-web/dist/modules/useLocale/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.isLocaleRTL = isLocaleRTL;
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var rtlScripts = new Set(['Arab', 'Syrc', 'Samr', 'Mand', 'Thaa', 'Mend', 'Nkoo', 'Adlm', 'Rohg', 'Hebr']);
  var rtlLangs = new Set(['ae',
  // Avestan
  'ar',
  // Arabic
  'arc',
  // Aramaic
  'bcc',
  // Southern Balochi
  'bqi',
  // Bakthiari
  'ckb',
  // Sorani
  'dv',
  // Dhivehi
  'fa', 'far',
  // Persian
  'glk',
  // Gilaki
  'he', 'iw',
  // Hebrew
  'khw',
  // Khowar
  'ks',
  // Kashmiri
  'ku',
  // Kurdish
  'mzn',
  // Mazanderani
  'nqo',
  // N'Ko
  'pnb',
  // Western Punjabi
  'ps',
  // Pashto
  'sd',
  // Sindhi
  'ug',
  // Uyghur
  'ur',
  // Urdu
  'yi' // Yiddish
  ]);
  var cache = new Map();

  /**
   * Determine the writing direction of a locale
   */
  function isLocaleRTL(locale) {
    var cachedRTL = cache.get(locale);
    if (cachedRTL) {
      return cachedRTL;
    }
    var isRTL = false;
    // $FlowFixMe
    if (Intl.Locale) {
      try {
        // $FlowFixMe
        var script = new Intl.Locale(locale).maximize().script;
        isRTL = rtlScripts.has(script);
      } catch (_unused) {
        // RangeError: Incorrect locale information provided
        // Fallback to inferring from language
        var lang = locale.split('-')[0];
        isRTL = rtlLangs.has(lang);
      }
    } else {
      // Fallback to inferring from language
      var _lang = locale.split('-')[0];
      isRTL = rtlLangs.has(_lang);
    }
    cache.set(locale, isRTL);
    return isRTL;
  }
},177,[],"node_modules/react-native-web/dist/modules/useLocale/isLocaleRTL.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "defaultProps", {
    enumerable: true,
    get: function () {
      return defaultProps;
    }
  });
  Object.defineProperty(exports, "accessibilityProps", {
    enumerable: true,
    get: function () {
      return accessibilityProps;
    }
  });
  Object.defineProperty(exports, "clickProps", {
    enumerable: true,
    get: function () {
      return clickProps;
    }
  });
  Object.defineProperty(exports, "focusProps", {
    enumerable: true,
    get: function () {
      return focusProps;
    }
  });
  Object.defineProperty(exports, "keyboardProps", {
    enumerable: true,
    get: function () {
      return keyboardProps;
    }
  });
  Object.defineProperty(exports, "mouseProps", {
    enumerable: true,
    get: function () {
      return mouseProps;
    }
  });
  Object.defineProperty(exports, "touchProps", {
    enumerable: true,
    get: function () {
      return touchProps;
    }
  });
  Object.defineProperty(exports, "styleProps", {
    enumerable: true,
    get: function () {
      return styleProps;
    }
  });
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var defaultProps = {
    children: true,
    dataSet: true,
    dir: true,
    id: true,
    ref: true,
    suppressHydrationWarning: true,
    tabIndex: true,
    testID: true,
    // @deprecated
    focusable: true,
    nativeID: true
  };
  var accessibilityProps = {
    'aria-activedescendant': true,
    'aria-atomic': true,
    'aria-autocomplete': true,
    'aria-busy': true,
    'aria-checked': true,
    'aria-colcount': true,
    'aria-colindex': true,
    'aria-colspan': true,
    'aria-controls': true,
    'aria-current': true,
    'aria-describedby': true,
    'aria-details': true,
    'aria-disabled': true,
    'aria-errormessage': true,
    'aria-expanded': true,
    'aria-flowto': true,
    'aria-haspopup': true,
    'aria-hidden': true,
    'aria-invalid': true,
    'aria-keyshortcuts': true,
    'aria-label': true,
    'aria-labelledby': true,
    'aria-level': true,
    'aria-live': true,
    'aria-modal': true,
    'aria-multiline': true,
    'aria-multiselectable': true,
    'aria-orientation': true,
    'aria-owns': true,
    'aria-placeholder': true,
    'aria-posinset': true,
    'aria-pressed': true,
    'aria-readonly': true,
    'aria-required': true,
    inert: true,
    role: true,
    'aria-roledescription': true,
    'aria-rowcount': true,
    'aria-rowindex': true,
    'aria-rowspan': true,
    'aria-selected': true,
    'aria-setsize': true,
    'aria-sort': true,
    'aria-valuemax': true,
    'aria-valuemin': true,
    'aria-valuenow': true,
    'aria-valuetext': true,
    // @deprecated
    accessibilityActiveDescendant: true,
    accessibilityAtomic: true,
    accessibilityAutoComplete: true,
    accessibilityBusy: true,
    accessibilityChecked: true,
    accessibilityColumnCount: true,
    accessibilityColumnIndex: true,
    accessibilityColumnSpan: true,
    accessibilityControls: true,
    accessibilityCurrent: true,
    accessibilityDescribedBy: true,
    accessibilityDetails: true,
    accessibilityDisabled: true,
    accessibilityErrorMessage: true,
    accessibilityExpanded: true,
    accessibilityFlowTo: true,
    accessibilityHasPopup: true,
    accessibilityHidden: true,
    accessibilityInvalid: true,
    accessibilityKeyShortcuts: true,
    accessibilityLabel: true,
    accessibilityLabelledBy: true,
    accessibilityLevel: true,
    accessibilityLiveRegion: true,
    accessibilityModal: true,
    accessibilityMultiline: true,
    accessibilityMultiSelectable: true,
    accessibilityOrientation: true,
    accessibilityOwns: true,
    accessibilityPlaceholder: true,
    accessibilityPosInSet: true,
    accessibilityPressed: true,
    accessibilityReadOnly: true,
    accessibilityRequired: true,
    accessibilityRole: true,
    accessibilityRoleDescription: true,
    accessibilityRowCount: true,
    accessibilityRowIndex: true,
    accessibilityRowSpan: true,
    accessibilitySelected: true,
    accessibilitySetSize: true,
    accessibilitySort: true,
    accessibilityValueMax: true,
    accessibilityValueMin: true,
    accessibilityValueNow: true,
    accessibilityValueText: true
  };
  var clickProps = {
    onClick: true,
    onAuxClick: true,
    onContextMenu: true,
    onGotPointerCapture: true,
    onLostPointerCapture: true,
    onPointerCancel: true,
    onPointerDown: true,
    onPointerEnter: true,
    onPointerMove: true,
    onPointerLeave: true,
    onPointerOut: true,
    onPointerOver: true,
    onPointerUp: true
  };
  var focusProps = {
    onBlur: true,
    onFocus: true
  };
  var keyboardProps = {
    onKeyDown: true,
    onKeyDownCapture: true,
    onKeyUp: true,
    onKeyUpCapture: true
  };
  var mouseProps = {
    onMouseDown: true,
    onMouseEnter: true,
    onMouseLeave: true,
    onMouseMove: true,
    onMouseOver: true,
    onMouseOut: true,
    onMouseUp: true
  };
  var touchProps = {
    onTouchCancel: true,
    onTouchCancelCapture: true,
    onTouchEnd: true,
    onTouchEndCapture: true,
    onTouchMove: true,
    onTouchMoveCapture: true,
    onTouchStart: true,
    onTouchStartCapture: true
  };
  var styleProps = {
    style: true
  };
},178,[],"node_modules/react-native-web/dist/modules/forwardedProps/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return pick;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  function pick(obj, list) {
    var nextObj = {};
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) {
        if (list[key] === true) {
          nextObj[key] = obj[key];
        }
      }
    }
    return nextObj;
  }
},179,[],"node_modules/react-native-web/dist/modules/pick/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return useElementLayout;
    }
  });
  var _useLayoutEffect = require(_dependencyMap[0], "../useLayoutEffect");
  var useLayoutEffect = _interopDefault(_useLayoutEffect);
  var _exportsUIManager = require(_dependencyMap[1], "../../exports/UIManager");
  var UIManager = _interopDefault(_exportsUIManager);
  var _canUseDom = require(_dependencyMap[2], "../canUseDom");
  var canUseDOM = _interopDefault(_canUseDom);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var DOM_LAYOUT_HANDLER_NAME = '__reactLayoutHandler';
  var didWarn = !canUseDOM.default;
  var resizeObserver = null;
  function getResizeObserver() {
    if (canUseDOM.default && typeof window.ResizeObserver !== 'undefined') {
      if (resizeObserver == null) {
        resizeObserver = new window.ResizeObserver(function (entries) {
          entries.forEach(entry => {
            var node = entry.target;
            var onLayout = node[DOM_LAYOUT_HANDLER_NAME];
            if (typeof onLayout === 'function') {
              // We still need to measure the view because browsers don't yet provide
              // border-box dimensions in the entry
              UIManager.default.measure(node, (x, y, width, height, left, top) => {
                var event = {
                  // $FlowFixMe
                  nativeEvent: {
                    layout: {
                      x,
                      y,
                      width,
                      height,
                      left,
                      top
                    }
                  },
                  timeStamp: Date.now()
                };
                Object.defineProperty(event.nativeEvent, 'target', {
                  enumerable: true,
                  get: () => entry.target
                });
                onLayout(event);
              });
            }
          });
        });
      }
    } else if (!didWarn) {
      if (process.env.NODE_ENV !== 'production' && process.env.NODE_ENV !== 'test') {
        console.warn('onLayout relies on ResizeObserver which is not supported by your browser. ' + 'Please include a polyfill, e.g., https://github.com/que-etc/resize-observer-polyfill.');
        didWarn = true;
      }
    }
    return resizeObserver;
  }
  function useElementLayout(ref, onLayout) {
    var observer = getResizeObserver();
    (0, useLayoutEffect.default)(() => {
      var node = ref.current;
      if (node != null) {
        node[DOM_LAYOUT_HANDLER_NAME] = onLayout;
      }
    }, [ref, onLayout]);

    // Observing is done in a separate effect to avoid this effect running
    // when 'onLayout' changes.
    (0, useLayoutEffect.default)(() => {
      var node = ref.current;
      if (node != null && observer != null) {
        if (typeof node[DOM_LAYOUT_HANDLER_NAME] === 'function') {
          observer.observe(node);
        } else {
          observer.unobserve(node);
        }
      }
      return () => {
        if (node != null && observer != null) {
          observer.unobserve(node);
        }
      };
    }, [ref, observer]);
  }
},180,[181,182,67],"node_modules/react-native-web/dist/modules/useElementLayout/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var _canUseDom = require(_dependencyMap[1], "../canUseDom");
  var canUseDOM = _interopDefault(_canUseDom);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * useLayoutEffect throws an error on the server. On the few occasions where is
   * problematic, use this hook.
   *
   * 
   */

  var useLayoutEffectImpl = canUseDOM.default ? _react.useLayoutEffect : _react.useEffect;
  var _default = useLayoutEffectImpl;
},181,[62,67],"node_modules/react-native-web/dist/modules/useLayoutEffect/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _modulesGetBoundingClientRect = require(_dependencyMap[0], "../../modules/getBoundingClientRect");
  var getBoundingClientRect = _interopDefault(_modulesGetBoundingClientRect);
  var _modulesSetValueForStyles = require(_dependencyMap[1], "../../modules/setValueForStyles");
  var setValueForStyles = _interopDefault(_modulesSetValueForStyles);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var getRect = node => {
    var height = node.offsetHeight;
    var width = node.offsetWidth;
    var left = node.offsetLeft;
    var top = node.offsetTop;
    node = node.offsetParent;
    while (node && node.nodeType === 1 /* Node.ELEMENT_NODE */) {
      left += node.offsetLeft + node.clientLeft - node.scrollLeft;
      top += node.offsetTop + node.clientTop - node.scrollTop;
      node = node.offsetParent;
    }
    top -= window.scrollY;
    left -= window.scrollX;
    return {
      width,
      height,
      top,
      left
    };
  };
  var measureLayout = (node, relativeToNativeNode, callback) => {
    var relativeNode = relativeToNativeNode || node && node.parentNode;
    if (node && relativeNode) {
      setTimeout(() => {
        if (node.isConnected && relativeNode.isConnected) {
          var relativeRect = getRect(relativeNode);
          var _getRect = getRect(node),
            height = _getRect.height,
            left = _getRect.left,
            top = _getRect.top,
            width = _getRect.width;
          var x = left - relativeRect.left;
          var y = top - relativeRect.top;
          callback(x, y, width, height, left, top);
        }
      }, 0);
    }
  };
  var elementsToIgnore = {
    A: true,
    BODY: true,
    INPUT: true,
    SELECT: true,
    TEXTAREA: true
  };
  var UIManager = {
    blur(node) {
      try {
        node.blur();
      } catch (err) {}
    },
    focus(node) {
      try {
        var name = node.nodeName;
        // A tabIndex of -1 allows element to be programmatically focused but
        // prevents keyboard focus. We don't want to set the tabindex value on
        // elements that should not prevent keyboard focus.
        if (node.getAttribute('tabIndex') == null && node.isContentEditable !== true && elementsToIgnore[name] == null) {
          node.setAttribute('tabIndex', '-1');
        }
        node.focus();
      } catch (err) {}
    },
    measure(node, callback) {
      measureLayout(node, null, callback);
    },
    measureInWindow(node, callback) {
      if (node) {
        setTimeout(() => {
          var _getBoundingClientRec = (0, getBoundingClientRect.default)(node),
            height = _getBoundingClientRec.height,
            left = _getBoundingClientRec.left,
            top = _getBoundingClientRec.top,
            width = _getBoundingClientRec.width;
          callback(left, top, width, height);
        }, 0);
      }
    },
    measureLayout(node, relativeToNativeNode, onFail, onSuccess) {
      measureLayout(node, relativeToNativeNode, onSuccess);
    },
    updateView(node, props) {
      for (var prop in props) {
        if (!Object.prototype.hasOwnProperty.call(props, prop)) {
          continue;
        }
        var value = props[prop];
        switch (prop) {
          case 'style':
            {
              (0, setValueForStyles.default)(node, value);
              break;
            }
          case 'class':
          case 'className':
            {
              node.setAttribute('class', value);
              break;
            }
          case 'text':
          case 'value':
            // native platforms use `text` prop to replace text input value
            node.value = value;
            break;
          default:
            node.setAttribute(prop, value);
        }
      }
    },
    configureNextLayoutAnimation(config, onAnimationDidEnd) {
      onAnimationDidEnd();
    },
    // mocks
    setLayoutAnimationEnabledExperimental() {}
  };
  var _default = UIManager;
},182,[183,184],"node_modules/react-native-web/dist/exports/UIManager/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var getBoundingClientRect = node => {
    if (node != null) {
      var isElement = node.nodeType === 1; /* Node.ELEMENT_NODE */
      if (isElement && typeof node.getBoundingClientRect === 'function') {
        return node.getBoundingClientRect();
      }
    }
  };
  var _default = getBoundingClientRect;
},183,[],"node_modules/react-native-web/dist/modules/getBoundingClientRect/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _dangerousStyleValue = require(_dependencyMap[0], "./dangerousStyleValue");
  var dangerousStyleValue = _interopDefault(_dangerousStyleValue);
  /* eslint-disable */

  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * From React 16.3.0
   * 
   */

  /**
   * Sets the value for multiple styles on a node.  If a value is specified as
   * '' (empty string), the corresponding style property will be unset.
   *
   * @param {DOMElement} node
   * @param {object} styles
   */
  function setValueForStyles(node, styles) {
    var style = node.style;
    for (var styleName in styles) {
      if (!styles.hasOwnProperty(styleName)) {
        continue;
      }
      var isCustomProperty = styleName.indexOf('--') === 0;
      var styleValue = (0, dangerousStyleValue.default)(styleName, styles[styleName], isCustomProperty);
      if (styleName === 'float') {
        styleName = 'cssFloat';
      }
      if (isCustomProperty) {
        style.setProperty(styleName, styleValue);
      } else {
        style[styleName] = styleValue;
      }
    }
  }
  var _default = setValueForStyles;
},184,[185],"node_modules/react-native-web/dist/modules/setValueForStyles/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _unitlessNumbers = require(_dependencyMap[0], "../unitlessNumbers");
  var isUnitlessNumber = _interopDefault(_unitlessNumbers);
  /* eslint-disable */

  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * From React 16.0.0
   * 
   */

  /**
   * Convert a value into the proper css writable value. The style name `name`
   * should be logical (no hyphens), as specified
   * in `CSSProperty.isUnitlessNumber`.
   *
   * @param {string} name CSS property name such as `topMargin`.
   * @param {*} value CSS property value such as `10px`.
   * @return {string} Normalized style value with dimensions applied.
   */
  function dangerousStyleValue(name, value, isCustomProperty) {
    // Note that we've removed escapeTextForBrowser() calls here since the
    // whole string will be escaped when the attribute is injected into
    // the markup. If you provide unsafe user data here they can inject
    // arbitrary CSS which may be problematic (I couldn't repro this):
    // https://www.owasp.org/index.php/XSS_Filter_Evasion_Cheat_Sheet
    // http://www.thespanner.co.uk/2007/11/26/ultimate-xss-css-injection/
    // This is not an XSS hole but instead a potential CSS injection issue
    // which has lead to a greater discussion about how we're going to
    // trust URLs moving forward. See #2115901

    var isEmpty = value == null || typeof value === 'boolean' || value === '';
    if (isEmpty) {
      return '';
    }
    if (!isCustomProperty && typeof value === 'number' && value !== 0 && !(isUnitlessNumber.default.hasOwnProperty(name) && isUnitlessNumber.default[name])) {
      return value + 'px'; // Presumes implicit 'px' suffix for unitless numbers
    }
    return ('' + value).trim();
  }
  var _default = dangerousStyleValue;
},185,[186],"node_modules/react-native-web/dist/modules/setValueForStyles/dangerousStyleValue.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var unitlessNumbers = {
    animationIterationCount: true,
    aspectRatio: true,
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    boxFlex: true,
    boxFlexGroup: true,
    boxOrdinalGroup: true,
    columnCount: true,
    flex: true,
    flexGrow: true,
    flexOrder: true,
    flexPositive: true,
    flexShrink: true,
    flexNegative: true,
    fontWeight: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowGap: true,
    gridRowStart: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnGap: true,
    gridColumnStart: true,
    lineClamp: true,
    opacity: true,
    order: true,
    orphans: true,
    tabSize: true,
    widows: true,
    zIndex: true,
    zoom: true,
    // SVG-related
    fillOpacity: true,
    floodOpacity: true,
    stopOpacity: true,
    strokeDasharray: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true,
    // transform types
    scale: true,
    scaleX: true,
    scaleY: true,
    scaleZ: true,
    // RN properties
    shadowOpacity: true
  };

  /**
   * Support style names that may come passed in prefixed by adding permutations
   * of vendor prefixes.
   */
  var prefixes = ['ms', 'Moz', 'O', 'Webkit'];
  var prefixKey = (prefix, key) => {
    return prefix + key.charAt(0).toUpperCase() + key.substring(1);
  };
  Object.keys(unitlessNumbers).forEach(prop => {
    prefixes.forEach(prefix => {
      unitlessNumbers[prefixKey(prefix, prop)] = unitlessNumbers[prop];
    });
  });
  var _default = unitlessNumbers;
},186,[],"node_modules/react-native-web/dist/modules/unitlessNumbers/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return useMergeRefs;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _mergeRefs = require(_dependencyMap[1], "../mergeRefs");
  var mergeRefs = _interopDefault(_mergeRefs);
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  function useMergeRefs() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return React.useMemo(() => (0, mergeRefs.default)(...args),
    // eslint-disable-next-line
    [...args]);
  }
},187,[62,188],"node_modules/react-native-web/dist/modules/useMergeRefs/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return mergeRefs;
    }
  });
  require(_dependencyMap[0], "react");
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  function mergeRefs() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return function forwardRef(node) {
      args.forEach(ref => {
        if (ref == null) {
          return;
        }
        if (typeof ref === 'function') {
          ref(node);
          return;
        }
        if (typeof ref === 'object') {
          ref.current = node;
          return;
        }
        console.error("mergeRefs cannot handle Refs of type boolean, number or string, received ref " + String(ref));
      });
    };
  }
},188,[62],"node_modules/react-native-web/dist/modules/mergeRefs/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return usePlatformMethods;
    }
  });
  var _exportsUIManager = require(_dependencyMap[0], "../../exports/UIManager");
  var UIManager = _interopDefault(_exportsUIManager);
  var _useStable = require(_dependencyMap[1], "../useStable");
  var useStable = _interopDefault(_useStable);
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  /**
   * Adds non-standard methods to the hode element. This is temporarily until an
   * API like `ReactNative.measure(hostRef, callback)` is added to React Native.
   */
  function usePlatformMethods(_ref) {
    var pointerEvents = _ref.pointerEvents,
      style = _ref.style;
    // Avoid creating a new ref on every render.
    var ref = (0, useStable.default)(() => hostNode => {
      if (hostNode != null) {
        hostNode.measure = callback => UIManager.default.measure(hostNode, callback);
        hostNode.measureLayout = (relativeToNode, success, failure) => UIManager.default.measureLayout(hostNode, relativeToNode, failure, success);
        hostNode.measureInWindow = callback => UIManager.default.measureInWindow(hostNode, callback);
      }
    });
    return ref;
  }
},189,[182,190],"node_modules/react-native-web/dist/modules/usePlatformMethods/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return useStable;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var UNINITIALIZED = typeof Symbol === 'function' && typeof Symbol() === 'symbol' ? Symbol() : Object.freeze({});
  function useStable(getInitialValue) {
    var ref = React.useRef(UNINITIALIZED);
    if (ref.current === UNINITIALIZED) {
      ref.current = getInitialValue();
    }
    // $FlowFixMe (#64650789) Trouble refining types where `Symbol` is concerned.
    return ref.current;
  }
},190,[62],"node_modules/react-native-web/dist/modules/useStable/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return useResponderEvents;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _ResponderSystem = require(_dependencyMap[1], "./ResponderSystem");
  var ResponderSystem = _interopNamespace(_ResponderSystem);
  /**
   * Copyright (c) Nicolas Gallagher
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  /**
   * Hook for integrating the Responder System into React
   *
   *   function SomeComponent({ onStartShouldSetResponder }) {
   *     const ref = useRef(null);
   *     useResponderEvents(ref, { onStartShouldSetResponder });
   *     return <div ref={ref} />
   *   }
   */

  var emptyObject = {};
  var idCounter = 0;
  function useStable(getInitialValue) {
    var ref = React.useRef(null);
    if (ref.current == null) {
      ref.current = getInitialValue();
    }
    return ref.current;
  }
  function useResponderEvents(hostRef, config) {
    if (config === void 0) {
      config = emptyObject;
    }
    var id = useStable(() => idCounter++);
    var isAttachedRef = React.useRef(false);

    // This is a separate effects so it doesn't run when the config changes.
    // On initial mount, attach global listeners if needed.
    // On unmount, remove node potentially attached to the Responder System.
    React.useEffect(() => {
      ResponderSystem.attachListeners();
      return () => {
        ResponderSystem.removeNode(id);
      };
    }, [id]);

    // Register and unregister with the Responder System as necessary
    React.useEffect(() => {
      var _config = config,
        onMoveShouldSetResponder = _config.onMoveShouldSetResponder,
        onMoveShouldSetResponderCapture = _config.onMoveShouldSetResponderCapture,
        onScrollShouldSetResponder = _config.onScrollShouldSetResponder,
        onScrollShouldSetResponderCapture = _config.onScrollShouldSetResponderCapture,
        onSelectionChangeShouldSetResponder = _config.onSelectionChangeShouldSetResponder,
        onSelectionChangeShouldSetResponderCapture = _config.onSelectionChangeShouldSetResponderCapture,
        onStartShouldSetResponder = _config.onStartShouldSetResponder,
        onStartShouldSetResponderCapture = _config.onStartShouldSetResponderCapture;
      var requiresResponderSystem = onMoveShouldSetResponder != null || onMoveShouldSetResponderCapture != null || onScrollShouldSetResponder != null || onScrollShouldSetResponderCapture != null || onSelectionChangeShouldSetResponder != null || onSelectionChangeShouldSetResponderCapture != null || onStartShouldSetResponder != null || onStartShouldSetResponderCapture != null;
      var node = hostRef.current;
      if (requiresResponderSystem) {
        ResponderSystem.addNode(id, node, config);
        isAttachedRef.current = true;
      } else if (isAttachedRef.current) {
        ResponderSystem.removeNode(id);
        isAttachedRef.current = false;
      }
    }, [config, hostRef, id]);
    React.useDebugValue({
      isResponder: hostRef.current === ResponderSystem.getResponderNode()
    });
    React.useDebugValue(config);
  }
},191,[62,192],"node_modules/react-native-web/dist/modules/useResponderEvents/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.attachListeners = attachListeners;
  exports.addNode = addNode;
  exports.removeNode = removeNode;
  exports.terminateResponder = terminateResponder;
  exports.getResponderNode = getResponderNode;
  var _createResponderEvent = require(_dependencyMap[0], "./createResponderEvent");
  var createResponderEvent = _interopDefault(_createResponderEvent);
  var _ResponderEventTypes = require(_dependencyMap[1], "./ResponderEventTypes");
  var _utils = require(_dependencyMap[2], "./utils");
  var _ResponderTouchHistoryStore = require(_dependencyMap[3], "./ResponderTouchHistoryStore");
  var _canUseDom = require(_dependencyMap[4], "../canUseDom");
  var canUseDOM = _interopDefault(_canUseDom);
  /**
   * Copyright (c) Nicolas Gallagher
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  /**
   * RESPONDER EVENT SYSTEM
   *
   * A single, global "interaction lock" on views. For a view to be the "responder" means
   * that pointer interactions are exclusive to that view and none other. The "interaction
   * lock" can be transferred (only) to ancestors of the current "responder" as long as
   * pointers continue to be active.
   *
   * Responder being granted:
   *
   * A view can become the "responder" after the following events:
   *  * "pointerdown" (implemented using "touchstart", "mousedown")
   *  * "pointermove" (implemented using "touchmove", "mousemove")
   *  * "scroll" (while a pointer is down)
   *  * "selectionchange" (while a pointer is down)
   *
   * If nothing is already the "responder", the event propagates to (capture) and from
   * (bubble) the event target until a view returns `true` for
   * `on*ShouldSetResponder(Capture)`.
   *
   * If something is already the responder, the event propagates to (capture) and from
   * (bubble) the lowest common ancestor of the event target and the current "responder".
   * Then negotiation happens between the current "responder" and a view that wants to
   * become the "responder": see the timing diagram below.
   *
   * (NOTE: Scrolled views either automatically become the "responder" or release the
   * "interaction lock". A native scroll view that isn't built on top of the responder
   * system must result in the current "responder" being notified that it no longer has
   * the "interaction lock" - the native system has taken over.
   *
   * Responder being released:
   *
   * As soon as there are no more active pointers that *started* inside descendants
   * of the *current* "responder", an `onResponderRelease` event is dispatched to the
   * current "responder", and the responder lock is released.
   *
   * Typical sequence of events:
   *  * startShouldSetResponder
   *  * responderGrant/Reject
   *  * responderStart
   *  * responderMove
   *  * responderEnd
   *  * responderRelease
   */

  /*                                             Negotiation Performed
                                               +-----------------------+
                                              /                         \
  Process low level events to    +     Current Responder      +   wantsResponderID
  determine who to perform negot-|   (if any exists at all)   |
  iation/transition              | Otherwise just pass through|
  -------------------------------+----------------------------+------------------+
  Bubble to find first ID        |                            |
  to return true:wantsResponderID|                            |
                                 |                            |
       +--------------+          |                            |
       | onTouchStart |          |                            |
       +------+-------+    none  |                            |
              |            return|                            |
  +-----------v-------------+true| +------------------------+ |
  |onStartShouldSetResponder|----->| onResponderStart (cur) |<-----------+
  +-----------+-------------+    | +------------------------+ |          |
              |                  |                            | +--------+-------+
              | returned true for|       false:REJECT +-------->|onResponderReject
              | wantsResponderID |                    |       | +----------------+
              | (now attempt     | +------------------+-----+ |
              |  handoff)        | | onResponder            | |
              +------------------->|    TerminationRequest  | |
                                 | +------------------+-----+ |
                                 |                    |       | +----------------+
                                 |         true:GRANT +-------->|onResponderGrant|
                                 |                            | +--------+-------+
                                 | +------------------------+ |          |
                                 | | onResponderTerminate   |<-----------+
                                 | +------------------+-----+ |
                                 |                    |       | +----------------+
                                 |                    +-------->|onResponderStart|
                                 |                            | +----------------+
  Bubble to find first ID        |                            |
  to return true:wantsResponderID|                            |
                                 |                            |
       +-------------+           |                            |
       | onTouchMove |           |                            |
       +------+------+     none  |                            |
              |            return|                            |
  +-----------v-------------+true| +------------------------+ |
  |onMoveShouldSetResponder |----->| onResponderMove (cur)  |<-----------+
  +-----------+-------------+    | +------------------------+ |          |
              |                  |                            | +--------+-------+
              | returned true for|       false:REJECT +-------->|onResponderReject
              | wantsResponderID |                    |       | +----------------+
              | (now attempt     | +------------------+-----+ |
              |  handoff)        | |   onResponder          | |
              +------------------->|      TerminationRequest| |
                                 | +------------------+-----+ |
                                 |                    |       | +----------------+
                                 |         true:GRANT +-------->|onResponderGrant|
                                 |                            | +--------+-------+
                                 | +------------------------+ |          |
                                 | |   onResponderTerminate |<-----------+
                                 | +------------------+-----+ |
                                 |                    |       | +----------------+
                                 |                    +-------->|onResponderMove |
                                 |                            | +----------------+
                                 |                            |
                                 |                            |
        Some active touch started|                            |
        inside current responder | +------------------------+ |
        +------------------------->|      onResponderEnd    | |
        |                        | +------------------------+ |
    +---+---------+              |                            |
    | onTouchEnd  |              |                            |
    +---+---------+              |                            |
        |                        | +------------------------+ |
        +------------------------->|     onResponderEnd     | |
        No active touches started| +-----------+------------+ |
        inside current responder |             |              |
                                 |             v              |
                                 | +------------------------+ |
                                 | |    onResponderRelease  | |
                                 | +------------------------+ |
                                 |                            |
                                 +                            + */

  /* ------------ TYPES ------------ */

  var emptyObject = {};

  /* ------------ IMPLEMENTATION ------------ */

  var startRegistration = ['onStartShouldSetResponderCapture', 'onStartShouldSetResponder', {
    bubbles: true
  }];
  var moveRegistration = ['onMoveShouldSetResponderCapture', 'onMoveShouldSetResponder', {
    bubbles: true
  }];
  var scrollRegistration = ['onScrollShouldSetResponderCapture', 'onScrollShouldSetResponder', {
    bubbles: false
  }];
  var shouldSetResponderEvents = {
    touchstart: startRegistration,
    mousedown: startRegistration,
    touchmove: moveRegistration,
    mousemove: moveRegistration,
    scroll: scrollRegistration
  };
  var emptyResponder = {
    id: null,
    idPath: null,
    node: null
  };
  var responderListenersMap = new Map();
  var isEmulatingMouseEvents = false;
  var trackedTouchCount = 0;
  var currentResponder = {
    id: null,
    node: null,
    idPath: null
  };
  var responderTouchHistoryStore = new _ResponderTouchHistoryStore.ResponderTouchHistoryStore();
  function changeCurrentResponder(responder) {
    currentResponder = responder;
  }
  function getResponderConfig(id) {
    var config = responderListenersMap.get(id);
    return config != null ? config : emptyObject;
  }

  /**
   * Process native events
   *
   * A single event listener is used to manage the responder system.
   * All pointers are tracked in the ResponderTouchHistoryStore. Native events
   * are interpreted in terms of the Responder System and checked to see if
   * the responder should be transferred. Each host node that is attached to
   * the Responder System has an ID, which is used to look up its associated
   * callbacks.
   */
  function eventListener(domEvent) {
    var eventType = domEvent.type;
    var eventTarget = domEvent.target;

    /**
     * Manage emulated events and early bailout.
     * Since PointerEvent is not used yet (lack of support in older Safari), it's
     * necessary to manually manage the mess of browser touch/mouse events.
     * And bailout early for termination events when there is no active responder.
     */

    // Flag when browser may produce emulated events
    if (eventType === 'touchstart') {
      isEmulatingMouseEvents = true;
    }
    // Remove flag when browser will not produce emulated events
    if (eventType === 'touchmove' || trackedTouchCount > 1) {
      isEmulatingMouseEvents = false;
    }
    // Ignore various events in particular circumstances
    if (
    // Ignore browser emulated mouse events
    eventType === 'mousedown' && isEmulatingMouseEvents || eventType === 'mousemove' && isEmulatingMouseEvents ||
    // Ignore mousemove if a mousedown didn't occur first
    eventType === 'mousemove' && trackedTouchCount < 1) {
      return;
    }
    // Remove flag after emulated events are finished
    if (isEmulatingMouseEvents && eventType === 'mouseup') {
      if (trackedTouchCount === 0) {
        isEmulatingMouseEvents = false;
      }
      return;
    }
    var isStartEvent = (0, _ResponderEventTypes.isStartish)(eventType) && (0, _utils.isPrimaryPointerDown)(domEvent);
    var isMoveEvent = (0, _ResponderEventTypes.isMoveish)(eventType);
    var isEndEvent = (0, _ResponderEventTypes.isEndish)(eventType);
    var isScrollEvent = (0, _ResponderEventTypes.isScroll)(eventType);
    var isSelectionChangeEvent = (0, _ResponderEventTypes.isSelectionChange)(eventType);
    var responderEvent = (0, createResponderEvent.default)(domEvent, responderTouchHistoryStore);

    /**
     * Record the state of active pointers
     */

    if (isStartEvent || isMoveEvent || isEndEvent) {
      if (domEvent.touches) {
        trackedTouchCount = domEvent.touches.length;
      } else {
        if (isStartEvent) {
          trackedTouchCount = 1;
        } else if (isEndEvent) {
          trackedTouchCount = 0;
        }
      }
      responderTouchHistoryStore.recordTouchTrack(eventType, responderEvent.nativeEvent);
    }

    /**
     * Responder System logic
     */

    var eventPaths = (0, _utils.getResponderPaths)(domEvent);
    var wasNegotiated = false;
    var wantsResponder;

    // If an event occured that might change the current responder...
    if (isStartEvent || isMoveEvent || isScrollEvent && trackedTouchCount > 0) {
      // If there is already a responder, prune the event paths to the lowest common ancestor
      // of the existing responder and deepest target of the event.
      var currentResponderIdPath = currentResponder.idPath;
      var eventIdPath = eventPaths.idPath;
      if (currentResponderIdPath != null && eventIdPath != null) {
        var lowestCommonAncestor = (0, _utils.getLowestCommonAncestor)(currentResponderIdPath, eventIdPath);
        if (lowestCommonAncestor != null) {
          var indexOfLowestCommonAncestor = eventIdPath.indexOf(lowestCommonAncestor);
          // Skip the current responder so it doesn't receive unexpected "shouldSet" events.
          var index = indexOfLowestCommonAncestor + (lowestCommonAncestor === currentResponder.id ? 1 : 0);
          eventPaths = {
            idPath: eventIdPath.slice(index),
            nodePath: eventPaths.nodePath.slice(index)
          };
        } else {
          eventPaths = null;
        }
      }
      if (eventPaths != null) {
        // If a node wants to become the responder, attempt to transfer.
        wantsResponder = findWantsResponder(eventPaths, domEvent, responderEvent);
        if (wantsResponder != null) {
          // Sets responder if none exists, or negotates with existing responder.
          attemptTransfer(responderEvent, wantsResponder);
          wasNegotiated = true;
        }
      }
    }

    // If there is now a responder, invoke its callbacks for the lifecycle of the gesture.
    if (currentResponder.id != null && currentResponder.node != null) {
      var _currentResponder = currentResponder,
        id = _currentResponder.id,
        node = _currentResponder.node;
      var _getResponderConfig = getResponderConfig(id),
        onResponderStart = _getResponderConfig.onResponderStart,
        onResponderMove = _getResponderConfig.onResponderMove,
        onResponderEnd = _getResponderConfig.onResponderEnd,
        onResponderRelease = _getResponderConfig.onResponderRelease,
        onResponderTerminate = _getResponderConfig.onResponderTerminate,
        onResponderTerminationRequest = _getResponderConfig.onResponderTerminationRequest;
      responderEvent.bubbles = false;
      responderEvent.cancelable = false;
      responderEvent.currentTarget = node;

      // Start
      if (isStartEvent) {
        if (onResponderStart != null) {
          responderEvent.dispatchConfig.registrationName = 'onResponderStart';
          onResponderStart(responderEvent);
        }
      }
      // Move
      else if (isMoveEvent) {
        if (onResponderMove != null) {
          responderEvent.dispatchConfig.registrationName = 'onResponderMove';
          onResponderMove(responderEvent);
        }
      } else {
        var isTerminateEvent = (0, _ResponderEventTypes.isCancelish)(eventType) ||
        // native context menu
        eventType === 'contextmenu' ||
        // window blur
        eventType === 'blur' && eventTarget === window ||
        // responder (or ancestors) blur
        eventType === 'blur' && eventTarget.contains(node) && domEvent.relatedTarget !== node ||
        // native scroll without using a pointer
        isScrollEvent && trackedTouchCount === 0 ||
        // native scroll on node that is parent of the responder (allow siblings to scroll)
        isScrollEvent && eventTarget.contains(node) && eventTarget !== node ||
        // native select/selectionchange on node
        isSelectionChangeEvent && (0, _utils.hasValidSelection)(domEvent);
        var isReleaseEvent = isEndEvent && !isTerminateEvent && !(0, _utils.hasTargetTouches)(node, domEvent.touches);

        // End
        if (isEndEvent) {
          if (onResponderEnd != null) {
            responderEvent.dispatchConfig.registrationName = 'onResponderEnd';
            onResponderEnd(responderEvent);
          }
        }
        // Release
        if (isReleaseEvent) {
          if (onResponderRelease != null) {
            responderEvent.dispatchConfig.registrationName = 'onResponderRelease';
            onResponderRelease(responderEvent);
          }
          changeCurrentResponder(emptyResponder);
        }
        // Terminate
        if (isTerminateEvent) {
          var shouldTerminate = true;

          // Responders can still avoid termination but only for these events.
          if (eventType === 'contextmenu' || eventType === 'scroll' || eventType === 'selectionchange') {
            // Only call this function is it wasn't already called during negotiation.
            if (wasNegotiated) {
              shouldTerminate = false;
            } else if (onResponderTerminationRequest != null) {
              responderEvent.dispatchConfig.registrationName = 'onResponderTerminationRequest';
              if (onResponderTerminationRequest(responderEvent) === false) {
                shouldTerminate = false;
              }
            }
          }
          if (shouldTerminate) {
            if (onResponderTerminate != null) {
              responderEvent.dispatchConfig.registrationName = 'onResponderTerminate';
              onResponderTerminate(responderEvent);
            }
            changeCurrentResponder(emptyResponder);
            isEmulatingMouseEvents = false;
            trackedTouchCount = 0;
          }
        }
      }
    }
  }

  /**
   * Walk the event path to/from the target node. At each node, stop and call the
   * relevant "shouldSet" functions for the given event type. If any of those functions
   * call "stopPropagation" on the event, stop searching for a responder.
   */
  function findWantsResponder(eventPaths, domEvent, responderEvent) {
    var shouldSetCallbacks = shouldSetResponderEvents[domEvent.type]; // for Flow

    if (shouldSetCallbacks != null) {
      var idPath = eventPaths.idPath,
        nodePath = eventPaths.nodePath;
      var shouldSetCallbackCaptureName = shouldSetCallbacks[0];
      var shouldSetCallbackBubbleName = shouldSetCallbacks[1];
      var bubbles = shouldSetCallbacks[2].bubbles;
      var check = function check(id, node, callbackName) {
        var config = getResponderConfig(id);
        var shouldSetCallback = config[callbackName];
        if (shouldSetCallback != null) {
          responderEvent.currentTarget = node;
          if (shouldSetCallback(responderEvent) === true) {
            // Start the path from the potential responder
            var prunedIdPath = idPath.slice(idPath.indexOf(id));
            return {
              id,
              node,
              idPath: prunedIdPath
            };
          }
        }
      };

      // capture
      for (var i = idPath.length - 1; i >= 0; i--) {
        var id = idPath[i];
        var node = nodePath[i];
        var result = check(id, node, shouldSetCallbackCaptureName);
        if (result != null) {
          return result;
        }
        if (responderEvent.isPropagationStopped() === true) {
          return;
        }
      }

      // bubble
      if (bubbles) {
        for (var _i = 0; _i < idPath.length; _i++) {
          var _id = idPath[_i];
          var _node = nodePath[_i];
          var _result = check(_id, _node, shouldSetCallbackBubbleName);
          if (_result != null) {
            return _result;
          }
          if (responderEvent.isPropagationStopped() === true) {
            return;
          }
        }
      } else {
        var _id2 = idPath[0];
        var _node2 = nodePath[0];
        var target = domEvent.target;
        if (target === _node2) {
          return check(_id2, _node2, shouldSetCallbackBubbleName);
        }
      }
    }
  }

  /**
   * Attempt to transfer the responder.
   */
  function attemptTransfer(responderEvent, wantsResponder) {
    var _currentResponder2 = currentResponder,
      currentId = _currentResponder2.id,
      currentNode = _currentResponder2.node;
    var id = wantsResponder.id,
      node = wantsResponder.node;
    var _getResponderConfig2 = getResponderConfig(id),
      onResponderGrant = _getResponderConfig2.onResponderGrant,
      onResponderReject = _getResponderConfig2.onResponderReject;
    responderEvent.bubbles = false;
    responderEvent.cancelable = false;
    responderEvent.currentTarget = node;

    // Set responder
    if (currentId == null) {
      if (onResponderGrant != null) {
        responderEvent.currentTarget = node;
        responderEvent.dispatchConfig.registrationName = 'onResponderGrant';
        onResponderGrant(responderEvent);
      }
      changeCurrentResponder(wantsResponder);
    }
    // Negotiate with current responder
    else {
      var _getResponderConfig3 = getResponderConfig(currentId),
        onResponderTerminate = _getResponderConfig3.onResponderTerminate,
        onResponderTerminationRequest = _getResponderConfig3.onResponderTerminationRequest;
      var allowTransfer = true;
      if (onResponderTerminationRequest != null) {
        responderEvent.currentTarget = currentNode;
        responderEvent.dispatchConfig.registrationName = 'onResponderTerminationRequest';
        if (onResponderTerminationRequest(responderEvent) === false) {
          allowTransfer = false;
        }
      }
      if (allowTransfer) {
        // Terminate existing responder
        if (onResponderTerminate != null) {
          responderEvent.currentTarget = currentNode;
          responderEvent.dispatchConfig.registrationName = 'onResponderTerminate';
          onResponderTerminate(responderEvent);
        }
        // Grant next responder
        if (onResponderGrant != null) {
          responderEvent.currentTarget = node;
          responderEvent.dispatchConfig.registrationName = 'onResponderGrant';
          onResponderGrant(responderEvent);
        }
        changeCurrentResponder(wantsResponder);
      } else {
        // Reject responder request
        if (onResponderReject != null) {
          responderEvent.currentTarget = node;
          responderEvent.dispatchConfig.registrationName = 'onResponderReject';
          onResponderReject(responderEvent);
        }
      }
    }
  }

  /* ------------ PUBLIC API ------------ */

  /**
   * Attach Listeners
   *
   * Use native events as ReactDOM doesn't have a non-plugin API to implement
   * this system.
   */
  var documentEventsCapturePhase = ['blur', 'scroll'];
  var documentEventsBubblePhase = [
  // mouse
  'mousedown', 'mousemove', 'mouseup', 'dragstart',
  // touch
  'touchstart', 'touchmove', 'touchend', 'touchcancel',
  // other
  'contextmenu', 'select', 'selectionchange'];
  function attachListeners() {
    if (canUseDOM.default && window.__reactResponderSystemActive == null) {
      window.addEventListener('blur', eventListener);
      documentEventsBubblePhase.forEach(eventType => {
        document.addEventListener(eventType, eventListener);
      });
      documentEventsCapturePhase.forEach(eventType => {
        document.addEventListener(eventType, eventListener, true);
      });
      window.__reactResponderSystemActive = true;
    }
  }

  /**
   * Register a node with the ResponderSystem.
   */
  function addNode(id, node, config) {
    (0, _utils.setResponderId)(node, id);
    responderListenersMap.set(id, config);
  }

  /**
   * Unregister a node with the ResponderSystem.
   */
  function removeNode(id) {
    if (currentResponder.id === id) {
      terminateResponder();
    }
    if (responderListenersMap.has(id)) {
      responderListenersMap.delete(id);
    }
  }

  /**
   * Allow the current responder to be terminated from within components to support
   * more complex requirements, such as use with other React libraries for working
   * with scroll views, input views, etc.
   */
  function terminateResponder() {
    var _currentResponder3 = currentResponder,
      id = _currentResponder3.id,
      node = _currentResponder3.node;
    if (id != null && node != null) {
      var _getResponderConfig4 = getResponderConfig(id),
        onResponderTerminate = _getResponderConfig4.onResponderTerminate;
      if (onResponderTerminate != null) {
        var event = (0, createResponderEvent.default)({}, responderTouchHistoryStore);
        event.currentTarget = node;
        onResponderTerminate(event);
      }
      changeCurrentResponder(emptyResponder);
    }
    isEmulatingMouseEvents = false;
    trackedTouchCount = 0;
  }

  /**
   * Allow unit tests to inspect the current responder in the system.
   * FOR TESTING ONLY.
   */
  function getResponderNode() {
    return currentResponder.node;
  }
},192,[193,194,195,197,67],"node_modules/react-native-web/dist/modules/useResponderEvents/ResponderSystem.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return createResponderEvent;
    }
  });
  var _modulesGetBoundingClientRect = require(_dependencyMap[0], "../../modules/getBoundingClientRect");
  var getBoundingClientRect = _interopDefault(_modulesGetBoundingClientRect);
  /**
   * Copyright (c) Nicolas Gallagher
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var emptyFunction = () => {};
  var emptyObject = {};
  var emptyArray = [];

  /**
   * Safari produces very large identifiers that would cause the `touchBank` array
   * length to be so large as to crash the browser, if not normalized like this.
   * In the future the `touchBank` should use an object/map instead.
   */
  function normalizeIdentifier(identifier) {
    return identifier > 20 ? identifier % 20 : identifier;
  }

  /**
   * Converts a native DOM event to a ResponderEvent.
   * Mouse events are transformed into fake touch events.
   */
  function createResponderEvent(domEvent, responderTouchHistoryStore) {
    var rect;
    var propagationWasStopped = false;
    var changedTouches;
    var touches;
    var domEventChangedTouches = domEvent.changedTouches;
    var domEventType = domEvent.type;
    var metaKey = domEvent.metaKey === true;
    var shiftKey = domEvent.shiftKey === true;
    var force = domEventChangedTouches && domEventChangedTouches[0].force || 0;
    var identifier = normalizeIdentifier(domEventChangedTouches && domEventChangedTouches[0].identifier || 0);
    var clientX = domEventChangedTouches && domEventChangedTouches[0].clientX || domEvent.clientX;
    var clientY = domEventChangedTouches && domEventChangedTouches[0].clientY || domEvent.clientY;
    var pageX = domEventChangedTouches && domEventChangedTouches[0].pageX || domEvent.pageX;
    var pageY = domEventChangedTouches && domEventChangedTouches[0].pageY || domEvent.pageY;
    var preventDefault = typeof domEvent.preventDefault === 'function' ? domEvent.preventDefault.bind(domEvent) : emptyFunction;
    var timestamp = domEvent.timeStamp;
    function normalizeTouches(touches) {
      return Array.prototype.slice.call(touches).map(touch => {
        return {
          force: touch.force,
          identifier: normalizeIdentifier(touch.identifier),
          get locationX() {
            return locationX(touch.clientX);
          },
          get locationY() {
            return locationY(touch.clientY);
          },
          pageX: touch.pageX,
          pageY: touch.pageY,
          target: touch.target,
          timestamp
        };
      });
    }
    if (domEventChangedTouches != null) {
      changedTouches = normalizeTouches(domEventChangedTouches);
      touches = normalizeTouches(domEvent.touches);
    } else {
      var emulatedTouches = [{
        force,
        identifier,
        get locationX() {
          return locationX(clientX);
        },
        get locationY() {
          return locationY(clientY);
        },
        pageX,
        pageY,
        target: domEvent.target,
        timestamp
      }];
      changedTouches = emulatedTouches;
      touches = domEventType === 'mouseup' || domEventType === 'dragstart' ? emptyArray : emulatedTouches;
    }
    var responderEvent = {
      bubbles: true,
      cancelable: true,
      // `currentTarget` is set before dispatch
      currentTarget: null,
      defaultPrevented: domEvent.defaultPrevented,
      dispatchConfig: emptyObject,
      eventPhase: domEvent.eventPhase,
      isDefaultPrevented() {
        return domEvent.defaultPrevented;
      },
      isPropagationStopped() {
        return propagationWasStopped;
      },
      isTrusted: domEvent.isTrusted,
      nativeEvent: {
        altKey: false,
        ctrlKey: false,
        metaKey,
        shiftKey,
        changedTouches,
        force,
        identifier,
        get locationX() {
          return locationX(clientX);
        },
        get locationY() {
          return locationY(clientY);
        },
        pageX,
        pageY,
        target: domEvent.target,
        timestamp,
        touches,
        type: domEventType
      },
      persist: emptyFunction,
      preventDefault,
      stopPropagation() {
        propagationWasStopped = true;
      },
      target: domEvent.target,
      timeStamp: timestamp,
      touchHistory: responderTouchHistoryStore.touchHistory
    };

    // Using getters and functions serves two purposes:
    // 1) The value of `currentTarget` is not initially available.
    // 2) Measuring the clientRect may cause layout jank and should only be done on-demand.
    function locationX(x) {
      rect = rect || (0, getBoundingClientRect.default)(responderEvent.currentTarget);
      if (rect) {
        return x - rect.left;
      }
    }
    function locationY(y) {
      rect = rect || (0, getBoundingClientRect.default)(responderEvent.currentTarget);
      if (rect) {
        return y - rect.top;
      }
    }
    return responderEvent;
  }
},193,[183],"node_modules/react-native-web/dist/modules/useResponderEvents/createResponderEvent.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "BLUR", {
    enumerable: true,
    get: function () {
      return BLUR;
    }
  });
  Object.defineProperty(exports, "CONTEXT_MENU", {
    enumerable: true,
    get: function () {
      return CONTEXT_MENU;
    }
  });
  Object.defineProperty(exports, "FOCUS_OUT", {
    enumerable: true,
    get: function () {
      return FOCUS_OUT;
    }
  });
  Object.defineProperty(exports, "MOUSE_DOWN", {
    enumerable: true,
    get: function () {
      return MOUSE_DOWN;
    }
  });
  Object.defineProperty(exports, "MOUSE_MOVE", {
    enumerable: true,
    get: function () {
      return MOUSE_MOVE;
    }
  });
  Object.defineProperty(exports, "MOUSE_UP", {
    enumerable: true,
    get: function () {
      return MOUSE_UP;
    }
  });
  Object.defineProperty(exports, "MOUSE_CANCEL", {
    enumerable: true,
    get: function () {
      return MOUSE_CANCEL;
    }
  });
  Object.defineProperty(exports, "TOUCH_START", {
    enumerable: true,
    get: function () {
      return TOUCH_START;
    }
  });
  Object.defineProperty(exports, "TOUCH_MOVE", {
    enumerable: true,
    get: function () {
      return TOUCH_MOVE;
    }
  });
  Object.defineProperty(exports, "TOUCH_END", {
    enumerable: true,
    get: function () {
      return TOUCH_END;
    }
  });
  Object.defineProperty(exports, "TOUCH_CANCEL", {
    enumerable: true,
    get: function () {
      return TOUCH_CANCEL;
    }
  });
  Object.defineProperty(exports, "SCROLL", {
    enumerable: true,
    get: function () {
      return SCROLL;
    }
  });
  Object.defineProperty(exports, "SELECT", {
    enumerable: true,
    get: function () {
      return SELECT;
    }
  });
  Object.defineProperty(exports, "SELECTION_CHANGE", {
    enumerable: true,
    get: function () {
      return SELECTION_CHANGE;
    }
  });
  exports.isStartish = isStartish;
  exports.isMoveish = isMoveish;
  exports.isEndish = isEndish;
  exports.isCancelish = isCancelish;
  exports.isScroll = isScroll;
  exports.isSelectionChange = isSelectionChange;
  /**
   * Copyright (c) Nicolas Gallagher
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var BLUR = 'blur';
  var CONTEXT_MENU = 'contextmenu';
  var FOCUS_OUT = 'focusout';
  var MOUSE_DOWN = 'mousedown';
  var MOUSE_MOVE = 'mousemove';
  var MOUSE_UP = 'mouseup';
  var MOUSE_CANCEL = 'dragstart';
  var TOUCH_START = 'touchstart';
  var TOUCH_MOVE = 'touchmove';
  var TOUCH_END = 'touchend';
  var TOUCH_CANCEL = 'touchcancel';
  var SCROLL = 'scroll';
  var SELECT = 'select';
  var SELECTION_CHANGE = 'selectionchange';
  function isStartish(eventType) {
    return eventType === TOUCH_START || eventType === MOUSE_DOWN;
  }
  function isMoveish(eventType) {
    return eventType === TOUCH_MOVE || eventType === MOUSE_MOVE;
  }
  function isEndish(eventType) {
    return eventType === TOUCH_END || eventType === MOUSE_UP || isCancelish(eventType);
  }
  function isCancelish(eventType) {
    return eventType === TOUCH_CANCEL || eventType === MOUSE_CANCEL;
  }
  function isScroll(eventType) {
    return eventType === SCROLL;
  }
  function isSelectionChange(eventType) {
    return eventType === SELECT || eventType === SELECTION_CHANGE;
  }
},194,[],"node_modules/react-native-web/dist/modules/useResponderEvents/ResponderEventTypes.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.setResponderId = setResponderId;
  exports.getResponderPaths = getResponderPaths;
  exports.getLowestCommonAncestor = getLowestCommonAncestor;
  exports.hasTargetTouches = hasTargetTouches;
  exports.hasValidSelection = hasValidSelection;
  exports.isPrimaryPointerDown = isPrimaryPointerDown;
  var _modulesIsSelectionValid = require(_dependencyMap[0], "../../modules/isSelectionValid");
  var isSelectionValid = _interopDefault(_modulesIsSelectionValid);
  /**
   * Copyright (c) Nicolas Gallagher
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var keyName = '__reactResponderId';
  function getEventPath(domEvent) {
    // The 'selectionchange' event always has the 'document' as the target.
    // Use the anchor node as the initial target to reconstruct a path.
    // (We actually only need the first "responder" node in practice.)
    if (domEvent.type === 'selectionchange') {
      var target = window.getSelection().anchorNode;
      return composedPathFallback(target);
    } else {
      var path = domEvent.composedPath != null ? domEvent.composedPath() : composedPathFallback(domEvent.target);
      return path;
    }
  }
  function composedPathFallback(target) {
    var path = [];
    while (target != null && target !== document.body) {
      path.push(target);
      target = target.parentNode;
    }
    return path;
  }

  /**
   * Retrieve the responderId from a host node
   */
  function getResponderId(node) {
    if (node != null) {
      return node[keyName];
    }
    return null;
  }

  /**
   * Store the responderId on a host node
   */
  function setResponderId(node, id) {
    if (node != null) {
      node[keyName] = id;
    }
  }

  /**
   * Filter the event path to contain only the nodes attached to the responder system
   */
  function getResponderPaths(domEvent) {
    var idPath = [];
    var nodePath = [];
    var eventPath = getEventPath(domEvent);
    for (var i = 0; i < eventPath.length; i++) {
      var node = eventPath[i];
      var id = getResponderId(node);
      if (id != null) {
        idPath.push(id);
        nodePath.push(node);
      }
    }
    return {
      idPath,
      nodePath
    };
  }

  /**
   * Walk the paths and find the first common ancestor
   */
  function getLowestCommonAncestor(pathA, pathB) {
    var pathALength = pathA.length;
    var pathBLength = pathB.length;
    if (
    // If either path is empty
    pathALength === 0 || pathBLength === 0 ||
    // If the last elements aren't the same there can't be a common ancestor
    // that is connected to the responder system
    pathA[pathALength - 1] !== pathB[pathBLength - 1]) {
      return null;
    }
    var itemA = pathA[0];
    var indexA = 0;
    var itemB = pathB[0];
    var indexB = 0;

    // If A is deeper, skip indices that can't match.
    if (pathALength - pathBLength > 0) {
      indexA = pathALength - pathBLength;
      itemA = pathA[indexA];
      pathALength = pathBLength;
    }

    // If B is deeper, skip indices that can't match
    if (pathBLength - pathALength > 0) {
      indexB = pathBLength - pathALength;
      itemB = pathB[indexB];
      pathBLength = pathALength;
    }

    // Walk in lockstep until a match is found
    var depth = pathALength;
    while (depth--) {
      if (itemA === itemB) {
        return itemA;
      }
      itemA = pathA[indexA++];
      itemB = pathB[indexB++];
    }
    return null;
  }

  /**
   * Determine whether any of the active touches are within the current responder.
   * This cannot rely on W3C `targetTouches`, as neither IE11 nor Safari implement it.
   */
  function hasTargetTouches(target, touches) {
    if (!touches || touches.length === 0) {
      return false;
    }
    for (var i = 0; i < touches.length; i++) {
      var node = touches[i].target;
      if (node != null) {
        if (target.contains(node)) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Ignore 'selectionchange' events that don't correspond with a person's intent to
   * select text.
   */
  function hasValidSelection(domEvent) {
    if (domEvent.type === 'selectionchange') {
      return (0, isSelectionValid.default)();
    }
    return domEvent.type === 'select';
  }

  /**
   * Events are only valid if the primary button was used without specific modifier keys.
   */
  function isPrimaryPointerDown(domEvent) {
    var altKey = domEvent.altKey,
      button = domEvent.button,
      buttons = domEvent.buttons,
      ctrlKey = domEvent.ctrlKey,
      type = domEvent.type;
    var isTouch = type === 'touchstart' || type === 'touchmove';
    var isPrimaryMouseDown = type === 'mousedown' && (button === 0 || buttons === 1);
    var isPrimaryMouseMove = type === 'mousemove' && buttons === 1;
    var noModifiers = altKey === false && ctrlKey === false;
    if (isTouch || isPrimaryMouseDown && noModifiers || isPrimaryMouseMove && noModifiers) {
      return true;
    }
    return false;
  }
},195,[196],"node_modules/react-native-web/dist/modules/useResponderEvents/utils.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return isSelectionValid;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  function isSelectionValid() {
    var selection = window.getSelection();
    var string = selection.toString();
    var anchorNode = selection.anchorNode;
    var focusNode = selection.focusNode;
    var isTextNode = anchorNode && anchorNode.nodeType === window.Node.TEXT_NODE || focusNode && focusNode.nodeType === window.Node.TEXT_NODE;
    return string.length >= 1 && string !== '\n' && isTextNode;
  }
},196,[],"node_modules/react-native-web/dist/modules/isSelectionValid/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "ResponderTouchHistoryStore", {
    enumerable: true,
    get: function () {
      return ResponderTouchHistoryStore;
    }
  });
  var _ResponderEventTypes = require(_dependencyMap[0], "./ResponderEventTypes");
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  /**
   * Tracks the position and time of each active touch by `touch.identifier`. We
   * should typically only see IDs in the range of 1-20 because IDs get recycled
   * when touches end and start again.
   */

  var __DEV__ = process.env.NODE_ENV !== 'production';
  var MAX_TOUCH_BANK = 20;
  function timestampForTouch(touch) {
    // The legacy internal implementation provides "timeStamp", which has been
    // renamed to "timestamp".
    return touch.timeStamp || touch.timestamp;
  }

  /**
   * TODO: Instead of making gestures recompute filtered velocity, we could
   * include a built in velocity computation that can be reused globally.
   */
  function createTouchRecord(touch) {
    return {
      touchActive: true,
      startPageX: touch.pageX,
      startPageY: touch.pageY,
      startTimeStamp: timestampForTouch(touch),
      currentPageX: touch.pageX,
      currentPageY: touch.pageY,
      currentTimeStamp: timestampForTouch(touch),
      previousPageX: touch.pageX,
      previousPageY: touch.pageY,
      previousTimeStamp: timestampForTouch(touch)
    };
  }
  function resetTouchRecord(touchRecord, touch) {
    touchRecord.touchActive = true;
    touchRecord.startPageX = touch.pageX;
    touchRecord.startPageY = touch.pageY;
    touchRecord.startTimeStamp = timestampForTouch(touch);
    touchRecord.currentPageX = touch.pageX;
    touchRecord.currentPageY = touch.pageY;
    touchRecord.currentTimeStamp = timestampForTouch(touch);
    touchRecord.previousPageX = touch.pageX;
    touchRecord.previousPageY = touch.pageY;
    touchRecord.previousTimeStamp = timestampForTouch(touch);
  }
  function getTouchIdentifier(_ref) {
    var identifier = _ref.identifier;
    if (identifier == null) {
      console.error('Touch object is missing identifier.');
    }
    if (__DEV__) {
      if (identifier > MAX_TOUCH_BANK) {
        console.error('Touch identifier %s is greater than maximum supported %s which causes ' + 'performance issues backfilling array locations for all of the indices.', identifier, MAX_TOUCH_BANK);
      }
    }
    return identifier;
  }
  function recordTouchStart(touch, touchHistory) {
    var identifier = getTouchIdentifier(touch);
    var touchRecord = touchHistory.touchBank[identifier];
    if (touchRecord) {
      resetTouchRecord(touchRecord, touch);
    } else {
      touchHistory.touchBank[identifier] = createTouchRecord(touch);
    }
    touchHistory.mostRecentTimeStamp = timestampForTouch(touch);
  }
  function recordTouchMove(touch, touchHistory) {
    var touchRecord = touchHistory.touchBank[getTouchIdentifier(touch)];
    if (touchRecord) {
      touchRecord.touchActive = true;
      touchRecord.previousPageX = touchRecord.currentPageX;
      touchRecord.previousPageY = touchRecord.currentPageY;
      touchRecord.previousTimeStamp = touchRecord.currentTimeStamp;
      touchRecord.currentPageX = touch.pageX;
      touchRecord.currentPageY = touch.pageY;
      touchRecord.currentTimeStamp = timestampForTouch(touch);
      touchHistory.mostRecentTimeStamp = timestampForTouch(touch);
    } else {
      console.warn('Cannot record touch move without a touch start.\n', "Touch Move: " + printTouch(touch) + "\n", "Touch Bank: " + printTouchBank(touchHistory));
    }
  }
  function recordTouchEnd(touch, touchHistory) {
    var touchRecord = touchHistory.touchBank[getTouchIdentifier(touch)];
    if (touchRecord) {
      touchRecord.touchActive = false;
      touchRecord.previousPageX = touchRecord.currentPageX;
      touchRecord.previousPageY = touchRecord.currentPageY;
      touchRecord.previousTimeStamp = touchRecord.currentTimeStamp;
      touchRecord.currentPageX = touch.pageX;
      touchRecord.currentPageY = touch.pageY;
      touchRecord.currentTimeStamp = timestampForTouch(touch);
      touchHistory.mostRecentTimeStamp = timestampForTouch(touch);
    } else {
      console.warn('Cannot record touch end without a touch start.\n', "Touch End: " + printTouch(touch) + "\n", "Touch Bank: " + printTouchBank(touchHistory));
    }
  }
  function printTouch(touch) {
    return JSON.stringify({
      identifier: touch.identifier,
      pageX: touch.pageX,
      pageY: touch.pageY,
      timestamp: timestampForTouch(touch)
    });
  }
  function printTouchBank(touchHistory) {
    var touchBank = touchHistory.touchBank;
    var printed = JSON.stringify(touchBank.slice(0, MAX_TOUCH_BANK));
    if (touchBank.length > MAX_TOUCH_BANK) {
      printed += ' (original size: ' + touchBank.length + ')';
    }
    return printed;
  }
  class ResponderTouchHistoryStore {
    constructor() {
      this._touchHistory = {
        touchBank: [],
        //Array<TouchRecord>
        numberActiveTouches: 0,
        // If there is only one active touch, we remember its location. This prevents
        // us having to loop through all of the touches all the time in the most
        // common case.
        indexOfSingleActiveTouch: -1,
        mostRecentTimeStamp: 0
      };
    }
    recordTouchTrack(topLevelType, nativeEvent) {
      var touchHistory = this._touchHistory;
      if ((0, _ResponderEventTypes.isMoveish)(topLevelType)) {
        nativeEvent.changedTouches.forEach(touch => recordTouchMove(touch, touchHistory));
      } else if ((0, _ResponderEventTypes.isStartish)(topLevelType)) {
        nativeEvent.changedTouches.forEach(touch => recordTouchStart(touch, touchHistory));
        touchHistory.numberActiveTouches = nativeEvent.touches.length;
        if (touchHistory.numberActiveTouches === 1) {
          touchHistory.indexOfSingleActiveTouch = nativeEvent.touches[0].identifier;
        }
      } else if ((0, _ResponderEventTypes.isEndish)(topLevelType)) {
        nativeEvent.changedTouches.forEach(touch => recordTouchEnd(touch, touchHistory));
        touchHistory.numberActiveTouches = nativeEvent.touches.length;
        if (touchHistory.numberActiveTouches === 1) {
          var touchBank = touchHistory.touchBank;
          for (var i = 0; i < touchBank.length; i++) {
            var touchTrackToCheck = touchBank[i];
            if (touchTrackToCheck != null && touchTrackToCheck.touchActive) {
              touchHistory.indexOfSingleActiveTouch = i;
              break;
            }
          }
          if (__DEV__) {
            var activeRecord = touchBank[touchHistory.indexOfSingleActiveTouch];
            if (!(activeRecord != null && activeRecord.touchActive)) {
              console.error('Cannot find single active touch.');
            }
          }
        }
      }
    }
    get touchHistory() {
      return this._touchHistory;
    }
  }
},197,[194],"node_modules/react-native-web/dist/modules/useResponderEvents/ResponderTouchHistoryStore.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var TextAncestorContext = /*#__PURE__*/(0, _react.createContext)(false);
  var _default = TextAncestorContext;
},198,[62],"node_modules/react-native-web/dist/exports/Text/TextAncestorContext.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _babelRuntimeHelpersObjectSpread = require(_dependencyMap[0], "@babel/runtime/helpers/objectSpread2");
  var _objectSpread = _interopDefault(_babelRuntimeHelpersObjectSpread);
  var _babelRuntimeHelpersExtends = require(_dependencyMap[1], "@babel/runtime/helpers/extends");
  var _extends = _interopDefault(_babelRuntimeHelpersExtends);
  var _babelRuntimeHelpersObjectWithoutPropertiesLoose = require(_dependencyMap[2], "@babel/runtime/helpers/objectWithoutPropertiesLoose");
  var _objectWithoutPropertiesLoose = _interopDefault(_babelRuntimeHelpersObjectWithoutPropertiesLoose);
  var _react = require(_dependencyMap[3], "react");
  var React = _interopNamespace(_react);
  var _createElement = require(_dependencyMap[4], "../createElement");
  var createElement = _interopDefault(_createElement);
  var _modulesAssetRegistry = require(_dependencyMap[5], "../../modules/AssetRegistry");
  var _StyleSheetPreprocess = require(_dependencyMap[6], "../StyleSheet/preprocess");
  var _modulesImageLoader = require(_dependencyMap[7], "../../modules/ImageLoader");
  var ImageLoader = _interopDefault(_modulesImageLoader);
  var _PixelRatio = require(_dependencyMap[8], "../PixelRatio");
  var PixelRatio = _interopDefault(_PixelRatio);
  var _StyleSheet = require(_dependencyMap[9], "../StyleSheet");
  var StyleSheet = _interopDefault(_StyleSheet);
  var _TextTextAncestorContext = require(_dependencyMap[10], "../Text/TextAncestorContext");
  var TextAncestorContext = _interopDefault(_TextTextAncestorContext);
  var _View = require(_dependencyMap[11], "../View");
  var View = _interopDefault(_View);
  var _modulesWarnOnce = require(_dependencyMap[12], "../../modules/warnOnce");
  var _excluded = ["aria-label", "accessibilityLabel", "blurRadius", "defaultSource", "draggable", "onError", "onLayout", "onLoad", "onLoadEnd", "onLoadStart", "pointerEvents", "source", "style"];
  var ERRORED = 'ERRORED';
  var LOADED = 'LOADED';
  var LOADING = 'LOADING';
  var IDLE = 'IDLE';
  var _filterId = 0;
  var svgDataUriPattern = /^(data:image\/svg\+xml;utf8,)(.*)/;
  function createTintColorSVG(tintColor, id) {
    return tintColor && id != null ? /*#__PURE__*/React.createElement("svg", {
      style: {
        position: 'absolute',
        height: 0,
        visibility: 'hidden',
        width: 0
      }
    }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("filter", {
      id: "tint-" + id,
      suppressHydrationWarning: true
    }, /*#__PURE__*/React.createElement("feFlood", {
      floodColor: "" + tintColor,
      key: tintColor
    }), /*#__PURE__*/React.createElement("feComposite", {
      in2: "SourceAlpha",
      operator: "in"
    })))) : null;
  }
  function extractNonStandardStyleProps(style, blurRadius, filterId, tintColorProp) {
    var flatStyle = StyleSheet.default.flatten(style);
    var filter = flatStyle.filter,
      resizeMode = flatStyle.resizeMode,
      shadowOffset = flatStyle.shadowOffset,
      tintColor = flatStyle.tintColor;
    if (flatStyle.resizeMode) {
      (0, _modulesWarnOnce.warnOnce)('Image.style.resizeMode', 'Image: style.resizeMode is deprecated. Please use props.resizeMode.');
    }
    if (flatStyle.tintColor) {
      (0, _modulesWarnOnce.warnOnce)('Image.style.tintColor', 'Image: style.tintColor is deprecated. Please use props.tintColor.');
    }

    // Add CSS filters
    // React Native exposes these features as props and proprietary styles
    var filters = [];
    var _filter = null;
    if (filter) {
      filters.push(filter);
    }
    if (blurRadius) {
      filters.push("blur(" + blurRadius + "px)");
    }
    if (shadowOffset) {
      var shadowString = (0, _StyleSheetPreprocess.createBoxShadowValue)(flatStyle);
      if (shadowString) {
        filters.push("drop-shadow(" + shadowString + ")");
      }
    }
    if ((tintColorProp || tintColor) && filterId != null) {
      filters.push("url(#tint-" + filterId + ")");
    }
    if (filters.length > 0) {
      _filter = filters.join(' ');
    }
    return [resizeMode, _filter, tintColor];
  }
  function resolveAssetDimensions(source) {
    if (typeof source === 'number') {
      var _getAssetByID = (0, _modulesAssetRegistry.getAssetByID)(source),
        _height = _getAssetByID.height,
        _width = _getAssetByID.width;
      return {
        height: _height,
        width: _width
      };
    } else if (source != null && !Array.isArray(source) && typeof source === 'object') {
      var _height2 = source.height,
        _width2 = source.width;
      return {
        height: _height2,
        width: _width2
      };
    }
  }
  function resolveAssetUri(source) {
    var uri = null;
    if (typeof source === 'number') {
      // get the URI from the packager
      var asset = (0, _modulesAssetRegistry.getAssetByID)(source);
      if (asset == null) {
        throw new Error("Image: asset with ID \"" + source + "\" could not be found. Please check the image source or packager.");
      }
      var scale = asset.scales[0];
      if (asset.scales.length > 1) {
        var preferredScale = PixelRatio.default.get();
        // Get the scale which is closest to the preferred scale
        scale = asset.scales.reduce((prev, curr) => Math.abs(curr - preferredScale) < Math.abs(prev - preferredScale) ? curr : prev);
      }
      var scaleSuffix = scale !== 1 ? "@" + scale + "x" : '';
      uri = asset ? asset.httpServerLocation + "/" + asset.name + scaleSuffix + "." + asset.type : '';
    } else if (typeof source === 'string') {
      uri = source;
    } else if (source && typeof source.uri === 'string') {
      uri = source.uri;
    }
    if (uri) {
      var match = uri.match(svgDataUriPattern);
      // inline SVG markup may contain characters (e.g., #, ") that need to be escaped
      if (match) {
        var prefix = match[1],
          svg = match[2];
        var encodedSvg = encodeURIComponent(svg);
        return "" + prefix + encodedSvg;
      }
    }
    return uri;
  }
  var Image = /*#__PURE__*/React.forwardRef((props, ref) => {
    var _ariaLabel = props['aria-label'],
      accessibilityLabel = props.accessibilityLabel,
      blurRadius = props.blurRadius,
      defaultSource = props.defaultSource,
      draggable = props.draggable,
      onError = props.onError,
      onLayout = props.onLayout,
      onLoad = props.onLoad,
      onLoadEnd = props.onLoadEnd,
      onLoadStart = props.onLoadStart,
      pointerEvents = props.pointerEvents,
      source = props.source,
      style = props.style,
      rest = (0, _objectWithoutPropertiesLoose.default)(props, _excluded);
    var ariaLabel = _ariaLabel || accessibilityLabel;
    if (process.env.NODE_ENV !== 'production') {
      if (props.children) {
        throw new Error('The <Image> component cannot contain children. If you want to render content on top of the image, consider using the <ImageBackground> component or absolute positioning.');
      }
    }
    var _React$useState = React.useState(() => {
        var uri = resolveAssetUri(source);
        if (uri != null) {
          var isLoaded = ImageLoader.default.has(uri);
          if (isLoaded) {
            return LOADED;
          }
        }
        return IDLE;
      }),
      state = _React$useState[0],
      updateState = _React$useState[1];
    var _React$useState2 = React.useState({}),
      layout = _React$useState2[0],
      updateLayout = _React$useState2[1];
    var hasTextAncestor = React.useContext(TextAncestorContext.default);
    var hiddenImageRef = React.useRef(null);
    var filterRef = React.useRef(_filterId++);
    var requestRef = React.useRef(null);
    var shouldDisplaySource = state === LOADED || state === LOADING && defaultSource == null;
    var _extractNonStandardSt = extractNonStandardStyleProps(style, blurRadius, filterRef.current, props.tintColor),
      _resizeMode = _extractNonStandardSt[0],
      filter = _extractNonStandardSt[1],
      _tintColor = _extractNonStandardSt[2];
    var resizeMode = props.resizeMode || _resizeMode || 'cover';
    var tintColor = props.tintColor || _tintColor;
    var selectedSource = shouldDisplaySource ? source : defaultSource;
    var displayImageUri = resolveAssetUri(selectedSource);
    var imageSizeStyle = resolveAssetDimensions(selectedSource);
    var backgroundImage = displayImageUri ? "url(\"" + displayImageUri + "\")" : null;
    var backgroundSize = getBackgroundSize();

    // Accessibility image allows users to trigger the browser's image context menu
    var hiddenImage = displayImageUri ? (0, createElement.default)('img', {
      alt: ariaLabel || '',
      style: styles.accessibilityImage$raw,
      draggable: draggable || false,
      ref: hiddenImageRef,
      src: displayImageUri
    }) : null;
    function getBackgroundSize() {
      if (hiddenImageRef.current != null && (resizeMode === 'center' || resizeMode === 'repeat')) {
        var _hiddenImageRef$curre = hiddenImageRef.current,
          naturalHeight = _hiddenImageRef$curre.naturalHeight,
          naturalWidth = _hiddenImageRef$curre.naturalWidth;
        var _height3 = layout.height,
          _width3 = layout.width;
        if (naturalHeight && naturalWidth && _height3 && _width3) {
          var scaleFactor = Math.min(1, _width3 / naturalWidth, _height3 / naturalHeight);
          var x = Math.ceil(scaleFactor * naturalWidth);
          var y = Math.ceil(scaleFactor * naturalHeight);
          return x + "px " + y + "px";
        }
      }
    }
    function handleLayout(e) {
      if (resizeMode === 'center' || resizeMode === 'repeat' || onLayout) {
        var _layout = e.nativeEvent.layout;
        onLayout && onLayout(e);
        updateLayout(_layout);
      }
    }

    // Image loading
    var uri = resolveAssetUri(source);
    React.useEffect(() => {
      abortPendingRequest();
      if (uri != null) {
        updateState(LOADING);
        if (onLoadStart) {
          onLoadStart();
        }
        requestRef.current = ImageLoader.default.load(uri, function load(e) {
          updateState(LOADED);
          if (onLoad) {
            onLoad(e);
          }
          if (onLoadEnd) {
            onLoadEnd();
          }
        }, function error() {
          updateState(ERRORED);
          if (onError) {
            onError({
              nativeEvent: {
                error: "Failed to load resource " + uri
              }
            });
          }
          if (onLoadEnd) {
            onLoadEnd();
          }
        });
      }
      function abortPendingRequest() {
        if (requestRef.current != null) {
          ImageLoader.default.abort(requestRef.current);
          requestRef.current = null;
        }
      }
      return abortPendingRequest;
    }, [uri, requestRef, updateState, onError, onLoad, onLoadEnd, onLoadStart]);
    return /*#__PURE__*/React.createElement(View.default, (0, _extends.default)({}, rest, {
      "aria-label": ariaLabel,
      onLayout: handleLayout,
      pointerEvents: pointerEvents,
      ref: ref,
      style: [styles.root, hasTextAncestor && styles.inline, imageSizeStyle, style, styles.undo,
      // TEMP: avoid deprecated shadow props regression
      // until Image refactored to use createElement.
      {
        boxShadow: null
      }]
    }), /*#__PURE__*/React.createElement(View.default, {
      style: [styles.image, resizeModeStyles[resizeMode], {
        backgroundImage,
        filter
      }, backgroundSize != null && {
        backgroundSize
      }],
      suppressHydrationWarning: true
    }), hiddenImage, createTintColorSVG(tintColor, filterRef.current));
  });
  Image.displayName = 'Image';

  // $FlowIgnore: This is the correct type, but casting makes it unhappy since the variables aren't defined yet
  var ImageWithStatics = Image;
  ImageWithStatics.getSize = function (uri, success, failure) {
    ImageLoader.default.getSize(uri, success, failure);
  };
  ImageWithStatics.prefetch = function (uri) {
    return ImageLoader.default.prefetch(uri);
  };
  ImageWithStatics.queryCache = function (uris) {
    return ImageLoader.default.queryCache(uris);
  };
  var styles = StyleSheet.default.create({
    root: {
      flexBasis: 'auto',
      overflow: 'hidden',
      zIndex: 0
    },
    inline: {
      display: 'inline-flex'
    },
    undo: {
      // These styles are converted to CSS filters applied to the
      // element displaying the background image.
      blurRadius: null,
      shadowColor: null,
      shadowOpacity: null,
      shadowOffset: null,
      shadowRadius: null,
      tintColor: null,
      // These styles are not supported
      overlayColor: null,
      resizeMode: null
    },
    image: (0, _objectSpread.default)((0, _objectSpread.default)({}, StyleSheet.default.absoluteFillObject), {}, {
      backgroundColor: 'transparent',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat',
      backgroundSize: 'cover',
      height: '100%',
      width: '100%',
      zIndex: -1
    }),
    accessibilityImage$raw: (0, _objectSpread.default)((0, _objectSpread.default)({}, StyleSheet.default.absoluteFillObject), {}, {
      height: '100%',
      opacity: 0,
      width: '100%',
      zIndex: -1
    })
  });
  var resizeModeStyles = StyleSheet.default.create({
    center: {
      backgroundSize: 'auto'
    },
    contain: {
      backgroundSize: 'contain'
    },
    cover: {
      backgroundSize: 'cover'
    },
    none: {
      backgroundPosition: '0',
      backgroundSize: 'auto'
    },
    repeat: {
      backgroundPosition: '0',
      backgroundRepeat: 'repeat',
      backgroundSize: 'auto'
    },
    stretch: {
      backgroundSize: '100% 100%'
    }
  });
  var _default = ImageWithStatics;
},203,[47,55,71,62,170,204,114,205,206,70,198,169,115],"node_modules/react-native-web/dist/exports/Image/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const assets = [];
  module.exports = {
    registerAsset: s => assets.push(s),
    getAssetByID: s => assets[s - 1]
  };
},204,[],"\u0000polyfill:assets-registry");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  Object.defineProperty(exports, "ImageUriCache", {
    enumerable: true,
    get: function () {
      return ImageUriCache;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var dataUriPattern = /^data:/;
  class ImageUriCache {
    static has(uri) {
      var entries = ImageUriCache._entries;
      var isDataUri = dataUriPattern.test(uri);
      return isDataUri || Boolean(entries[uri]);
    }
    static add(uri) {
      var entries = ImageUriCache._entries;
      var lastUsedTimestamp = Date.now();
      if (entries[uri]) {
        entries[uri].lastUsedTimestamp = lastUsedTimestamp;
        entries[uri].refCount += 1;
      } else {
        entries[uri] = {
          lastUsedTimestamp,
          refCount: 1
        };
      }
    }
    static remove(uri) {
      var entries = ImageUriCache._entries;
      if (entries[uri]) {
        entries[uri].refCount -= 1;
      }
      // Free up entries when the cache is "full"
      ImageUriCache._cleanUpIfNeeded();
    }
    static _cleanUpIfNeeded() {
      var entries = ImageUriCache._entries;
      var imageUris = Object.keys(entries);
      if (imageUris.length + 1 > ImageUriCache._maximumEntries) {
        var leastRecentlyUsedKey;
        var leastRecentlyUsedEntry;
        imageUris.forEach(uri => {
          var entry = entries[uri];
          if ((!leastRecentlyUsedEntry || entry.lastUsedTimestamp < leastRecentlyUsedEntry.lastUsedTimestamp) && entry.refCount === 0) {
            leastRecentlyUsedKey = uri;
            leastRecentlyUsedEntry = entry;
          }
        });
        if (leastRecentlyUsedKey) {
          delete entries[leastRecentlyUsedKey];
        }
      }
    }
  }
  ImageUriCache._maximumEntries = 256;
  ImageUriCache._entries = {};
  var id = 0;
  var requests = {};
  var ImageLoader = {
    abort(requestId) {
      var image = requests["" + requestId];
      if (image) {
        image.onerror = null;
        image.onload = null;
        image = null;
        delete requests["" + requestId];
      }
    },
    getSize(uri, success, failure) {
      var complete = false;
      var interval = setInterval(callback, 16);
      var requestId = ImageLoader.load(uri, callback, errorCallback);
      function callback() {
        var image = requests["" + requestId];
        if (image) {
          var naturalHeight = image.naturalHeight,
            naturalWidth = image.naturalWidth;
          if (naturalHeight && naturalWidth) {
            success(naturalWidth, naturalHeight);
            complete = true;
          }
        }
        if (complete) {
          ImageLoader.abort(requestId);
          clearInterval(interval);
        }
      }
      function errorCallback() {
        if (typeof failure === 'function') {
          failure();
        }
        ImageLoader.abort(requestId);
        clearInterval(interval);
      }
    },
    has(uri) {
      return ImageUriCache.has(uri);
    },
    load(uri, onLoad, onError) {
      id += 1;
      var image = new window.Image();
      image.onerror = onError;
      image.onload = e => {
        // avoid blocking the main thread
        var onDecode = () => onLoad({
          nativeEvent: e
        });
        if (typeof image.decode === 'function') {
          // Safari currently throws exceptions when decoding svgs.
          // We want to catch that error and allow the load handler
          // to be forwarded to the onLoad handler in this case
          image.decode().then(onDecode, onDecode);
        } else {
          setTimeout(onDecode, 0);
        }
      };
      image.src = uri;
      requests["" + id] = image;
      return id;
    },
    prefetch(uri) {
      return new Promise((resolve, reject) => {
        ImageLoader.load(uri, () => {
          // Add the uri to the cache so it can be immediately displayed when used
          // but also immediately remove it to correctly reflect that it has no active references
          ImageUriCache.add(uri);
          ImageUriCache.remove(uri);
          resolve();
        }, reject);
      });
    },
    queryCache(uris) {
      var result = {};
      uris.forEach(u => {
        if (ImageUriCache.has(u)) {
          result[u] = 'disk/memory';
        }
      });
      return Promise.resolve(result);
    }
  };
  var _default = ImageLoader;
},205,[],"node_modules/react-native-web/dist/modules/ImageLoader/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return PixelRatio;
    }
  });
  var _Dimensions = require(_dependencyMap[0], "../Dimensions");
  var Dimensions = _interopDefault(_Dimensions);
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  /**
   * PixelRatio gives access to the device pixel density.
   */
  class PixelRatio {
    /**
     * Returns the device pixel density.
     */
    static get() {
      return Dimensions.default.get('window').scale;
    }

    /**
     * No equivalent for Web
     */
    static getFontScale() {
      return Dimensions.default.get('window').fontScale || PixelRatio.get();
    }

    /**
     * Converts a layout size (dp) to pixel size (px).
     * Guaranteed to return an integer number.
     */
    static getPixelSizeForLayoutSize(layoutSize) {
      return Math.round(layoutSize * PixelRatio.get());
    }

    /**
     * Rounds a layout size (dp) to the nearest layout size that corresponds to
     * an integer number of pixels. For example, on a device with a PixelRatio
     * of 3, `PixelRatio.roundToNearestPixel(8.4) = 8.33`, which corresponds to
     * exactly (8.33 * 3) = 25 pixels.
     */
    static roundToNearestPixel(layoutSize) {
      var ratio = PixelRatio.get();
      return Math.round(layoutSize * ratio) / ratio;
    }
  }
},206,[207],"node_modules/react-native-web/dist/exports/PixelRatio/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return Dimensions;
    }
  });
  var _fbjsLibInvariant = require(_dependencyMap[0], "fbjs/lib/invariant");
  var invariant = _interopDefault(_fbjsLibInvariant);
  var _modulesCanUseDom = require(_dependencyMap[1], "../../modules/canUseDom");
  var canUseDOM = _interopDefault(_modulesCanUseDom);
  var dimensions = {
    window: {
      fontScale: 1,
      height: 0,
      scale: 1,
      width: 0
    },
    screen: {
      fontScale: 1,
      height: 0,
      scale: 1,
      width: 0
    }
  };
  var listeners = {};
  var shouldInit = canUseDOM.default;
  function update() {
    if (!canUseDOM.default) {
      return;
    }
    var win = window;
    var height;
    var width;

    /**
     * iOS does not update viewport dimensions on keyboard open/close.
     * window.visualViewport(https://developer.mozilla.org/en-US/docs/Web/API/VisualViewport)
     * is used instead of document.documentElement.clientHeight (which remains as a fallback)
     */
    if (win.visualViewport) {
      var visualViewport = win.visualViewport;
      /**
       * We are multiplying by scale because height and width from visual viewport
       * also react to pinch zoom, and become smaller when zoomed. But it is not desired
       * behaviour, since originally documentElement client height and width were used,
       * and they do not react to pinch zoom.
       */
      height = Math.round(visualViewport.height * visualViewport.scale);
      width = Math.round(visualViewport.width * visualViewport.scale);
    } else {
      var docEl = win.document.documentElement;
      height = docEl.clientHeight;
      width = docEl.clientWidth;
    }
    dimensions.window = {
      fontScale: 1,
      height,
      scale: win.devicePixelRatio || 1,
      width
    };
    dimensions.screen = {
      fontScale: 1,
      height: win.screen.height,
      scale: win.devicePixelRatio || 1,
      width: win.screen.width
    };
  }
  function handleResize() {
    update();
    if (Array.isArray(listeners['change'])) {
      listeners['change'].forEach(handler => handler(dimensions));
    }
  }
  class Dimensions {
    static get(dimension) {
      if (shouldInit) {
        shouldInit = false;
        update();
      }
      (0, invariant.default)(dimensions[dimension], "No dimension set for key " + dimension);
      return dimensions[dimension];
    }
    static set(initialDimensions) {
      if (initialDimensions) {
        if (canUseDOM.default) {
          (0, invariant.default)(false, 'Dimensions cannot be set in the browser');
        } else {
          if (initialDimensions.screen != null) {
            dimensions.screen = initialDimensions.screen;
          }
          if (initialDimensions.window != null) {
            dimensions.window = initialDimensions.window;
          }
        }
      }
    }
    static addEventListener(type, handler) {
      listeners[type] = listeners[type] || [];
      listeners[type].push(handler);
      return {
        remove: () => {
          this.removeEventListener(type, handler);
        }
      };
    }
    static removeEventListener(type, handler) {
      if (Array.isArray(listeners[type])) {
        listeners[type] = listeners[type].filter(_handler => _handler !== handler);
      }
    }
  }
  if (canUseDOM.default) {
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', handleResize, false);
    } else {
      window.addEventListener('resize', handleResize, false);
    }
  }
},207,[52,67],"node_modules/react-native-web/dist/exports/Dimensions/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  var _Updates = require(_dependencyMap[0], "./Updates");
  Object.keys(_Updates).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _Updates[k];
        }
      });
    }
  });
  var _UpdatesEmitter = require(_dependencyMap[1], "./UpdatesEmitter");
  Object.keys(_UpdatesEmitter).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _UpdatesEmitter[k];
        }
      });
    }
  });
  var _UpdatesTypes = require(_dependencyMap[2], "./Updates.types");
  Object.keys(_UpdatesTypes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _UpdatesTypes[k];
        }
      });
    }
  });
  var _UseUpdates = require(_dependencyMap[3], "./UseUpdates");
  Object.keys(_UseUpdates).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _UseUpdates[k];
        }
      });
    }
  });
  var _UseUpdatesTypes = require(_dependencyMap[4], "./UseUpdates.types");
  Object.keys(_UseUpdatesTypes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _UseUpdatesTypes[k];
        }
      });
    }
  });
  var _ExpoUpdatesModuleTypes = require(_dependencyMap[5], "./ExpoUpdatesModule.types");
  Object.keys(_ExpoUpdatesModuleTypes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _ExpoUpdatesModuleTypes[k];
        }
      });
    }
  });
},3720,[3724,3727,3726,3728,3730,3731],"node_modules/expo-updates/build/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "isEnabled", {
    enumerable: true,
    get: function () {
      return isEnabled;
    }
  });
  Object.defineProperty(exports, "updateId", {
    enumerable: true,
    get: function () {
      return updateId;
    }
  });
  Object.defineProperty(exports, "channel", {
    enumerable: true,
    get: function () {
      return channel;
    }
  });
  Object.defineProperty(exports, "runtimeVersion", {
    enumerable: true,
    get: function () {
      return runtimeVersion;
    }
  });
  Object.defineProperty(exports, "checkAutomatically", {
    enumerable: true,
    get: function () {
      return checkAutomatically;
    }
  });
  Object.defineProperty(exports, "localAssets", {
    enumerable: true,
    get: function () {
      return localAssets;
    }
  });
  Object.defineProperty(exports, "isEmergencyLaunch", {
    enumerable: true,
    get: function () {
      return isEmergencyLaunch;
    }
  });
  Object.defineProperty(exports, "emergencyLaunchReason", {
    enumerable: true,
    get: function () {
      return emergencyLaunchReason;
    }
  });
  Object.defineProperty(exports, "launchDuration", {
    enumerable: true,
    get: function () {
      return launchDuration;
    }
  });
  Object.defineProperty(exports, "isEmbeddedLaunch", {
    enumerable: true,
    get: function () {
      return isEmbeddedLaunch;
    }
  });
  Object.defineProperty(exports, "isUsingEmbeddedAssets", {
    enumerable: true,
    get: function () {
      return isUsingEmbeddedAssets;
    }
  });
  Object.defineProperty(exports, "manifest", {
    enumerable: true,
    get: function () {
      return manifest;
    }
  });
  Object.defineProperty(exports, "createdAt", {
    enumerable: true,
    get: function () {
      return createdAt;
    }
  });
  exports.reloadAsync = reloadAsync;
  exports.checkForUpdateAsync = checkForUpdateAsync;
  exports.getExtraParamsAsync = getExtraParamsAsync;
  exports.setExtraParamAsync = setExtraParamAsync;
  exports.readLogEntriesAsync = readLogEntriesAsync;
  exports.clearLogEntriesAsync = clearLogEntriesAsync;
  exports.fetchUpdateAsync = fetchUpdateAsync;
  exports.setUpdateURLAndRequestHeadersOverride = setUpdateURLAndRequestHeadersOverride;
  exports.setUpdateRequestHeadersOverride = setUpdateRequestHeadersOverride;
  exports.showReloadScreen = showReloadScreen;
  exports.hideReloadScreen = hideReloadScreen;
  var _expoModulesCore = require(_dependencyMap[0], "expo-modules-core");
  var _reactNativeWebDistExportsImage = require(_dependencyMap[1], "react-native-web/dist/exports/Image");
  var Image = _interopDefault(_reactNativeWebDistExportsImage);
  var _ExpoUpdates = require(_dependencyMap[2], "./ExpoUpdates");
  var ExpoUpdates = _interopDefault(_ExpoUpdates);
  var _UpdatesTypes = require(_dependencyMap[3], "./Updates.types");
  /**
   * Whether `expo-updates` is enabled. This may be false in a variety of cases including:
   * - enabled set to false in configuration
   * - missing or invalid URL in configuration
   * - missing runtime version or SDK version in configuration
   * - error accessing storage on device during initialization
   *
   * When false, the embedded update is loaded.
   */
  const isEnabled = !!ExpoUpdates.default.isEnabled;
  /**
   * The UUID that uniquely identifies the currently running update. The
   * UUID is represented in its canonical string form and will always use lowercase letters.
   * This value is `null` when running in a local development environment or any other environment where `expo-updates` is disabled.
   * @example
   * `"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"`
   */
  const updateId = ExpoUpdates.default.updateId && typeof ExpoUpdates.default.updateId === 'string' ? ExpoUpdates.default.updateId.toLowerCase() : null;
  /**
   * The channel name of the current build, if configured for use with EAS Update. `null` otherwise.
   *
   * Expo Go and development builds are not set to a specific channel and can run any updates compatible with their native runtime. Therefore, this value will always be `null` when running an update on Expo Go or a development build.
   */
  const channel = ExpoUpdates.default.channel ?? null;
  /**
   * The runtime version of the current build.
   */
  const runtimeVersion = ExpoUpdates.default.runtimeVersion ?? null;
  const _checkAutomaticallyMapNativeToJS = {
    ALWAYS: _UpdatesTypes.UpdatesCheckAutomaticallyValue.ON_LOAD,
    ERROR_RECOVERY_ONLY: _UpdatesTypes.UpdatesCheckAutomaticallyValue.ON_ERROR_RECOVERY,
    NEVER: _UpdatesTypes.UpdatesCheckAutomaticallyValue.NEVER,
    WIFI_ONLY: _UpdatesTypes.UpdatesCheckAutomaticallyValue.WIFI_ONLY
  };
  /**
   * Determines if and when `expo-updates` checks for and downloads updates automatically on startup.
   */
  const checkAutomatically = _checkAutomaticallyMapNativeToJS[ExpoUpdates.default.checkAutomatically] ?? null;
  // @docsMissing
  /**
   * @hidden
   */
  const localAssets = ExpoUpdates.default.localAssets ?? {};
  /**
   * `expo-updates` does its very best to always launch monotonically newer versions of your app so
   * you don't need to worry about backwards compatibility when you put out an update. In very rare
   * cases, it's possible that `expo-updates` may need to fall back to the update that's embedded in
   * the app binary, even after newer updates have been downloaded and run (an "emergency launch").
   * This boolean will be `true` if the app is launching under this fallback mechanism and `false`
   * otherwise. If you are concerned about backwards compatibility of future updates to your app, you
   * can use this constant to provide special behavior for this rare case.
   */
  const isEmergencyLaunch = ExpoUpdates.default.isEmergencyLaunch;
  /**
   * If `isEmergencyLaunch` is set to true, this will contain a string error message describing
   * what failed during initialization.
   */
  const emergencyLaunchReason = ExpoUpdates.default.emergencyLaunchReason;
  /**
   * Number of milliseconds it took to launch.
   */
  const launchDuration = ExpoUpdates.default.launchDuration;
  /**
   * This will be true if the currently running update is the one embedded in the build,
   * and not one downloaded from the updates server.
   */
  const isEmbeddedLaunch = ExpoUpdates.default.isEmbeddedLaunch || false;
  // @docsMissing
  /**
   * @hidden
   */
  const isUsingEmbeddedAssets = ExpoUpdates.default.isUsingEmbeddedAssets || false;
  /**
   * If `expo-updates` is enabled, this is the
   * [manifest](/versions/latest/sdk/constants/#manifest) (or
   * [classic manifest](/versions/latest/sdk/constants/#appmanifest))
   * object for the update that's currently running.
   *
   * In development mode, or any other environment in which `expo-updates` is disabled, this object is
   * empty.
   */
  const manifest = (ExpoUpdates.default.manifestString ? JSON.parse(ExpoUpdates.default.manifestString) : ExpoUpdates.default.manifest) ?? {};
  /**
   * If `expo-updates` is enabled, this is a `Date` object representing the creation time of the update that's currently running (whether it was embedded or downloaded at runtime).
   *
   * In development mode, or any other environment in which `expo-updates` is disabled, this value is
   * null.
   */
  const createdAt = ExpoUpdates.default.commitTime ? new Date(ExpoUpdates.default.commitTime) : null;
  /**
   * During non-expo development we block accessing the updates API methods on the JS side, but when developing in
   * Expo Go or a development client build, the controllers should have control over which API methods should
   * be allowed.
   */
  const shouldDeferToNativeForAPIMethodAvailabilityInDevelopment = !!ExpoUpdates.default.shouldDeferToNativeForAPIMethodAvailabilityInDevelopment;
  /**
   * Developer tool is set when a project is served by `expo start`.
   */
  const isUsingDeveloperTool = 'extra' in manifest ? !!manifest.extra?.expoGo?.developer?.tool : false;
  const manualUpdatesInstructions = 'To test usage of the expo-updates JS API in your app, make a release build with `npx expo run:ios --configuration Release` or ' + '`npx expo run:android --variant Release`.';
  function resolveImageSource(source) {
    if (typeof source === 'string') {
      return {
        url: source
      };
    }
    if (typeof source === 'number') {
      const resolved = Image.default.resolveAssetSource(source);
      if (resolved) {
        return {
          url: resolved.uri,
          width: resolved.width,
          height: resolved.height,
          scale: resolved.scale
        };
      }
      return null;
    }
    if (typeof source === 'object' && source !== null) {
      return source;
    }
    return null;
  }
  function resolveReloadScreenOptions(options) {
    if (!options.image) {
      return options;
    }
    const resolvedImage = resolveImageSource(options.image);
    return {
      ...options,
      image: resolvedImage || undefined
    };
  }
  /**
   * Instructs the app to reload using the most recently downloaded version. This is useful for
   * triggering a newly downloaded update to launch without the user needing to manually restart the
   * app.
   * Unlike `Expo.reloadAppAsync()` provided by the `expo` package,
   * this function not only reloads the app but also changes the loaded JavaScript bundle to that of the most recently downloaded update.
   *
   * It is not recommended to place any meaningful logic after a call to `await
   * Updates.reloadAsync()`. This is because the promise is resolved after verifying that the app can
   * be reloaded, and immediately before posting an asynchronous task to the main thread to actually
   * reload the app. It is unsafe to make any assumptions about whether any more JS code will be
   * executed after the `Updates.reloadAsync` method call resolves, since that depends on the OS and
   * the state of the native module and main threads.
   *
   * This method cannot be used in Expo Go or development mode, and the returned promise will be rejected if you
   * try to do so. It also rejects when `expo-updates` is not enabled.
   *
   * @return A promise that fulfills right before the reload instruction is sent to the JS runtime, or
   * rejects if it cannot find a reference to the JS runtime. If the promise is rejected in production
   * mode, it most likely means you have installed the module incorrectly. Double check you've
   * followed the installation instructions. In particular, on iOS ensure that you set the `bridge`
   * property on `EXUpdatesAppController` with a pointer to the `RCTBridge` you want to reload, and on
   * Android ensure you either call `UpdatesController.initialize` with the instance of
   * `ReactApplication` you want to reload, or call `UpdatesController.setReactNativeHost` with the
   * proper instance of `ReactNativeHost`.
   */
  async function reloadAsync(options) {
    if ((__DEV__ || isUsingDeveloperTool) && !shouldDeferToNativeForAPIMethodAvailabilityInDevelopment) {
      throw new _expoModulesCore.CodedError('ERR_UPDATES_DISABLED', `You cannot use the Updates module in development mode in a production app. ${manualUpdatesInstructions}`);
    }
    if (options?.reloadScreenOptions) {
      const resolvedOptions = resolveReloadScreenOptions(options.reloadScreenOptions);
      return await ExpoUpdates.default.reload(resolvedOptions);
    }
    await ExpoUpdates.default.reload(null);
  }
  /**
   * Checks the server to see if a newly deployed update to your project is available. Does not
   * actually download the update. This method cannot be used in development mode, and the returned
   * promise will be rejected if you try to do so.
   *
   * Checking for an update uses a device's bandwidth and battery life like any network call.
   * Additionally, updates served by Expo may be rate limited. A good rule of thumb to check for
   * updates judiciously is to check when the user launches or foregrounds the app. Avoid polling for
   * updates in a frequent loop.
   *
   * @return A promise that fulfills with an [`UpdateCheckResult`](#updatecheckresult) object.
   *
   * The promise rejects in Expo Go or if the app is in development mode, or if there is an unexpected error or
   * timeout communicating with the server. It also rejects when `expo-updates` is not enabled.
   */
  async function checkForUpdateAsync() {
    if ((__DEV__ || isUsingDeveloperTool) && !shouldDeferToNativeForAPIMethodAvailabilityInDevelopment) {
      throw new _expoModulesCore.CodedError('ERR_UPDATES_DISABLED', `You cannot check for updates in development mode. ${manualUpdatesInstructions}`);
    }
    const result = await ExpoUpdates.default.checkForUpdateAsync();
    if ('manifestString' in result) {
      const {
        manifestString,
        ...rest
      } = result;
      return {
        ...rest,
        manifest: JSON.parse(manifestString)
      };
    }
    return result;
  }
  /**
   * Retrieves the current extra params.
   *
   * This method cannot be used in Expo Go or development mode. It also rejects when `expo-updates` is not enabled.
   */
  async function getExtraParamsAsync() {
    return await ExpoUpdates.default.getExtraParamsAsync();
  }
  /**
   * Sets an extra param if value is non-null, otherwise unsets the param.
   * Extra params are sent as an [Expo Structured Field Value Dictionary](/technical-specs/expo-sfv-0/)
   * in the `Expo-Extra-Params` header of update requests. A compliant update server may use these params when selecting an update to serve.
   *
   * This method cannot be used in Expo Go or development mode. It also rejects when `expo-updates` is not enabled.
   */
  async function setExtraParamAsync(key, value) {
    return await ExpoUpdates.default.setExtraParamAsync(key, value ?? null);
  }
  /**
   * Retrieves the most recent `expo-updates` log entries.
   *
   * @param maxAge Sets the max age of retrieved log entries in milliseconds. Default to `3600000` ms (1 hour).
   *
   * @return A promise that fulfills with an array of [`UpdatesLogEntry`](#updateslogentry) objects;
   *
   * The promise rejects if there is an unexpected error in retrieving the logs.
   */
  async function readLogEntriesAsync(maxAge = 3600000) {
    return await ExpoUpdates.default.readLogEntriesAsync(maxAge);
  }
  /**
   * Clears existing `expo-updates` log entries.
   *
   * > For now, this operation does nothing on the client.  Once log persistence has been
   * > implemented, this operation will actually remove existing logs.
   *
   * @return A promise that fulfills if the clear operation was successful.
   *
   * The promise rejects if there is an unexpected error in clearing the logs.
   *
   */
  async function clearLogEntriesAsync() {
    await ExpoUpdates.default.clearLogEntriesAsync();
  }
  /**
   * Downloads the most recently deployed update to your project from server to the device's local
   * storage. This method cannot be used in development mode, and the returned promise will be
   * rejected if you try to do so.
   *
   > **Note:** [`reloadAsync()`](#updatesreloadasync) can be called after promise resolution to
   * reload the app using the most recently downloaded version. Otherwise, the update will be applied
   * on the next app cold start.
   *
   * @return A promise that fulfills with an [`UpdateFetchResult`](#updatefetchresult) object.
   *
   * The promise rejects in Expo Go or if the app is in development mode, or if there is an unexpected error or
   * timeout communicating with the server. It also rejects when `expo-updates` is not enabled.
   */
  async function fetchUpdateAsync() {
    if ((__DEV__ || isUsingDeveloperTool) && !shouldDeferToNativeForAPIMethodAvailabilityInDevelopment) {
      throw new _expoModulesCore.CodedError('ERR_UPDATES_DISABLED', `You cannot fetch updates in development mode. ${manualUpdatesInstructions}`);
    }
    const result = await ExpoUpdates.default.fetchUpdateAsync();
    if ('manifestString' in result) {
      const {
        manifestString,
        ...rest
      } = result;
      return {
        ...rest,
        manifest: JSON.parse(manifestString)
      };
    }
    return result;
  }
  /**
   * Overrides updates URL and reuqest headers in runtime from build time.
   * This method allows you to load specific updates from a URL that you provide.
   * Use this method at your own risk, as it may cause unexpected behavior.
   * Because of the risk, this method requires `disableAntiBrickingMeasures` to be set to `true` in the **app.json** file.
   * [Learn more about use cases and limitations](https://docs.expo.dev/eas-update/override/).
   * @experimental
   */
  function setUpdateURLAndRequestHeadersOverride(configOverride) {
    ExpoUpdates.default.setUpdateURLAndRequestHeadersOverride(configOverride);
  }
  /**
   * Overrides updates request headers in runtime from build time.
   * This method allows you to load specific updates with custom request headers.
   * Use this method at your own risk, as it may cause unexpected behavior.
   * [Learn more about use cases and limitations](https://docs.expo.dev/eas-update/override/).
   * @experimental
   */
  function setUpdateRequestHeadersOverride(requestHeaders) {
    ExpoUpdates.default.setUpdateRequestHeadersOverride(requestHeaders);
  }
  /**
   * Shows the reload screen with customizable appearance. This is primarily useful for testing
   * how the reload screen will appear to users during app reloads and is only available in
   * debug builds of the app. The reload screen can be hidden by calling `hideReloadScreen()`.
   *
   *
   * @param options Configuration options for customizing the reload screen appearance.
   *
   * @hidden exposed for testing
   * @example
   * ```ts
   * import * as Updates from 'expo-updates';
   *
   * // Show the reload screen with custom styling for testing
   * await Updates.showReloadScreen({
   *   reloadScreenOptions: {
   *     backgroundColor: '#1a1a1a',
   *     spinner: {
   *       color: '#ffffff'
   *     }
   *   }
   * });
   *
   * // Hide it after 3 seconds
   * setTimeout(async () => {
   *   await Updates.hideReloadScreen();
   * }, 3000);
   *
   * // Test with a custom image
   * await Updates.showReloadScreen({
   *   reloadScreenOptions: {
   *     backgroundColor: '#ffffff',
   *     image: require('./assets/loading.png'),
   *     imageResizeMode: 'contain'
   *   }
   * });
   * ```
   */
  async function showReloadScreen(options) {
    if (options?.reloadScreenOptions) {
      const resolvedOptions = resolveReloadScreenOptions(options.reloadScreenOptions);
      return ExpoUpdates.default.showReloadScreen(resolvedOptions);
    }
    return ExpoUpdates.default.showReloadScreen();
  }
  /**
   *
   * @hidden exposed for testing
   * @return A promise that resolves when the reload screen is hidden.
   */
  async function hideReloadScreen() {
    return ExpoUpdates.default.hideReloadScreen();
  }
},3724,[131,203,3725,3726],"node_modules/expo-updates/build/Updates.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _expoModulesCore = require(_dependencyMap[0], "expo-modules-core");
  var _UpdatesTypes = require(_dependencyMap[1], "./Updates.types");
  class ExpoUpdatesModule extends _expoModulesCore.NativeModule {
    isEmergencyLaunch = false;
    emergencyLaunchReason = null;
    launchDuration = null;
    isEmbeddedLaunch = false;
    isEnabled = true;
    isUsingEmbeddedAssets = undefined;
    runtimeVersion = '';
    checkAutomatically = 'ALWAYS';
    channel = '';
    shouldDeferToNativeForAPIMethodAvailabilityInDevelopment = false;
    initialContext = {
      isStartupProcedureRunning: false,
      isUpdateAvailable: false,
      isUpdatePending: false,
      isChecking: false,
      isDownloading: false,
      isRestarting: false,
      restartCount: 0,
      sequenceNumber: 0,
      downloadProgress: 0
    };
    async reload() {
      if (typeof window !== 'undefined') window.location.reload(true);
    }
    async checkForUpdateAsync() {
      return {
        isAvailable: false,
        manifest: undefined,
        isRollBackToEmbedded: false,
        reason: _UpdatesTypes.UpdateCheckResultNotAvailableReason.NO_UPDATE_AVAILABLE_ON_SERVER
      };
    }
    async getExtraParamsAsync() {
      return {};
    }
    async setExtraParamAsync(key, value) {}
    async readLogEntriesAsync(maxAge) {
      return [];
    }
    async clearLogEntriesAsync() {}
    async fetchUpdateAsync() {
      return {
        isNew: false,
        manifest: undefined,
        isRollBackToEmbedded: false
      };
    }
  }
  var _default = (0, _expoModulesCore.registerWebModule)(ExpoUpdatesModule, 'ExpoUpdates');
},3725,[131,3726],"node_modules/expo-updates/build/ExpoUpdates.web.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "UpdateCheckResultNotAvailableReason", {
    enumerable: true,
    get: function () {
      return UpdateCheckResultNotAvailableReason;
    }
  });
  Object.defineProperty(exports, "UpdatesLogEntryCode", {
    enumerable: true,
    get: function () {
      return UpdatesLogEntryCode;
    }
  });
  Object.defineProperty(exports, "UpdatesLogEntryLevel", {
    enumerable: true,
    get: function () {
      return UpdatesLogEntryLevel;
    }
  });
  Object.defineProperty(exports, "UpdatesCheckAutomaticallyValue", {
    enumerable: true,
    get: function () {
      return UpdatesCheckAutomaticallyValue;
    }
  });
  var UpdateCheckResultNotAvailableReason;
  (function (UpdateCheckResultNotAvailableReason) {
    /**
     * No update manifest or rollback directive received from the update server.
     */
    UpdateCheckResultNotAvailableReason["NO_UPDATE_AVAILABLE_ON_SERVER"] = "noUpdateAvailableOnServer";
    /**
     * An update manifest was received from the update server, but the update is not launchable,
     * or does not pass the configured selection policy.
     */
    UpdateCheckResultNotAvailableReason["UPDATE_REJECTED_BY_SELECTION_POLICY"] = "updateRejectedBySelectionPolicy";
    /**
     * An update manifest was received from the update server, but the update has been previously
     * launched on this device and never successfully launched.
     */
    UpdateCheckResultNotAvailableReason["UPDATE_PREVIOUSLY_FAILED"] = "updatePreviouslyFailed";
    /**
     * A rollback directive was received from the update server, but the directive does not pass
     * the configured selection policy.
     */
    UpdateCheckResultNotAvailableReason["ROLLBACK_REJECTED_BY_SELECTION_POLICY"] = "rollbackRejectedBySelectionPolicy";
    /**
     * A rollback directive was received from the update server, but this app has no embedded update.
     */
    UpdateCheckResultNotAvailableReason["ROLLBACK_NO_EMBEDDED"] = "rollbackNoEmbeddedConfiguration";
  })(UpdateCheckResultNotAvailableReason || (UpdateCheckResultNotAvailableReason = {}));
  /**
   * The possible code values for `expo-updates` log entries
   */
  var UpdatesLogEntryCode;
  (function (UpdatesLogEntryCode) {
    UpdatesLogEntryCode["NONE"] = "None";
    UpdatesLogEntryCode["NO_UPDATES_AVAILABLE"] = "NoUpdatesAvailable";
    UpdatesLogEntryCode["UPDATE_ASSETS_NOT_AVAILABLE"] = "UpdateAssetsNotAvailable";
    UpdatesLogEntryCode["UPDATE_SERVER_UNREACHABLE"] = "UpdateServerUnreachable";
    UpdatesLogEntryCode["UPDATE_HAS_INVALID_SIGNATURE"] = "UpdateHasInvalidSignature";
    UpdatesLogEntryCode["UPDATE_CODE_SIGNING_ERROR"] = "UpdateCodeSigningError";
    UpdatesLogEntryCode["UPDATE_FAILED_TO_LOAD"] = "UpdateFailedToLoad";
    UpdatesLogEntryCode["ASSETS_FAILED_TO_LOAD"] = "AssetsFailedToLoad";
    UpdatesLogEntryCode["JS_RUNTIME_ERROR"] = "JSRuntimeError";
    UpdatesLogEntryCode["INITIALIZATION_ERROR"] = "InitializationError";
    UpdatesLogEntryCode["UNKNOWN"] = "Unknown";
  })(UpdatesLogEntryCode || (UpdatesLogEntryCode = {}));
  /**
   * The possible log levels for `expo-updates` log entries
   */
  var UpdatesLogEntryLevel;
  (function (UpdatesLogEntryLevel) {
    UpdatesLogEntryLevel["TRACE"] = "trace";
    UpdatesLogEntryLevel["DEBUG"] = "debug";
    UpdatesLogEntryLevel["INFO"] = "info";
    UpdatesLogEntryLevel["WARN"] = "warn";
    UpdatesLogEntryLevel["ERROR"] = "error";
    UpdatesLogEntryLevel["FATAL"] = "fatal";
  })(UpdatesLogEntryLevel || (UpdatesLogEntryLevel = {}));
  /**
   * The possible settings that determine if `expo-updates` will check for updates on app startup.
   * By default, Expo will check for updates every time the app is loaded.
   * Set this to `ON_ERROR_RECOVERY` to disable automatic checking unless recovering from an error.
   * Set this to `NEVER` to completely disable automatic checking.
   */
  var UpdatesCheckAutomaticallyValue;
  (function (UpdatesCheckAutomaticallyValue) {
    /**
     * Checks for updates whenever the app is loaded. This is the default setting.
     */
    UpdatesCheckAutomaticallyValue["ON_LOAD"] = "ON_LOAD";
    /**
     * Only checks for updates when the app starts up after an error recovery.
     */
    UpdatesCheckAutomaticallyValue["ON_ERROR_RECOVERY"] = "ON_ERROR_RECOVERY";
    /**
     * Only checks for updates when the app starts and has a Wi-Fi connection.
     */
    UpdatesCheckAutomaticallyValue["WIFI_ONLY"] = "WIFI_ONLY";
    /**
     * Automatic update checks are off, and update checks must be done through the JS API.
     */
    UpdatesCheckAutomaticallyValue["NEVER"] = "NEVER";
  })(UpdatesCheckAutomaticallyValue || (UpdatesCheckAutomaticallyValue = {}));
},3726,[],"node_modules/expo-updates/build/Updates.types.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "latestContext", {
    enumerable: true,
    get: function () {
      return latestContext;
    }
  });
  Object.defineProperty(exports, "addUpdatesStateChangeListener", {
    enumerable: true,
    get: function () {
      return addUpdatesStateChangeListener;
    }
  });
  Object.defineProperty(exports, "emitTestStateChangeEvent", {
    enumerable: true,
    get: function () {
      return emitTestStateChangeEvent;
    }
  });
  Object.defineProperty(exports, "resetLatestContext", {
    enumerable: true,
    get: function () {
      return resetLatestContext;
    }
  });
  var _ExpoUpdates = require(_dependencyMap[0], "./ExpoUpdates");
  var ExpoUpdatesModule = _interopDefault(_ExpoUpdates);
  let latestContext = transformNativeStateMachineContext(ExpoUpdatesModule.default.initialContext);
  ExpoUpdatesModule.default.addListener('Expo.nativeUpdatesStateChangeEvent', _handleNativeStateChangeEvent);
  const _updatesStateChangeListeners = new Set();
  // Reemits native state change events
  function _handleNativeStateChangeEvent(params) {
    const newParams = typeof params === 'string' ? JSON.parse(params) : {
      ...params
    };
    const transformedContext = transformNativeStateMachineContext(newParams.context);
    // only process state change events if they are in order
    if (transformedContext.sequenceNumber <= latestContext.sequenceNumber) {
      return;
    }
    newParams.context = transformedContext;
    latestContext = transformedContext;
    _updatesStateChangeListeners.forEach(listener => listener(newParams));
  }
  /**
   * Add listener for state change events
   * @hidden
   */
  const addUpdatesStateChangeListener = listener => {
    _updatesStateChangeListeners.add(listener);
    return {
      remove() {
        _updatesStateChangeListeners.delete(listener);
      }
    };
  };
  /**
   * Allows JS test to emit a simulated native state change event (used in unit testing)
   * @hidden
   */
  const emitTestStateChangeEvent = event => {
    _handleNativeStateChangeEvent(event);
  };
  /**
   * Allows JS test to reset latest context (and sequence number)
   * @hidden
   */
  const resetLatestContext = () => {
    latestContext = transformNativeStateMachineContext(ExpoUpdatesModule.default.initialContext);
  };
  function transformNativeStateMachineContext(originalNativeContext) {
    const nativeContext = {
      ...originalNativeContext
    };
    if (nativeContext.latestManifestString) {
      nativeContext.latestManifest = JSON.parse(nativeContext.latestManifestString);
      delete nativeContext.latestManifestString;
    }
    if (nativeContext.downloadedManifestString) {
      nativeContext.downloadedManifest = JSON.parse(nativeContext.downloadedManifestString);
      delete nativeContext.downloadedManifestString;
    }
    if (nativeContext.lastCheckForUpdateTimeString) {
      nativeContext.lastCheckForUpdateTime = new Date(nativeContext.lastCheckForUpdateTimeString);
      delete nativeContext.lastCheckForUpdateTimeString;
    }
    if (nativeContext.rollbackString) {
      nativeContext.rollback = JSON.parse(nativeContext.rollbackString);
      delete nativeContext.rollbackString;
    }
    return nativeContext;
  }
},3727,[3725],"node_modules/expo-updates/build/UpdatesEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "useUpdates", {
    enumerable: true,
    get: function () {
      return useUpdates;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var _UpdatesEmitter = require(_dependencyMap[1], "./UpdatesEmitter");
  var _UseUpdatesUtils = require(_dependencyMap[2], "./UseUpdatesUtils");
  /**
   * Hook that obtains information on available updates and on the currently running update.
   *
   * @return the structures with information on currently running and available updates.
   *
   * @example
   * ```tsx UpdatesDemo.tsx
   * import { StatusBar } from 'expo-status-bar';
   * import * as Updates from 'expo-updates';
   * import { useEffect } from 'react';
   * import { Button, Text, View } from 'react-native';
   *
   * export default function UpdatesDemo() {
   *   const {
   *     currentlyRunning,
   *     isUpdateAvailable,
   *     isUpdatePending
   *   } = Updates.useUpdates();
   *
   *   useEffect(() => {
   *     if (isUpdatePending) {
   *       // Update has successfully downloaded; apply it now
   *       Updates.reloadAsync();
   *     }
   *   }, [isUpdatePending]);
   *
   *   // If true, we show the button to download and run the update
   *   const showDownloadButton = isUpdateAvailable;
   *
   *   // Show whether or not we are running embedded code or an update
   *   const runTypeMessage = currentlyRunning.isEmbeddedLaunch
   *     ? 'This app is running from built-in code'
   *     : 'This app is running an update';
   *
   *   return (
   *     <View style={styles.container}>
   *       <Text style={styles.headerText}>Updates Demo</Text>
   *       <Text>{runTypeMessage}</Text>
   *       <Button onPress={() => Updates.checkForUpdateAsync()} title="Check manually for updates" />
   *       {showDownloadButton ? (
   *         <Button onPress={() => Updates.fetchUpdateAsync()} title="Download and run update" />
   *       ) : null}
   *       <StatusBar style="auto" />
   *     </View>
   *   );
   * }
   * ```
   */
  const useUpdates = () => {
    const [updatesState, setUpdatesState] = (0, _react.useState)((0, _UseUpdatesUtils.updatesStateFromContext)(_UpdatesEmitter.latestContext));
    // Change the state based on native state machine context changes
    (0, _react.useEffect)(() => {
      const subscription = (0, _UpdatesEmitter.addUpdatesStateChangeListener)(event => {
        setUpdatesState((0, _UseUpdatesUtils.updatesStateFromContext)(event.context));
      });
      return () => subscription.remove();
    }, []);
    // Return the updates info and the user facing functions
    return {
      currentlyRunning: _UseUpdatesUtils.currentlyRunning,
      ...updatesState
    };
  };
},3728,[62,3727,3729],"node_modules/expo-updates/build/UseUpdates.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "currentlyRunning", {
    enumerable: true,
    get: function () {
      return currentlyRunning;
    }
  });
  Object.defineProperty(exports, "updateFromManifest", {
    enumerable: true,
    get: function () {
      return updateFromManifest;
    }
  });
  Object.defineProperty(exports, "updateFromRollback", {
    enumerable: true,
    get: function () {
      return updateFromRollback;
    }
  });
  Object.defineProperty(exports, "updatesStateFromContext", {
    enumerable: true,
    get: function () {
      return updatesStateFromContext;
    }
  });
  var _Updates = require(_dependencyMap[0], "./Updates");
  var Updates = _interopNamespace(_Updates);
  var _UseUpdatesTypes = require(_dependencyMap[1], "./UseUpdates.types");
  // The currently running info, constructed from Updates constants
  const currentlyRunning = {
    updateId: Updates.updateId ?? undefined,
    channel: Updates.channel ?? undefined,
    createdAt: Updates.createdAt ?? undefined,
    launchDuration: Updates.launchDuration ?? undefined,
    isEmbeddedLaunch: Updates.isEmbeddedLaunch,
    isEmergencyLaunch: Updates.isEmergencyLaunch,
    emergencyLaunchReason: Updates.emergencyLaunchReason,
    manifest: Updates.manifest ?? undefined,
    runtimeVersion: Updates.runtimeVersion ?? undefined
  };
  // Constructs an UpdateInfo from a manifest
  const updateFromManifest = manifest => {
    return {
      type: _UseUpdatesTypes.UpdateInfoType.NEW,
      updateId: manifest.id ?? '',
      createdAt: manifest && 'createdAt' in manifest && manifest.createdAt ? new Date(manifest.createdAt) :
      // We should never reach this if the manifest is valid and has a commit time,
      // but leave this in so that createdAt is always defined
      new Date(0),
      manifest
    };
  };
  const updateFromRollback = rollback => ({
    type: _UseUpdatesTypes.UpdateInfoType.ROLLBACK,
    createdAt: new Date(rollback.commitTime),
    manifest: undefined,
    updateId: undefined
  });
  // Transform the useUpdates() state based on native state machine context
  const updatesStateFromContext = context => {
    const availableUpdate = context?.latestManifest ? updateFromManifest(context?.latestManifest) : context.rollback ? updateFromRollback(context.rollback) : undefined;
    const downloadedUpdate = context?.downloadedManifest ? updateFromManifest(context?.downloadedManifest) : context.rollback ? updateFromRollback(context.rollback) : undefined;
    return {
      isStartupProcedureRunning: context.isStartupProcedureRunning,
      isUpdateAvailable: context.isUpdateAvailable,
      isUpdatePending: context.isUpdatePending,
      isChecking: context.isChecking,
      isDownloading: context.isDownloading,
      isRestarting: context.isRestarting,
      restartCount: context.restartCount,
      availableUpdate,
      downloadedUpdate,
      checkError: context.checkError,
      downloadError: context.downloadError,
      downloadProgress: context.downloadProgress,
      lastCheckForUpdateTimeSinceRestart: context.lastCheckForUpdateTime
    };
  };
},3729,[3724,3730],"node_modules/expo-updates/build/UseUpdatesUtils.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "UpdateInfoType", {
    enumerable: true,
    get: function () {
      return UpdateInfoType;
    }
  });
  /**
   * The different possible types of updates.
   * Currently, the only supported type is `UpdateInfoType.NEW`, indicating a new update that can be downloaded and launched
   * on the device.
   * In the future, other types of updates may be added to this list.
   */
  var UpdateInfoType;
  (function (UpdateInfoType) {
    /**
     * This is the type for new updates found on or downloaded from the update server, that are launchable on the device.
     */
    UpdateInfoType["NEW"] = "new";
    /**
     * This type is used when an update is a directive to roll back to the embedded bundle.
     */
    UpdateInfoType["ROLLBACK"] = "rollback";
  })(UpdateInfoType || (UpdateInfoType = {}));
},3730,[],"node_modules/expo-updates/build/UseUpdates.types.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},3731,[],"node_modules/expo-updates/build/ExpoUpdatesModule.types.js");
//# sourceMappingURL=http://127.0.0.1:8087/node_modules/expo-updates/build/index.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false