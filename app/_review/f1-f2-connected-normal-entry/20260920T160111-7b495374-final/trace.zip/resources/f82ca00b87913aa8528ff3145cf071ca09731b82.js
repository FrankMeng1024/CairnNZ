__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "useAsyncStorage", {
    enumerable: true,
    get: function () {
      return _hooks.useAsyncStorage;
    }
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _AsyncStorage = require(_dependencyMap[0], "./AsyncStorage");
  var AsyncStorage = _interopDefault(_AsyncStorage);
  var _hooks = require(_dependencyMap[1], "./hooks");
  var _default = AsyncStorage.default;
},548,[549,553],"node_modules/@react-native-async-storage/async-storage/lib/module/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _mergeOptions = require(_dependencyMap[0], "merge-options");
  var mergeOptions = _interopDefault(_mergeOptions);
  // eslint-disable-next-line @typescript-eslint/ban-types
  // eslint-disable-next-line @typescript-eslint/ban-types
  const merge = mergeOptions.default.bind({
    concatArrays: true,
    ignoreUndefined: true
  });
  function mergeLocalStorageItem(key, value) {
    const oldValue = window.localStorage.getItem(key);
    if (oldValue) {
      const oldObject = JSON.parse(oldValue);
      const newObject = JSON.parse(value);
      const nextValue = JSON.stringify(merge(oldObject, newObject));
      window.localStorage.setItem(key, nextValue);
    } else {
      window.localStorage.setItem(key, value);
    }
  }
  function createPromise(getValue, callback) {
    return new Promise((resolve, reject) => {
      try {
        const value = getValue();
        callback?.(null, value);
        resolve(value);
      } catch (err) {
        callback?.(err);
        reject(err);
      }
    });
  }
  function createPromiseAll(promises, callback, processResult) {
    return Promise.all(promises).then(result => {
      const value = processResult?.(result) ?? null;
      callback?.(null, value);
      return Promise.resolve(value);
    }, errors => {
      callback?.(errors);
      return Promise.reject(errors);
    });
  }
  const AsyncStorage = {
    /**
     * Fetches `key` value.
     */
    getItem: (key, callback) => {
      return createPromise(() => window.localStorage.getItem(key), callback);
    },
    /**
     * Sets `value` for `key`.
     */
    setItem: (key, value, callback) => {
      return createPromise(() => window.localStorage.setItem(key, value), callback);
    },
    /**
     * Removes a `key`
     */
    removeItem: (key, callback) => {
      return createPromise(() => window.localStorage.removeItem(key), callback);
    },
    /**
     * Merges existing value with input value, assuming they are stringified JSON.
     */
    mergeItem: (key, value, callback) => {
      return createPromise(() => mergeLocalStorageItem(key, value), callback);
    },
    /**
     * Erases *all* AsyncStorage for the domain.
     */
    clear: callback => {
      return createPromise(() => window.localStorage.clear(), callback);
    },
    /**
     * Gets *all* keys known to the app, for all callers, libraries, etc.
     */
    getAllKeys: callback => {
      return createPromise(() => {
        const numberOfKeys = window.localStorage.length;
        const keys = [];
        for (let i = 0; i < numberOfKeys; i += 1) {
          const key = window.localStorage.key(i) || "";
          keys.push(key);
        }
        return keys;
      }, callback);
    },
    /**
     * (stub) Flushes any pending requests using a single batch call to get the data.
     */
    flushGetRequests: () => undefined,
    /**
     * multiGet resolves to an array of key-value pair arrays that matches the
     * input format of multiSet.
     *
     *   multiGet(['k1', 'k2']) -> [['k1', 'val1'], ['k2', 'val2']]
     */
    multiGet: (keys, callback) => {
      const promises = keys.map(key => AsyncStorage.getItem(key));
      const processResult = result => result.map((value, i) => [keys[i], value]);
      return createPromiseAll(promises, callback, processResult);
    },
    /**
     * Takes an array of key-value array pairs.
     *   multiSet([['k1', 'val1'], ['k2', 'val2']])
     */
    multiSet: (keyValuePairs, callback) => {
      const promises = keyValuePairs.map(item => AsyncStorage.setItem(item[0], item[1]));
      return createPromiseAll(promises, callback);
    },
    /**
     * Delete all the keys in the `keys` array.
     */
    multiRemove: (keys, callback) => {
      const promises = keys.map(key => AsyncStorage.removeItem(key));
      return createPromiseAll(promises, callback);
    },
    /**
     * Takes an array of key-value array pairs and merges them with existing
     * values, assuming they are stringified JSON.
     *
     *   multiMerge([['k1', 'val1'], ['k2', 'val2']])
     */
    multiMerge: (keyValuePairs, callback) => {
      const promises = keyValuePairs.map(item => AsyncStorage.mergeItem(item[0], item[1]));
      return createPromiseAll(promises, callback);
    }
  };
  var _default = AsyncStorage;
},549,[550],"node_modules/@react-native-async-storage/async-storage/lib/module/AsyncStorage.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _indexJs = require(_dependencyMap[0], "./index.js");
  var mergeOptions = _interopDefault(_indexJs);
  /**
   * Thin ESM wrapper for CJS named exports.
   *
   * Ref: https://redfin.engineering/node-modules-at-war-why-commonjs-and-es-modules-cant-get-along-9617135eeca1
   */

  var _default = mergeOptions.default;
},550,[551],"node_modules/merge-options/index.mjs");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  const isOptionObject = require(_dependencyMap[0], "is-plain-obj");
  const {
    hasOwnProperty
  } = Object.prototype;
  const {
    propertyIsEnumerable
  } = Object;
  const defineProperty = (object, name, value) => Object.defineProperty(object, name, {
    value,
    writable: true,
    enumerable: true,
    configurable: true
  });
  const globalThis = this;
  const defaultMergeOptions = {
    concatArrays: false,
    ignoreUndefined: false
  };
  const getEnumerableOwnPropertyKeys = value => {
    const keys = [];
    for (const key in value) {
      if (hasOwnProperty.call(value, key)) {
        keys.push(key);
      }
    }

    /* istanbul ignore else  */
    if (Object.getOwnPropertySymbols) {
      const symbols = Object.getOwnPropertySymbols(value);
      for (const symbol of symbols) {
        if (propertyIsEnumerable.call(value, symbol)) {
          keys.push(symbol);
        }
      }
    }
    return keys;
  };
  function clone(value) {
    if (Array.isArray(value)) {
      return cloneArray(value);
    }
    if (isOptionObject(value)) {
      return cloneOptionObject(value);
    }
    return value;
  }
  function cloneArray(array) {
    const result = array.slice(0, 0);
    getEnumerableOwnPropertyKeys(array).forEach(key => {
      defineProperty(result, key, clone(array[key]));
    });
    return result;
  }
  function cloneOptionObject(object) {
    const result = Object.getPrototypeOf(object) === null ? Object.create(null) : {};
    getEnumerableOwnPropertyKeys(object).forEach(key => {
      defineProperty(result, key, clone(object[key]));
    });
    return result;
  }

  /**
   * @param {*} merged already cloned
   * @param {*} source something to merge
   * @param {string[]} keys keys to merge
   * @param {Object} config Config Object
   * @returns {*} cloned Object
   */
  const mergeKeys = (merged, source, keys, config) => {
    keys.forEach(key => {
      if (typeof source[key] === 'undefined' && config.ignoreUndefined) {
        return;
      }

      // Do not recurse into prototype chain of merged
      if (key in merged && merged[key] !== Object.getPrototypeOf(merged)) {
        defineProperty(merged, key, merge(merged[key], source[key], config));
      } else {
        defineProperty(merged, key, clone(source[key]));
      }
    });
    return merged;
  };

  /**
   * @param {*} merged already cloned
   * @param {*} source something to merge
   * @param {Object} config Config Object
   * @returns {*} cloned Object
   *
   * see [Array.prototype.concat ( ...arguments )](http://www.ecma-international.org/ecma-262/6.0/#sec-array.prototype.concat)
   */
  const concatArrays = (merged, source, config) => {
    let result = merged.slice(0, 0);
    let resultIndex = 0;
    [merged, source].forEach(array => {
      const indices = [];

      // `result.concat(array)` with cloning
      for (let k = 0; k < array.length; k++) {
        if (!hasOwnProperty.call(array, k)) {
          continue;
        }
        indices.push(String(k));
        if (array === merged) {
          // Already cloned
          defineProperty(result, resultIndex++, array[k]);
        } else {
          defineProperty(result, resultIndex++, clone(array[k]));
        }
      }

      // Merge non-index keys
      result = mergeKeys(result, array, getEnumerableOwnPropertyKeys(array).filter(key => !indices.includes(key)), config);
    });
    return result;
  };

  /**
   * @param {*} merged already cloned
   * @param {*} source something to merge
   * @param {Object} config Config Object
   * @returns {*} cloned Object
   */
  function merge(merged, source, config) {
    if (config.concatArrays && Array.isArray(merged) && Array.isArray(source)) {
      return concatArrays(merged, source, config);
    }
    if (!isOptionObject(source) || !isOptionObject(merged)) {
      return clone(source);
    }
    return mergeKeys(merged, source, getEnumerableOwnPropertyKeys(source), config);
  }
  module.exports = function (...options) {
    const config = merge(clone(defaultMergeOptions), this !== globalThis && this || {}, defaultMergeOptions);
    let merged = {
      _: {}
    };
    for (const option of options) {
      if (option === undefined) {
        continue;
      }
      if (!isOptionObject(option)) {
        throw new TypeError('`' + option + '` is not an Option Object');
      }
      merged = merge(merged, {
        _: option
      }, config);
    }
    return merged._;
  };
},551,[552],"node_modules/merge-options/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  module.exports = value => {
    if (Object.prototype.toString.call(value) !== '[object Object]') {
      return false;
    }
    const prototype = Object.getPrototypeOf(value);
    return prototype === null || prototype === Object.prototype;
  };
},552,[],"node_modules/is-plain-obj/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.useAsyncStorage = useAsyncStorage;
  var _AsyncStorage = require(_dependencyMap[0], "./AsyncStorage");
  var AsyncStorage = _interopDefault(_AsyncStorage);
  function useAsyncStorage(key) {
    return {
      getItem: (...args) => AsyncStorage.default.getItem(key, ...args),
      setItem: (...args) => AsyncStorage.default.setItem(key, ...args),
      mergeItem: (...args) => AsyncStorage.default.mergeItem(key, ...args),
      removeItem: (...args) => AsyncStorage.default.removeItem(key, ...args)
    };
  }
},553,[549],"node_modules/@react-native-async-storage/async-storage/lib/module/hooks.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.getActivityRegistry = getActivityRegistry;
  exports.getUnfinishedActivity = getUnfinishedActivity;
  exports.registerUnfinishedActivity = registerUnfinishedActivity;
  exports.replaceUnfinishedActivity = replaceUnfinishedActivity;
  exports.updateUnfinishedActivity = updateUnfinishedActivity;
  exports.mapActivityServerId = mapActivityServerId;
  exports.completeActivity = completeActivity;
  exports.acknowledgeActivity = acknowledgeActivity;
  exports.updateCompletedActivitySyncState = updateCompletedActivitySyncState;
  exports.removeAcknowledgedActivity = removeAcknowledgedActivity;
  exports.tombstoneActivity = tombstoneActivity;
  exports.isActivityTombstoned = isActivityTombstoned;
  exports.activityRegistryStorageKey = activityRegistryStorageKey;
  var _reactNativeAsyncStorageAsyncStorage = require(_dependencyMap[0], "@react-native-async-storage/async-storage");
  var AsyncStorage = _interopDefault(_reactNativeAsyncStorageAsyncStorage);
  const EMPTY = {
    version: 1,
    unfinished: null,
    completed: [],
    tombstones: []
  };
  const keyFor = userId => `@cairn:activity_registry:v1:${userId}`;
  let writeTail = Promise.resolve();
  function cloneEmpty() {
    return {
      version: 1,
      unfinished: null,
      completed: [],
      tombstones: []
    };
  }
  function validUserId(userId) {
    return !!userId && userId !== 'unknown' && userId !== 'guest';
  }
  async function read(userId) {
    if (!validUserId(userId)) return cloneEmpty();
    try {
      const raw = await AsyncStorage.default.getItem(keyFor(userId));
      if (!raw) return cloneEmpty();
      const parsed = JSON.parse(raw);
      if (!parsed || parsed.version !== 1) return cloneEmpty();
      return {
        version: 1,
        unfinished: parsed.unfinished ?? null,
        completed: Array.isArray(parsed.completed) ? parsed.completed : [],
        tombstones: Array.isArray(parsed.tombstones) ? parsed.tombstones : []
      };
    } catch {
      return cloneEmpty();
    }
  }
  async function mutate(userId, fn) {
    if (!validUserId(userId)) throw new Error('activity_registry_user_required');
    let result = EMPTY;
    const run = writeTail.then(async () => {
      result = fn(await read(userId));
      await AsyncStorage.default.setItem(keyFor(userId), JSON.stringify(result));
    });
    writeTail = run.catch(() => {});
    await run;
    return result;
  }
  async function getActivityRegistry(userId) {
    await writeTail.catch(() => {});
    return read(userId);
  }
  async function getUnfinishedActivity(userId) {
    return (await getActivityRegistry(userId)).unfinished;
  }
  async function registerUnfinishedActivity(record) {
    await mutate(record.userId, snapshot => {
      const current = snapshot.unfinished;
      if (current && current.clientActivityId !== record.clientActivityId) {
        throw new Error('unfinished_activity_exists');
      }
      if (snapshot.tombstones.some(item => item.clientActivityId === record.clientActivityId)) {
        throw new Error('activity_tombstoned');
      }
      return {
        ...snapshot,
        unfinished: record
      };
    });
  }

  /** Replace only the tentative Start that received an authoritative conflict. */
  async function replaceUnfinishedActivity(userId, expectedClientActivityId, replacement) {
    let replaced = false;
    await mutate(userId, snapshot => {
      if (snapshot.unfinished?.clientActivityId !== expectedClientActivityId) return snapshot;
      if (replacement.userId !== userId) throw new Error('activity_registry_owner_mismatch');
      if (snapshot.tombstones.some(item => item.clientActivityId === replacement.clientActivityId)) {
        throw new Error('activity_tombstoned');
      }
      replaced = true;
      return {
        ...snapshot,
        unfinished: replacement
      };
    });
    return replaced;
  }
  async function updateUnfinishedActivity(userId, clientActivityId, patch) {
    let updated = false;
    await mutate(userId, snapshot => {
      if (snapshot.unfinished?.clientActivityId !== clientActivityId) return snapshot;
      updated = true;
      return {
        ...snapshot,
        unfinished: {
          ...snapshot.unfinished,
          ...patch
        }
      };
    });
    return updated;
  }
  /**
   * Persist a late server-shell acknowledgement without changing lifecycle or
   * sync state. In particular, a completed-local Activity remains pending until
   * its full Save payload is acknowledged.
   */
  async function mapActivityServerId(userId, clientActivityId, serverActivityId) {
    let target = 'missing';
    await mutate(userId, snapshot => {
      if (snapshot.tombstones.some(item => item.clientActivityId === clientActivityId)) {
        target = 'tombstoned';
        return snapshot;
      }
      const unfinished = snapshot.unfinished?.clientActivityId === clientActivityId ? {
        ...snapshot.unfinished,
        serverActivityId
      } : snapshot.unfinished;
      if (unfinished !== snapshot.unfinished) target = 'unfinished';
      const completed = snapshot.completed.map(item => {
        if (item.clientActivityId !== clientActivityId) return item;
        target = 'completed';
        return {
          ...item,
          serverActivityId
        };
      });
      return {
        ...snapshot,
        unfinished,
        completed
      };
    });
    return target;
  }
  async function completeActivity(record) {
    await mutate(record.userId, snapshot => ({
      ...snapshot,
      unfinished: snapshot.unfinished?.clientActivityId === record.clientActivityId ? null : snapshot.unfinished,
      completed: [record, ...snapshot.completed.filter(item => item.clientActivityId !== record.clientActivityId)]
    }));
  }
  async function acknowledgeActivity(userId, clientActivityId, serverActivityId) {
    let updated = false;
    await mutate(userId, snapshot => ({
      ...snapshot,
      completed: snapshot.completed.map(item => {
        if (item.clientActivityId !== clientActivityId) return item;
        updated = true;
        return {
          ...item,
          serverActivityId,
          syncState: 'synced',
          acknowledgedAt: Date.now()
        };
      })
    }));
    return updated;
  }
  async function updateCompletedActivitySyncState(userId, clientActivityId, syncState) {
    await mutate(userId, snapshot => ({
      ...snapshot,
      completed: snapshot.completed.map(item => item.clientActivityId === clientActivityId ? {
        ...item,
        syncState
      } : item)
    }));
  }
  async function removeAcknowledgedActivity(userId, clientActivityId) {
    await mutate(userId, snapshot => ({
      ...snapshot,
      completed: snapshot.completed.filter(item => item.clientActivityId !== clientActivityId || item.syncState !== 'synced')
    }));
  }
  async function tombstoneActivity(args) {
    await mutate(args.userId, snapshot => {
      const existing = snapshot.tombstones.find(item => item.clientActivityId === args.clientActivityId);
      const tombstone = existing ?? {
        userId: args.userId,
        clientActivityId: args.clientActivityId,
        serverActivityId: args.serverActivityId ?? null,
        lifecycle: 'discarded',
        discardedAt: Date.now()
      };
      return {
        ...snapshot,
        unfinished: snapshot.unfinished?.clientActivityId === args.clientActivityId ? null : snapshot.unfinished,
        completed: snapshot.completed.filter(item => item.clientActivityId !== args.clientActivityId),
        tombstones: [tombstone, ...snapshot.tombstones.filter(item => item.clientActivityId !== args.clientActivityId)]
      };
    });
  }
  async function isActivityTombstoned(userId, clientActivityId) {
    return (await getActivityRegistry(userId)).tombstones.some(item => item.clientActivityId === clientActivityId);
  }
  function activityRegistryStorageKey(userId) {
    return keyFor(userId);
  }
},597,[548],"src/features/activity/activityRegistry.ts");
//# sourceMappingURL=http://127.0.0.1:8087/src/features/activity/activityRegistry.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false